/*
 * Copyright 2010 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package repackage.com.jsyn.unitgen;

import repackage.com.jsyn.ports.UnitInputPort;
import repackage.com.jsyn.ports.UnitOutputPort;

/**
 * Base class for binary arithmetic operators like Add and Compare.
 * 
 * @author Phil Burk (C) 2010 Mobileer Inc
 */
public abstract class UnitBinaryOperator extends UnitGenerator {
    public UnitInputPort inputA;
    public UnitInputPort inputB;
    public UnitOutputPort output;

    /* Define Unit Ports used by connect() and set(). */
    public UnitBinaryOperator() {
        addPort(inputA = new UnitInputPort("InputA"));
        addPort(inputB = new UnitInputPort("InputB"));
        addPort(output = new UnitOutputPort("Output"));
    }

    @Override
    public abstract void generate(int start, int limit);
}
