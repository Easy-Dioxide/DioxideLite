/*
 * Copyright 2011 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package repackage.com.jsyn.ports;

/**
 * This is called when a block of data that is queued to a UnitDataQueuePort starts, loops, or
 * finishes.
 * 
 * @author Phil Burk (C) 2011 Mobileer Inc
 */
public interface UnitDataQueueCallback {
    void started(QueueDataEvent event);

    void looped(QueueDataEvent event);

    void finished(QueueDataEvent event);
}
