/*
 * This file is part of DioxideLiteVia - https://github.com/ViaVersion/DioxideLiteVia
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.dioxidelitevia;

import com.viaversion.dioxidelitevia.api.DioxideLiteViaBase;
import com.viaversion.dioxidelitevia.api.entrypoint.DioxideLiteViaLoadEntrypoint;
import com.viaversion.dioxidelitevia.api.events.ChangeProtocolVersionCallback;
import com.viaversion.dioxidelitevia.api.events.LoadingCycleCallback;
import com.viaversion.dioxidelitevia.api.settings.SettingGroup;
import com.viaversion.dioxidelitevia.util.network.SyncTasks;
import com.viaversion.dioxidelitevia.features.FeaturesLoading;
import com.viaversion.dioxidelitevia.features.item.filter_creative_tabs.VersionedRegistries;
import com.viaversion.dioxidelitevia.features.item.negative_item_count.NegativeItemUtil;
import com.viaversion.dioxidelitevia.features.limitation.max_chat_length.MaxChatLength;
import com.viaversion.dioxidelitevia.injection.access.core.IConnection;
import com.viaversion.dioxidelitevia.injection.access.core.IServerData;
import com.viaversion.dioxidelitevia.protocoltranslator.ProtocolTranslator;
import com.viaversion.dioxidelitevia.protocoltranslator.translator.ItemTranslator;
import com.viaversion.dioxidelitevia.save.SaveManager;
import com.viaversion.dioxidelitevia.screen.impl.ProtocolSelectionScreen;
import com.viaversion.dioxidelitevia.screen.impl.SettingsScreen;
import com.viaversion.dioxidelitevia.settings.SettingsManager;
import com.viaversion.dioxidelitevia.util.ChatUtil;
import com.viaversion.dioxidelitevia.util.ClassLoaderPriorityUtil;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import io.netty.channel.Channel;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
import net.fabricmc.loader.api.metadata.ModMetadata;
import net.minecraft.world.level.block.entity.BannerPattern;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.Connection;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.Holder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import static com.viaversion.dioxidelitevia.api.entrypoint.DioxideLiteViaLoadEntrypoint.KEY;

public final class DioxideLiteViaImpl implements DioxideLiteViaBase {

    public static final Event<LoadingCycleCallback> LOADING_CYCLE = EventFactory.createArrayBacked(LoadingCycleCallback.class, listeners -> state -> {
        for (final LoadingCycleCallback listener : listeners) {
            listener.onLoadCycle(state);
        }
    });

    public static final Event<ChangeProtocolVersionCallback> CHANGE_PROTOCOL_VERSION = EventFactory.createArrayBacked(ChangeProtocolVersionCallback.class, listeners -> (oldVersion, newVersion) -> {
        for (final ChangeProtocolVersionCallback listener : listeners) {
            listener.onChangeProtocolVersion(oldVersion, newVersion);
        }
    });

    public static final DioxideLiteViaImpl INSTANCE = new DioxideLiteViaImpl();

    private final Logger logger = LogManager.getLogger("DioxideLiteVia");
    private final Path path = FabricLoader.getInstance().getConfigDir().resolve("dioxidelitevia");

    private String version;
    private String implVersion;
    private CompletableFuture<Void> loadingFuture;

    public void init() {
        DioxideLiteVia.init(INSTANCE);

        final ModMetadata metadata = FabricLoader.getInstance().getModContainer("dioxide-lite").orElseThrow().getMetadata();
        version = metadata.getVersion().getFriendlyString();
        implVersion = metadata.getCustomValue("dioxidelitevia:implVersion").getAsString();

        for (final EntrypointContainer<DioxideLiteViaLoadEntrypoint> container : FabricLoader.getInstance().getEntrypointContainers(KEY, DioxideLiteViaLoadEntrypoint.class)) {
            container.getEntrypoint().onPlatformLoad(INSTANCE);
        }

        try {
            Files.createDirectories(path);
        } catch (final IOException e) {
            logger.error("Failed to create DioxideLiteVia directory", e);
        }

        ClassLoaderPriorityUtil.loadOverridingJars(path, logger);
        SettingsManager.INSTANCE.init();
        SaveManager.INSTANCE.init();
        SyncTasks.init();
        FeaturesLoading.init();

        this.loadingFuture = ProtocolTranslator.init(path);
        LOADING_CYCLE.register(cycle -> {
            if (cycle == LoadingCycleCallback.LoadingCycle.POST_GAME_LOAD) {
                this.loadingFuture.join();
                FeaturesLoading.postInit();
                SaveManager.INSTANCE.postInit();
            }
        });
        LOADING_CYCLE.invoker().onLoadCycle(LoadingCycleCallback.LoadingCycle.FINAL_LOAD);
    }

    // --------------------------------------------------------------------------------------------
    // Proxy the most important/used internals to a general API point for mods

    @Override
    public String getVersion() {
        return this.version;
    }

    @Override
    public String getImplVersion() {
        return this.implVersion;
    }

    @Override
    public Path getPath() {
        return this.path;
    }

    @Override
    public @Nullable ProtocolVersion getTargetVersion() {
        return ProtocolTranslator.getTargetVersion();
    }

    @Override
    public void setTargetVersion(ProtocolVersion newVersion) {
        ProtocolTranslator.setTargetVersion(newVersion);
    }

    @Override
    public @Nullable ProtocolVersion getTargetVersion(Channel channel) {
        return ProtocolTranslator.getTargetVersion(channel);
    }

    @Override
    public @Nullable ProtocolVersion getTargetVersion(Connection connection) {
        return ((IConnection) connection).DioxideLiteVia$getTargetVersion();
    }

    @Override
    public void setTargetVersion(ProtocolVersion newVersion, boolean revertOnDisconnect) {
        ProtocolTranslator.setTargetVersion(newVersion, revertOnDisconnect);
    }

    @Override
    public @Nullable UserConnection getPlayNetworkUserConnection() {
        return ProtocolTranslator.getPlayNetworkUserConnection();
    }

    @Override
    public @Nullable UserConnection getUserConnection(Connection connection) {
        return ((IConnection) connection).DioxideLiteVia$getUserConnection();
    }

    @Override
    public @Nullable ProtocolVersion getServerVersion(ServerData serverInfo) {
        return ((IServerData) serverInfo).DioxideLiteVia$forcedVersion();
    }

    @Override
    public void registerOnChangeProtocolVersionCallback(ChangeProtocolVersionCallback callback) {
        CHANGE_PROTOCOL_VERSION.register(callback);
    }

    @Override
    public void registerLoadingCycleCallback(LoadingCycleCallback callback) {
        LOADING_CYCLE.register(callback);
    }

    @Override
    public int getMaxChatLength(ProtocolVersion version) {
        return MaxChatLength.getChatLength();
    }

    @Override
    public List<SettingGroup> getSettingGroups() {
        return Collections.unmodifiableList(SettingsManager.INSTANCE.getGroups());
    }

    @Override
    public void addSettingGroup(SettingGroup group) {
        SettingsManager.INSTANCE.addGroup(group);
    }

    @Override
    public @Nullable SettingGroup getSettingGroup(String translationKey) {
        for (final SettingGroup group : SettingsManager.INSTANCE.getGroups()) {
            if (ChatUtil.uncoverTranslationKey(group.getName()).equals(translationKey)) {
                return group;
            }
        }
        return null;
    }

    @Override
    public void openProtocolSelectionScreen(Screen parent) {
        ProtocolSelectionScreen.INSTANCE.open(parent);
    }

    @Override
    public void openSettingsScreen(Screen parent) {
        SettingsScreen.INSTANCE.open(parent);
    }

    @Override
    public @Nullable Item translateItem(ItemStack stack, ProtocolVersion targetVersion) {
        return ItemTranslator.mcToVia(stack, targetVersion);
    }

    @Override
    public @Nullable ItemStack translateItem(Item item, ProtocolVersion sourceVersion) {
        return ItemTranslator.viaToMc(item, sourceVersion);
    }

    @Override
    public boolean itemExists(net.minecraft.world.item.Item item, ProtocolVersion version) {
        return VersionedRegistries.containsItem(item, version);
    }

    @Override
    public boolean enchantmentExists(ResourceKey<Enchantment> enchantment, ProtocolVersion version) {
        return VersionedRegistries.containsEnchantment(enchantment, version);
    }

    @Override
    public boolean effectExists(Holder<MobEffect> effect, ProtocolVersion version) {
        return VersionedRegistries.containsEffect(effect, version);
    }

    @Override
    public boolean bannerPatternExists(ResourceKey<BannerPattern> pattern, ProtocolVersion version) {
        return VersionedRegistries.containsBannerPattern(pattern, version);
    }

    @Override
    public boolean itemExistsInConnection(net.minecraft.world.item.Item item) {
        return VersionedRegistries.keepItem(item);
    }

    @Override
    public boolean itemExistsInConnection(ItemStack stack) {
        return VersionedRegistries.keepItem(stack);
    }

    @Override
    public int getStackCount(ItemStack stack) {
        return NegativeItemUtil.getCount(stack);
    }

    public Logger getLogger() {
        return this.logger;
    }

}
