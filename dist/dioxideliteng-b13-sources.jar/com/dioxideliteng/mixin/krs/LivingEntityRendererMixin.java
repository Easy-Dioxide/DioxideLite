package com.dioxideliteng.mixin.krs;

import com.dioxideliteng.krs.KrsClient;
import com.dioxideliteng.krs.hacks.ModuleManager;
import com.dioxideliteng.krs.hacks.features.render.Rotations;
import com.dioxideliteng.krs.hacks.features.render.TrueSight;
import com.dioxideliteng.krs.utils.render.GuiEntityRenderGuard;
import com.dioxideliteng.krs.utils.render.custommodel.CustomModelRenderer;
import com.dioxideliteng.krs.oringo.IEntityRenderState;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.Model;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.texture.UvMapping;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @ModifyExpressionValue(
            method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;solveBodyRot(Lnet/minecraft/world/entity/LivingEntity;FF)F")
    )
    private float krs$vanillaRotationBodyYaw(float original, LivingEntity entity, LivingEntityRenderState state, float tickDelta) {
        if (krs$shouldApplyVanillaRotation(entity))
            return KrsClient.rotationManager.getInterpolatedBodyYaw(tickDelta);

        return original;
    }

    @ModifyExpressionValue(
            method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Mth;rotLerp(FFF)F", ordinal = 0)
    )
    private float krs$vanillaRotationHeadYaw(float original, LivingEntity entity, LivingEntityRenderState state, float tickDelta) {
        if (krs$shouldApplyVanillaRotation(entity))
            return KrsClient.rotationManager.getInterpolatedYaw(tickDelta);

        return original;
    }

    @ModifyExpressionValue(
            method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getXRot(F)F")
    )
    private float krs$vanillaRotationPitch(float original, LivingEntity entity, LivingEntityRenderState state, float tickDelta) {
        if (krs$shouldApplyVanillaRotation(entity))
            return KrsClient.rotationManager.getInterpolatedPitch(tickDelta);

        return original;
    }

    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("HEAD")
    )
    private void krs$revealInvisibleEntities(LivingEntityRenderState state, PoseStack matrices, SubmitNodeCollector submitter, CameraRenderState cameraState, CallbackInfo ci) {
        if (!ModuleManager.getModuleState(TrueSight.class) || !TrueSight.entities.get())
            return;

        Entity entity = ((IEntityRenderState) state).client$getEntity();
        if (!TrueSight.requiresTrueSight(entity))
            return;

        state.isInvisible = false;
        state.isInvisibleToPlayer = false;
    }

    @WrapOperation(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/rendertype/RenderType;IIILnet/minecraft/client/renderer/texture/UvMapping;I)V")
    )
    private void krs$customModelBody(SubmitNodeCollector collector, Model<?> model, Object state, PoseStack poseStack, RenderType renderType,
                                     int lightCoords, int overlayCoords, int tintedColor, UvMapping uvMapping, int outlineColor, Operation<Void> original) {
        if (state instanceof AvatarRenderState avatar
                && CustomModelRenderer.trySubmit(avatar, poseStack, collector, lightCoords, overlayCoords, tintedColor))
            return;

        original.call(collector, model, state, poseStack, renderType, lightCoords, overlayCoords, tintedColor, uvMapping, outlineColor);
    }

    @Unique
    private boolean krs$shouldApplyVanillaRotation(LivingEntity entity) {
        return !GuiEntityRenderGuard.isActive()
                && KrsClient.rotationManager != null
                && KrsClient.rotationManager.isRotating()
                && Rotations.shouldUseVanilla()
                && entity == Minecraft.getInstance().player;
    }
}
