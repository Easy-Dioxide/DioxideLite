package com.dioxideliteng.mixin.krs;

import com.dioxideliteng.krs.hacks.features.level.CaveFinder;
import com.mojang.renderpearl.backend.api.BackendRenderPipeline;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Since 26.3 OpenGL pipeline state is applied by the compiled pipeline itself when it is bound.
 */
@Mixin(targets = "com.mojang.renderpearl.backend.opengl.GlRenderPipeline")
public abstract class GlRenderPipelineMixin {

    @Unique
    private static boolean krs$frontFaceCulled;

    @Unique
    private boolean krs$terrainPipeline;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void krs$rememberLocation(@Coerce Object device, BackendRenderPipeline.CreateInfo createInfo, @Coerce Object program, @Coerce Object vertexArray, CallbackInfo ci) {
        this.krs$terrainPipeline = CaveFinder.isTerrainPipeline(createInfo.name());
    }

    @Inject(method = "bind", at = @At("RETURN"))
    private void krs$caveFinderCullFace(CallbackInfo ci) {
        boolean cullFront = this.krs$terrainPipeline && CaveFinder.isActive();
        if (cullFront == krs$frontFaceCulled)
            return;

        GL11.glCullFace(cullFront ? GL11.GL_FRONT : GL11.GL_BACK);
        krs$frontFaceCulled = cullFront;
    }
}
