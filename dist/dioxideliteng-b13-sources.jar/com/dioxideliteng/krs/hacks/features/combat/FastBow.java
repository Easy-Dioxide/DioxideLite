package com.dioxideliteng.krs.hacks.features.combat;

import com.dioxideliteng.krs.events.features.UpdateEvent;
import com.dioxideliteng.krs.hacks.Module;
import com.dioxideliteng.krs.hacks.ModuleCategory;
import com.dioxideliteng.krs.utils.packet.PacketUtil;
import com.dioxideliteng.krs.utils.value.IntValue;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import com.dioxideliteng.krs.utils.input.Keys;

public class FastBow extends Module {

    public FastBow() {
        super("Fast Bow", ModuleCategory.Combat, Keys.KEY_UNKNOWN, false, true);
    }

    @Setting
    private final IntValue packets = new IntValue("Packets", 20, 1, 20, "x");

    @Setting
    private final IntValue chargeTicks = new IntValue("Charge Ticks", 1, 1, 20, "ticks");

    @Override
    public void onDisable() {
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onUpdate(UpdateEvent event) {
        var player = mc.player;
        var gameMode = mc.gameMode;
        if (player == null || gameMode == null || !player.isUsingItem()) return;

        ItemStack useItem = player.getUseItem();
        if (useItem.getUseAnimation() != ItemUseAnimation.BOW
                || player.getTicksUsingItem() < chargeTicks.get())
            return;

        InteractionHand hand = player.getUsedItemHand();
        float yaw = player.getYRot();
        float pitch = player.getXRot();
        boolean onGround = player.onGround();
        boolean horizontalCollision = player.horizontalCollision;
        int packetCount = packets.get();
        for (int i = 0; i < packetCount; i++) {
            PacketUtil.sendPacket(new ServerboundMovePlayerPacket.Rot(yaw, pitch, onGround, horizontalCollision));
        }

        PacketUtil.sendPacket(new ServerboundPlayerActionPacket(
                ServerboundPlayerActionPacket.Action.RELEASE_USE_ITEM,
                BlockPos.ZERO,
                Direction.DOWN
        ));

        player.releaseUsingItem();
        if (mc.options.keyUse.isDown()
                && player.getItemInHand(hand).getUseAnimation() == ItemUseAnimation.BOW)
            gameMode.useItem(player, hand);
    }
}
