package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_1058;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4603.class)
public class ScreenEffectRendererMixin {
    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void dioxide_lite$hideFireOverlay(class_4587 poseStack, class_4597 multiBufferSource, class_1058 textureAtlasSprite, CallbackInfo ci) {
        if (Config.hideFireOverlay) {
            ci.cancel();
        }
    }
}
