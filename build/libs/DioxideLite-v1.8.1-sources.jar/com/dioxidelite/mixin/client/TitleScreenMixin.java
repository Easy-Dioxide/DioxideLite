package com.dioxidelite.mixin.client;

import com.dioxidelite.client.Version;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public class TitleScreenMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void dioxide_lite$renderVersionText(class_332 guiGraphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        String version = Version.displayName();
        String type = Version.typeName();
        int x = 4;
        int y = 4;
        if (type.isEmpty()) {
            guiGraphics.method_51433(client.field_1772, version, x, y, 0xFFFFFFFF, false);
            return;
        }

        if (Version.DEBUG) {
            guiGraphics.method_51433(client.field_1772, "DEBUG", x, y + client.field_1772.field_2000 + 2, 0xFFFFD34D, false);
        }

        String marker = "-" + type;
        int typeStart = version.indexOf(marker);
        if (typeStart < 0) {
            guiGraphics.method_51433(client.field_1772, version, x, y, 0xFFFFFFFF, false);
            return;
        }

        typeStart += 1;
        int typeEnd = typeStart + type.length();
        String before = version.substring(0, typeStart);
        String typed = version.substring(typeStart, typeEnd);
        String after = version.substring(typeEnd);
        int typeColor = Version.TYPE == 1 ? 0xFFFF4444 : 0xFFFFD34D;
        guiGraphics.method_51433(client.field_1772, before, x, y, 0xFFFFFFFF, false);
        int tx = x + client.field_1772.method_1727(before);
        guiGraphics.method_51433(client.field_1772, typed, tx, y, typeColor, false);
        guiGraphics.method_51433(client.field_1772, after, tx + client.field_1772.method_1727(typed), y, 0xFFFFFFFF, false);
    }
}
