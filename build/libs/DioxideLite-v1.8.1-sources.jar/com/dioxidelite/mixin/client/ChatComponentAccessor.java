package com.dioxidelite.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_338.class)
public interface ChatComponentAccessor {
    @Accessor("minecraft")
    class_310 dioxide_lite$getMinecraft();

    @Invoker("getWidth")
    int dioxide_lite$getChatWidth();
}
