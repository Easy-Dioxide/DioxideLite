package com.dioxidelite.mixin.client;

import com.dioxidelite.client.modules.impl.Optimize.InputMethodFix.InputMethodFix;
import net.minecraft.class_11905;
import net.minecraft.class_342;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_342.class)
public abstract class InputMethodFixEditBoxMixin {
    @Inject(method = "setFocused", at = @At("TAIL"))
    private void dioxide_lite$onFocusedChanged(boolean focused, CallbackInfo ci) {
        InputMethodFix.refreshForFocusedTextField(net.minecraft.class_310.method_1551());
    }

    @Inject(method = "charTyped", at = @At("HEAD"), cancellable = true)
    private void dioxide_lite$onCharTyped(class_11905 characterEvent, CallbackInfoReturnable<Boolean> cir) {
        InputMethodFix.refreshForFocusedTextField(net.minecraft.class_310.method_1551());
    }
}
