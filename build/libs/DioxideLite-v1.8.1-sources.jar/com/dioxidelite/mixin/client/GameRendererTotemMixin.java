package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererTotemMixin {
    @Inject(method = "displayItemActivation", at = @At("HEAD"), cancellable = true)
    private void hideTotemAnimation(class_1799 itemStack, CallbackInfo ci) {
        if (Config.hideTotemAnimation && itemStack.method_31574(class_1802.field_8288)) {
            ci.cancel();
        }
    }
}
