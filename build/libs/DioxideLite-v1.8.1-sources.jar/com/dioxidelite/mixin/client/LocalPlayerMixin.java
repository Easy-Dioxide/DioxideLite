package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Tool.AutoChestDepositManager;
import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public class LocalPlayerMixin {
    @Shadow @Final protected class_310 minecraft;

    @Inject(method = "aiStep", at = @At("HEAD"))
    private void handleUseSwingInput(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;
        AutoChestDepositManager.applyRotationLock(player);
        if (Config.useSwing && player.method_6115()) {
            if (this.minecraft.field_1690.field_1886.method_1434()) {
                if (player.field_6279 <= 0) {
                    player.method_6104(class_1268.field_5808);
                }
            }
        }
    }
}
