package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_4184;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow private class_1297 entity;
    @Shadow private boolean detached;
    @Shadow private float eyeHeight;
    @Unique private final class_4050[] dioxideLite$lastPoses = new class_4050[2];

    @Inject(method = "tick", at = @At("HEAD"))
    private void storeSneakPose(CallbackInfo ci) {
        if (this.entity == null) return;

        class_4050 pose = this.entity.method_18376();
        if (pose != this.dioxideLite$lastPoses[0]) {
            this.dioxideLite$lastPoses[1] = this.dioxideLite$lastPoses[0];
            this.dioxideLite$lastPoses[0] = pose;
        }
    }

    @Inject(method = "tick", at = @At(value = "FIELD", target = "Lnet/minecraft/client/Camera;eyeHeight:F", ordinal = 0))
    private void updateInstantSneakEyeHeight(CallbackInfo ci) {
        if (Config.sneakAnimationSpeed < 1.0f || !isValidSneakTransition() || !(this.entity instanceof class_746 player)) {
            return;
        }

        this.eyeHeight = getCustomEyeHeight(player, player.method_18376());
    }

    @ModifyConstant(method = "tick", constant = @Constant(floatValue = 0.5f))
    private float updateSneakEyeHeightSpeed(float modifier) {
        if (!isValidSneakTransition()) {
            return modifier;
        }

        return Config.sneakAnimationSpeed >= 1.0f ? 0.0f : getSneakAnimationModifier();
    }

    private float getCustomEyeHeight(class_746 player, class_4050 pose) {
        float standingEyeHeight = player.method_18377(class_4050.field_18076).comp_2187();
        if (pose != class_4050.field_18081) {
            return standingEyeHeight;
        }

        float crouchingEyeHeight = player.method_18377(class_4050.field_18081).comp_2187();
        float sneakDrop = standingEyeHeight - crouchingEyeHeight;
        return standingEyeHeight - sneakDrop * Config.sneakDropScale;
    }

    private float getSneakAnimationModifier() {
        return 0.5f + Config.sneakAnimationSpeed * 0.5f;
    }

    @Unique
    private boolean isValidSneakTransition() {
        if (!Config.noSneakAnimation || this.detached || !(this.entity instanceof class_746 player)) {
            return false;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1724 != player) {
            return false;
        }

        return this.dioxideLite$lastPoses[1] == class_4050.field_18076 && this.dioxideLite$lastPoses[0] == class_4050.field_18081
                || this.dioxideLite$lastPoses[1] == class_4050.field_18081 && this.dioxideLite$lastPoses[0] == class_4050.field_18076;
    }
}
