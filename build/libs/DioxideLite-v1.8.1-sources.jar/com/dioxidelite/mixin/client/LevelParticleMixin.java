package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1937.class)
public class LevelParticleMixin {
    @Inject(method = "addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V", at = @At("HEAD"), cancellable = true)
    private void hideExplosionParticles(class_2394 particleOptions, double x, double y, double z, double vx, double vy, double vz, CallbackInfo ci) {
        if (shouldHideParticle(particleOptions)) {
            ci.cancel();
        }
    }

    @Inject(method = "addParticle(Lnet/minecraft/core/particles/ParticleOptions;ZZDDDDDD)V", at = @At("HEAD"), cancellable = true)
    private void hideExplosionParticlesForced(class_2394 particleOptions, boolean force, boolean important, double x, double y, double z, double vx, double vy, double vz, CallbackInfo ci) {
        if (shouldHideParticle(particleOptions)) {
            ci.cancel();
        }
    }

    @Inject(method = "addAlwaysVisibleParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V", at = @At("HEAD"), cancellable = true)
    private void hideAlwaysVisibleExplosionParticles(class_2394 particleOptions, double x, double y, double z, double vx, double vy, double vz, CallbackInfo ci) {
        if (shouldHideParticle(particleOptions)) {
            ci.cancel();
        }
    }

    @Inject(method = "addAlwaysVisibleParticle(Lnet/minecraft/core/particles/ParticleOptions;ZDDDDDD)V", at = @At("HEAD"), cancellable = true)
    private void hideAlwaysVisibleExplosionParticlesForced(class_2394 particleOptions, boolean ignoreRange, double x, double y, double z, double vx, double vy, double vz, CallbackInfo ci) {
        if (shouldHideParticle(particleOptions)) {
            ci.cancel();
        }
    }

    private boolean shouldHideParticle(class_2394 particleOptions) {
        return (Config.hideExplosionParticles && isExplosionParticle(particleOptions))
                || (Config.hideRainParticles && isRainParticle(particleOptions));
    }

    private boolean isExplosionParticle(class_2394 particleOptions) {
        return particleOptions == class_2398.field_11236
                || particleOptions == class_2398.field_11221
                || particleOptions == class_2398.field_11203
                || particleOptions == class_2398.field_11251
                || particleOptions == class_2398.field_11237;
    }

    private boolean isRainParticle(class_2394 particleOptions) {
        return particleOptions == class_2398.field_11242
                || particleOptions == class_2398.field_11232
                || particleOptions == class_2398.field_18306;
    }
}
