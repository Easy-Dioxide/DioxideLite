package com.dioxidelite.mixin.client;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_2703;
import net.minecraft.class_634;
import net.minecraft.class_7438;
import com.dioxidelite.client.modules.impl.Render.BetterChat.BetterChatHeadsState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class BetterChatPlayerChatMessageMixin {
    @Inject(method = "handlePlayerInfoUpdate", at = @At("HEAD"))
    private void dioxide_lite$cacheSender(class_2703 packet, CallbackInfo ci) {
        for (class_2703.class_2705 entry : packet.method_46329()) {
            GameProfile profile = entry.comp_1107();
            if (profile != null) {
                BetterChatHeadsState.getInstance().setPendingSender(profile);
            }
        }
    }

    @Inject(method = "handlePlayerChat", at = @At("HEAD"))
    private void dioxide_lite$cacheSender(class_7438 packet, CallbackInfo ci) {
        GameProfile profile = BetterChatHeadsState.getInstance().findProfile(packet.comp_1099());
        if (profile != null) {
            BetterChatHeadsState.getInstance().setPendingSender(profile);
        }
    }
}
