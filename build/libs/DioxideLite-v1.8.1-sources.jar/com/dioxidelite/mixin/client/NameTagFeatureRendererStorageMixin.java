package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.util.NameTagPlayerFilterContext;
import net.minecraft.class_12075;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(targets = "net.minecraft.client.renderer.feature.NameTagFeatureRenderer$Storage")
public class NameTagFeatureRendererStorageMixin {
    @Unique private double dioxide_lite$nameTagDistanceSq = 64.0;

    @Inject(method = "add", at = @At("HEAD"))
    private void dioxide_lite$captureNameTagDistance(class_4587 poseStack, class_243 attachment, int yOffset, class_2561 component, boolean seeThrough, int light, double distanceToCameraSq, class_12075 cameraRenderState, CallbackInfo ci) {
        dioxide_lite$nameTagDistanceSq = distanceToCameraSq;
    }

    @ModifyArgs(
            method = "add",
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;scale(FFF)V")
    )
    private void dioxide_lite$modifyNameTagScale(Args args) {
        if (!Config.nameTag) return;
        if (Config.nameTagOnlyPlayer && !NameTagPlayerFilterContext.isRealPlayer()) return;
        float scale = clamp(Config.nameTagScale, 0.5f, 3.0f) * dynamicScale();
        args.set(0, (float) args.get(0) * scale);
        args.set(1, (float) args.get(1) * scale);
        args.set(2, (float) args.get(2) * scale);
    }

    private float dynamicScale() {
        if (!Config.nameTagDynamicScale) return 1.0f;
        return clamp((float) (Math.sqrt(Math.max(0.0, dioxide_lite$nameTagDistanceSq)) / 8.0), 0.5f, 8.0f);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
