package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.render.nativeui.NativeGlassVisualSystem;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Places the glass material after the vanilla container background but before slots/widgets. */
@Mixin(class_465.class)
public abstract class AbstractContainerScreenGlassMixin {
    @Inject(method = "renderSlots", at = @At("HEAD"))
    private void dioxide_lite$liquidGlassContainer(class_332 graphics, int mouseX, int mouseY, CallbackInfo ci) {
        if (!Config.liquidGlassAllVisuals) return;
        class_465<?> screen = (class_465<?>) (Object) this;
        NativeGlassVisualSystem.renderContainer(graphics, screen.field_22789, screen.field_22790);
    }
}
