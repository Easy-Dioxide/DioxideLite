package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_303;
import net.minecraft.class_7591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_303.class_7590.class)
public class BetterChatGuiMessageMixin {
    @Inject(method = "tag", at = @At("HEAD"), cancellable = true)
    private void dioxide_lite$removeIndicator(CallbackInfoReturnable<class_7591> cir) {
        if (Config.betterChat) {
            cir.setReturnValue(null);
        }
    }
}
