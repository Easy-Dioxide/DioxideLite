package com.dioxidelite.mixin.client;

import net.minecraft.class_1657;
import net.minecraft.class_4050;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1657.class)
public interface PlayerPoseAccessMixin {
    @Invoker("canPlayerFitWithinBlocksAndEntitiesWhen")
    boolean dioxideLite$canPlayerFitWithinBlocksAndEntitiesWhen(class_4050 pose);
}
