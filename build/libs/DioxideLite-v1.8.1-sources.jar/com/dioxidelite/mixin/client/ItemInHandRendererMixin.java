package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.gui.SettingsScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {
    @Shadow private class_1799 mainHandItem;
    @Shadow private float mainHandHeight;
    @Shadow private float oMainHandHeight;
    @Shadow private void applyItemArmTransform(class_4587 poseStack, class_1306 humanoidArm, float f) {}
    @Shadow public abstract void renderItem(class_1309 livingEntity, class_1799 itemStack, class_811 itemDisplayContext, class_4587 poseStack, class_11659 submitNodeCollector, int i);
    private int lastSelectedSlot = -1;
    private class_1799 lastSelectedStack = class_1799.field_8037;
    private boolean waitingForWeaponCooldown = false;

    private boolean isEntityInRange() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return false;
        double r = Config.range;
        class_243 pos = client.field_1724.method_73189();
        class_238 area = new class_238(pos.field_1352 - r, pos.field_1351 - r, pos.field_1350 - r, pos.field_1352 + r, pos.field_1351 + r, pos.field_1350 + r);
        List<class_1297> entities = client.field_1687.method_8333(client.field_1724, area, (e) -> e instanceof class_1657 && !e.method_7325() && e.method_5805());
        for (class_1297 entity : entities) {
            if (client.field_1724.method_5739(entity) <= r) {
                return true;
            }
        }
        return false;
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void updateHandPosition(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        class_1799 currentStack = client.field_1724.method_6047();
        int selectedSlot = client.field_1724.method_31548().method_67532();
        if (lastSelectedSlot != -1 && (selectedSlot != lastSelectedSlot || !class_1799.method_7973(currentStack, lastSelectedStack))) {
            waitingForWeaponCooldown = isWeapon(currentStack);
        } else if (client.field_1690.field_1886.method_1434()) {
            waitingForWeaponCooldown = false;
        } else if (waitingForWeaponCooldown && client.field_1724.method_7261(1.0F) >= 0.999F) {
            waitingForWeaponCooldown = false;
        }
        lastSelectedSlot = selectedSlot;
        lastSelectedStack = currentStack.method_7972();
        boolean isSword = currentStack.method_31573(class_3489.field_42611);
        boolean isWeapon = isWeapon(currentStack);
        boolean visibleItemMatches = class_1799.method_7973(currentStack, this.mainHandItem);
        boolean hasTarget = Config.autoMode && isEntityInRange();
        boolean isBlocking = Config.swordBlock && isSword && (client.field_1690.field_1904.method_1434() || hasTarget);
        boolean isEatingSwing = Config.useSwing && client.field_1724.method_6115() && !currentStack.method_31573(class_3489.field_63257);
        boolean shouldSuppressCooldownRaise = Config.noAttackCooldownAnimation && isWeapon && visibleItemMatches && !waitingForWeaponCooldown && !client.field_1724.method_6115();
        if (shouldSuppressCooldownRaise || isBlocking || isEatingSwing || client.field_1755 instanceof SettingsScreen) {
            this.mainHandHeight = 1.0F;
            this.oMainHandHeight = 1.0F;
        }
    }

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void injectOldAnimation(class_742 abstractClientPlayer, float f, float g, class_1268 interactionHand, float h, class_1799 itemStack, float i, class_4587 poseStack, class_11659 submitNodeCollector, int j, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        class_1799 mainHandStack = abstractClientPlayer.method_6047();
        class_1799 offHandStack = abstractClientPlayer.method_6079();

        boolean isSword = mainHandStack.method_31573(class_3489.field_42611);
        boolean hasShield = offHandStack.method_31574(class_1802.field_8255);
        boolean hasTarget = Config.autoMode && isEntityInRange();

        boolean isBlocking = Config.swordBlock && isSword && (client.field_1690.field_1904.method_1434() || hasTarget || client.field_1755 instanceof SettingsScreen);

        if (interactionHand == class_1268.field_5810 && isBlocking && hasShield) {
            ci.cancel();
            return;
        }

        if (interactionHand == class_1268.field_5808) {
            boolean isUseSwinging = Config.useSwing && abstractClientPlayer.method_6115() && !mainHandStack.method_31573(class_3489.field_63257);

            if (isBlocking || isUseSwinging) {
                ci.cancel();
                class_1306 arm = abstractClientPlayer.method_6068();
                int side = arm == class_1306.field_6183 ? 1 : -1;

                poseStack.method_22903();

                if (isBlocking) {
                    poseStack.method_46416(Config.offsetX * side, Config.offsetY, Config.offsetZ);
                    this.applyItemArmTransform(poseStack, arm, 0.0F);

                    if (Config.animationMode == Config.AnimMode.MODE_1_7) {
                        float factor = class_3532.method_15374(class_3532.method_15355(h) * (float) Math.PI);
                        float blend = 1.0F - factor;
                        poseStack.method_46416(side * (-0.139F * blend), 0.06F * blend, 0.20F * blend);

                        poseStack.method_46416(side * 0.430F, -0.190F, 0.520F);
                        poseStack.method_46416(side * -0.141F, 0.08F, -0.72F);
                        float f17 = class_3532.method_15374(h * h * (float) Math.PI);
                        float f22 = class_3532.method_15374(class_3532.method_15355(h) * (float) Math.PI);
                        poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * (45.0F + f17 * -20.0F)));
                        poseStack.method_22907(class_7833.field_40718.rotationDegrees(side * f22 * -20.0F));
                        poseStack.method_22907(class_7833.field_40714.rotationDegrees(f22 * -80.0F));
                        poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * -45.0F));
                        renderOldSwordStance(poseStack, side);
                    } else if (Config.animationMode == Config.AnimMode.MODE_1_7_PLUS) {
                        poseStack.method_46416(side * 0.15F, -0.05F, 0.0F);
                        renderOldSwordStance(poseStack, side);

                        float sqrtSwing = class_3532.method_15355(h);
                        float swingAmount = class_3532.method_15374(sqrtSwing * (float) Math.PI);
                        poseStack.method_22907(class_7833.field_40714.rotationDegrees(swingAmount * -45.0F));
                        poseStack.method_22907(class_7833.field_40718.rotationDegrees(side * swingAmount * 20.0F));
                    } else if (Config.animationMode == Config.AnimMode.MODE_NEW) {
                        poseStack.method_46416(side * 0.15F, -0.05F, 0.0F);
                        renderOldSwordStance(poseStack, side);
                        if (h > 0.0F) {
                            float swingFactor = class_3532.method_15374(class_3532.method_15355(h) * (float) Math.PI);
                            poseStack.method_46416(side * 0.430F * swingFactor, -0.190F * swingFactor, 0.520F * swingFactor);
                            poseStack.method_46416(side * -0.141F * swingFactor, 0.08F * swingFactor, -0.72F * swingFactor);
                            float f17 = class_3532.method_15374(h * h * (float) Math.PI);
                            float f22 = class_3532.method_15374(class_3532.method_15355(h) * (float) Math.PI);
                            poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * (45.0F + f17 * -20.0F)));
                            poseStack.method_22907(class_7833.field_40718.rotationDegrees(side * f22 * -20.0F));
                            poseStack.method_22907(class_7833.field_40714.rotationDegrees(f22 * -80.0F));
                            poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * -45.0F));
                        }
                    } else {
                        poseStack.method_46416(side * 0.15F, -0.05F, 0.0F);
                        renderOldSwordStance(poseStack, side);

                        float sqrtSwing = class_3532.method_15355(h);
                        float swingAmount = class_3532.method_15374(sqrtSwing * (float) Math.PI);
                        poseStack.method_22907(class_7833.field_40718.rotationDegrees(-side * swingAmount * 35.0F));
                        poseStack.method_22907(class_7833.field_40714.rotationDegrees(swingAmount * -10.0F));
                    }
                } else {
                    poseStack.method_46416(side * -0.66F, -0.06F, 0.0F);
                    this.applyItemArmTransform(poseStack, arm, 0.0F);

                    float speedH = h * 1.17F;
                    float f1 = class_3532.method_15374(speedH * (float) Math.PI);
                    float f2 = class_3532.method_15374(class_3532.method_15355(speedH) * (float) Math.PI);
                    poseStack.method_46416(side * -0.4F * f2, 0.4F * f1, -0.3F * f2);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * 180.0F));
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * 45.0F));
                    float f17 = class_3532.method_15374(speedH * speedH * (float) Math.PI);
                    float f22 = class_3532.method_15374(class_3532.method_15355(speedH) * (float) Math.PI);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * (f17 * -20.0F)));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(side * f22 * -20.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(f22 * -80.0F));
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * -45.0F));
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
                }

                class_1799 renderStack = isBlocking ? mainHandStack : itemStack;
                this.renderItem(abstractClientPlayer, renderStack, arm == class_1306.field_6183 ? class_811.field_4322 : class_811.field_4321, poseStack, submitNodeCollector, j);
                poseStack.method_22909();
            }
        }
    }

    private void renderOldSwordStance(class_4587 poseStack, int i) {
        poseStack.method_46416(-0.2F, 0.126F, 0.2F);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(-102.25F));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(i * 15.0F));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(i * 80.0F));
    }

    private boolean isWeapon(class_1799 stack) {
        return stack.method_31573(class_3489.field_42611) || stack.method_31573(class_3489.field_42612) || stack.method_31573(class_3489.field_63257) || stack.method_31573(class_3489.field_63258);
    }
}
