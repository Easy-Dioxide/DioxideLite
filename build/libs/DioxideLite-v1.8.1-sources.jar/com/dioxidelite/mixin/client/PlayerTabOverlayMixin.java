package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.DynamicIslandRenderer;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_332;
import net.minecraft.class_355;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_355.class)
public class PlayerTabOverlayMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void dioxide_lite$dynamicIslandTabList(class_332 guiGraphics, int width, class_269 scoreboard, class_266 objective, CallbackInfo ci) {
        if (!Config.dynamicIsland) {
            return;
        }

        DynamicIslandRenderer.getInstance().requestTabListFrame();
        ci.cancel();
    }
}
