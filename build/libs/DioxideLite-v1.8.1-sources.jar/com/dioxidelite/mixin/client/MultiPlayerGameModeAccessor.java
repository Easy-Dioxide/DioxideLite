package com.dioxidelite.mixin.client;

import net.minecraft.class_2338;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_636.class)
public interface MultiPlayerGameModeAccessor {
    @Accessor("destroyProgress")
    float dioxideLite$getDestroyProgress();

    @Accessor("destroyDelay")
    int dioxideLite$getDestroyDelay();

    @Accessor("isDestroying")
    boolean dioxideLite$isDestroying();

    @Accessor("destroyBlockPos")
    class_2338 dioxideLite$getDestroyBlockPos();
}
