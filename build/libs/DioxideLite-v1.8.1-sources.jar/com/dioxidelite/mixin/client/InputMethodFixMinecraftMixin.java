package com.dioxidelite.mixin.client;

import com.dioxidelite.client.modules.impl.Optimize.InputMethodFix.InputMethodFix;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class InputMethodFixMinecraftMixin {
    @Shadow public net.minecraft.class_437 screen;

    @Inject(method = "setWindowActive", at = @At("TAIL"))
    private void dioxide_lite$onWindowActiveChanged(boolean active, CallbackInfo ci) {
        InputMethodFix.onWindowActiveChanged(active, (class_310) (Object) this);
    }

    @Inject(method = "setScreen", at = @At("TAIL"))
    private void dioxide_lite$onScreenChanged(class_437 screen, CallbackInfo ci) {
        InputMethodFix.onScreenChanged(screen, (class_310) (Object) this);
    }
}
