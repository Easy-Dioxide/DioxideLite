package com.dioxidelite.mixin.client;

import com.dioxidelite.client.util.NameTagPlayerFilterState;
import net.minecraft.class_10017;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_10017.class)
public class EntityRenderStateMixin implements NameTagPlayerFilterState {
    @Unique private boolean dioxide_lite$nameTagRealPlayer = true;

    @Override
    public void dioxide_lite$setNameTagRealPlayer(boolean realPlayer) {
        dioxide_lite$nameTagRealPlayer = realPlayer;
    }

    @Override
    public boolean dioxide_lite$isNameTagRealPlayer() {
        return dioxide_lite$nameTagRealPlayer;
    }
}
