package com.dioxidelite.mixin.client;

import com.dioxidelite.client.util.NameTagPlayerFilterState;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_634;
import net.minecraft.class_640;
import net.minecraft.class_897;
import com.dioxidelite.client.util.NameTagPlayerFilterContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public class EntityRendererMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void dioxide_lite$captureNameTagPlayerFilter(class_1297 entity, class_10017 state, float tickProgress, CallbackInfo ci) {
        ((NameTagPlayerFilterState) state).dioxide_lite$setNameTagRealPlayer(isRealPlayer(entity));
    }

    @Inject(method = "submitNameTag", at = @At("HEAD"))
    private void dioxide_lite$beginNameTagPlayerFilter(class_10017 state, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo ci) {
        NameTagPlayerFilterContext.setRealPlayer(((NameTagPlayerFilterState) state).dioxide_lite$isNameTagRealPlayer());
    }

    @Inject(method = "submitNameTag", at = @At("RETURN"))
    private void dioxide_lite$endNameTagPlayerFilter(class_10017 state, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo ci) {
        NameTagPlayerFilterContext.clear();
    }

    private static boolean isRealPlayer(class_1297 entity) {
        if (!(entity instanceof class_1657)) return false;

        class_634 connection = class_310.method_1551().method_1562();
        if (connection == null) return true;

        class_640 info = connection.method_2871(entity.method_5667());
        return info != null;
    }
}
