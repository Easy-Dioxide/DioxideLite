package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public abstract class LocalPlayerEyeHeightMixin {
    @Inject(method = "getEyeHeight", at = @At("HEAD"), cancellable = true)
    private void modifyFastSneakEyeHeight(class_4050 pose, CallbackInfoReturnable<Float> cir) {
        if (!((Object) this instanceof class_746 player)) {
            return;
        }

        if (!Config.noSneakAnimation || class_310.method_1551().field_1724 != player || pose != class_4050.field_18081) {
            return;
        }

        if (!((PlayerPoseAccessMixin) player).dioxideLite$canPlayerFitWithinBlocksAndEntitiesWhen(class_4050.field_18076)) {
            return;
        }

        float crouchingEyeHeight = player.method_18377(class_4050.field_18081).comp_2187();
        float standingEyeHeight = player.method_18377(class_4050.field_18076).comp_2187();
        float sneakDrop = standingEyeHeight - crouchingEyeHeight;
        cir.setReturnValue(standingEyeHeight - sneakDrop * Config.sneakDropScale);
    }

    @Inject(method = "getEyeHeight()F", at = @At("HEAD"), cancellable = true)
    private void modifyFastSneakCurrentEyeHeight(CallbackInfoReturnable<Float> cir) {
        if (!((Object) this instanceof class_746 player)) {
            return;
        }

        if (!Config.noSneakAnimation || class_310.method_1551().field_1724 != player || player.method_18376() != class_4050.field_18081) {
            return;
        }

        if (!((PlayerPoseAccessMixin) player).dioxideLite$canPlayerFitWithinBlocksAndEntitiesWhen(class_4050.field_18076)) {
            return;
        }

        float crouchingEyeHeight = player.method_18377(class_4050.field_18081).comp_2187();
        float standingEyeHeight = player.method_18377(class_4050.field_18076).comp_2187();
        float sneakDrop = standingEyeHeight - crouchingEyeHeight;
        cir.setReturnValue(standingEyeHeight - sneakDrop * Config.sneakDropScale);
    }
}
