package com.dioxidelite.mixin.client;

import net.minecraft.class_10151;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10151.class)
public interface ShaderManagerAccessor {
    @Accessor class_10151.class_10170 getCompilationCache();
}
