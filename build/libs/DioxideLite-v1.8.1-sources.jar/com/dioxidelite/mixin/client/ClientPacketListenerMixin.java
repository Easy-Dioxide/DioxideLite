package com.dioxidelite.mixin.client;

import com.dioxidelite.client.modules.impl.Combat.HitMarkerRenderer;
import com.dioxidelite.client.modules.impl.Render.TargetHudRenderer;
import com.dioxidelite.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1676;
import net.minecraft.class_2739;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_8143;

@Mixin(class_634.class)
public class ClientPacketListenerMixin {
    @Redirect(method = "handleSetEntityData", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/protocol/game/ClientboundSetEntityDataPacket;packedItems()Ljava/util/List;", ordinal = 0))
    private List<class_2945.class_7834<?>> fixLocalPlayerPoseTracker(class_2739 packet) {
        class_310 client = class_310.method_1551();
        if (Config.noDoubleSneak && client.field_1687 != null && client.field_1724 != null) {
            class_1297 entity = client.field_1687.method_8469(packet.comp_1127());
            if (entity == client.field_1724) {
                packet.comp_1128().removeIf(value -> value.comp_1116().equals(class_2943.field_18238));
            }
        }

        return packet.comp_1128();
    }

    @Inject(method = "handleDamageEvent", at = @At("HEAD"))
    private void onDamageEvent(class_8143 packet, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null && client.field_1724 != null) {
            class_1297 target = client.field_1687.method_8469(packet.comp_1267());
            if (target instanceof class_1309 livingTarget && packet.comp_1269() == client.field_1724.method_5628()) {
                class_1297 source = client.field_1687.method_8469(packet.comp_1270());
                boolean isRanged = source instanceof class_1676;

                boolean isCrit = !isRanged &&
                        client.field_1724.field_6017 > 0.0f &&
                        !client.field_1724.method_24828();

                int colorValue = 0xFFFFFF;
                if (isCrit) {
                    colorValue = 0xFF0000;
                } else if (isRanged) {
                    colorValue = 0x00FF00;
                }

                final int finalColor = colorValue;
                client.execute(() -> {
                    HitMarkerRenderer.getInstance().onHit(isRanged, finalColor);
                    TargetHudRenderer.getInstance().onHit(livingTarget);
                });
            }
        }
    }

}
