package com.dioxidelite.mixin.client;

import com.dioxidelite.client.modules.impl.Tool.BlockCountDisplayRenderer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1838;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1747.class)
public class BlockItemMixin {
    @Inject(method = "useOn", at = @At("RETURN"))
    private void recordBlockCountPlacement(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        class_1657 player = context.method_8036();
        if (player == class_310.method_1551().field_1724
                && context.method_20287() == class_1268.field_5808
                && cir.getReturnValue().method_23665()) {
            BlockCountDisplayRenderer.getInstance().recordPlacement(class_310.method_1551());
        }
    }
}
