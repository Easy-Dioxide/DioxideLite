package com.dioxidelite.mixin.client;

import com.mojang.brigadier.Message;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_338;

@Mixin(class_338.class)
public interface ChatHudAccessor {
    @Accessor("trimmedMessages")
    List<Message> getVisibleMessages();
}
