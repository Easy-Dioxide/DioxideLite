package com.dioxidelite.mixin.client;

import com.dioxidelite.client.modules.impl.Render.motionblur.MotionBlurManager;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class MotionBlurGameRendererMixin {
    @Inject(method = "renderLevel", at = @At("TAIL"))
    private void dioxide_lite$afterRenderLevel(class_9779 deltaTracker, CallbackInfo ci) {
        MotionBlurManager.applyTemporalBlur();
        MotionBlurManager.clearFrameAllocator();
    }
}
