package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true)
    private void hideHurtShake(class_4587 poseStack, float tickProgress, CallbackInfo ci) {
        if (Config.hideHurtShake) ci.cancel();
    }
}
