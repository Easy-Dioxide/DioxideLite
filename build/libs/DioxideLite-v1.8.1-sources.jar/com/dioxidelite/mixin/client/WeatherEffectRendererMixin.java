package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_12077;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_4066;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_9976;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9976.class)
public class WeatherEffectRendererMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void dioxide_lite$hideRainColumns(class_1937 level, int ticks, float partialTick, class_243 cameraPosition, class_12077 state, CallbackInfo ci) {
        if (Config.hideRainParticles) {
            state.field_63101.clear();
        }
    }

    @Inject(method = "tickRainParticles", at = @At("HEAD"), cancellable = true)
    private void dioxide_lite$hideRainDrops(class_638 level, class_4184 camera, int ticks, class_4066 particleStatus, int particleCount, CallbackInfo ci) {
        if (Config.hideRainParticles) {
            ci.cancel();
        }
    }
}
