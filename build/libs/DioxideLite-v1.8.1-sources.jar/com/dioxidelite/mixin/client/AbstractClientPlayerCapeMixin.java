package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.CustomCapeManager;
import net.minecraft.class_12079;
import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerCapeMixin {
    private static boolean logged;

    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void dioxide_lite$customCape(CallbackInfoReturnable<class_8685> cir) {
        if (!Config.customCape) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || (Object) this != client.field_1724) return;
        class_12079.class_12081 cape = CustomCapeManager.texture();
        if (cape == null) return;
        class_8685 skin = cir.getReturnValue();
        if (!logged) {
            logged = true;
            System.out.println("[DioxideLite] CustomCape mixin applied: " + cape.comp_3627());
        }
        cir.setReturnValue(class_8685.method_74884(skin.comp_1626(), cape, cape, skin.comp_1629()));
    }
}
