package com.dioxidelite.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_765;
import com.dioxidelite.client.modules.impl.Render.GammaOverrideManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_765.class)
public abstract class LightTextureMixin {
    @ModifyExpressionValue(
            method = "updateLightTexture",
            at = @At(value = "INVOKE", target = "Ljava/lang/Double;floatValue()F", ordinal = 1)
    )
    private float overrideGamma(float gamma) {
        return GammaOverrideManager.apply(gamma);
    }
}
