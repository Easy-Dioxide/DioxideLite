package com.dioxidelite.mixin.client;

import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(targets = "net.minecraft.client.gui.components.ChatComponent$DrawingFocusedGraphicsAccess")
public interface ChatComponentDrawingFocusedGraphicsAccessor {
    @Accessor("graphics")
    class_332 dioxide_lite$getGraphics();
}
