package com.dioxidelite.mixin.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import java.util.Map;
import net.minecraft.class_283;

@Mixin(class_283.class)
public interface PostPassAccessor {
    @Accessor Map<String, GpuBuffer> getCustomUniforms();
    @Accessor List<class_283.class_9971> getInputs();
}
