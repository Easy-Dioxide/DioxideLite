package com.dioxidelite.mixin.client;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.dioxidelite.Config;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import org.joml.Matrix3x2fStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value = class_329.class, priority = 999)
public class HotbarSmoothMixin {
    @Unique private static final int SLOT_WIDTH = 20;
    @Unique private static final int SLOT_COUNT = 9;
    @Unique private static final int ROLLOVER_SPACE = 4;
    @Unique private float dioxide_lite$smoothSelectorPos;

    @WrapMethod(method = "renderHotbarAndDecorations")
    private void dioxide_lite$wrapHotbarAndDecorations(class_332 graphics, class_9779 deltaTracker, Operation<Void> operation) {
        if (!Config.smoothHotbarScrolling) {
            operation.call(graphics, deltaTracker);
            return;
        }
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null) {
            operation.call(graphics, deltaTracker);
            return;
        }

        float target = getTargetPosition(player.method_31548().method_67532(), Config.hotbarRollover);
        float smoothness = Math.min(0.99f, Math.max(0.05f, Config.smoothHotbarAnimationSpeed));
        dioxide_lite$smoothSelectorPos += (target - dioxide_lite$smoothSelectorPos) * (1f - (float) Math.pow(smoothness, deltaTracker.method_60638()));

        operation.call(graphics, deltaTracker);
    }

    @WrapOperation(
            method = "renderItemHotbar",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V", ordinal = 1)
    )
    private void dioxide_lite$moveSelector(class_332 graphics, RenderPipeline pipeline, class_2960 texture, int x, int y, int width, int height, Operation<Void> operation) {
        if (!Config.smoothHotbarScrolling) {
            operation.call(graphics, pipeline, texture, x, y, width, height);
            return;
        }
        Matrix3x2fStack pose = graphics.method_51448();
        pose.pushMatrix();
        int selectedSlot = class_310.method_1551().field_1724 != null ? class_310.method_1551().field_1724.method_31548().method_67532() : 0;
        pose.translate(dioxide_lite$smoothSelectorPos - (selectedSlot * SLOT_WIDTH), 0f);
        operation.call(graphics, pipeline, texture, x, y, width, height);
        pose.popMatrix();
    }

    @Unique
    private static float getTargetPosition(int selectedSlot, int rollover) {
        return (selectedSlot + rollover * SLOT_COUNT) * SLOT_WIDTH;
    }
}
