package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public class LivingEntityTotemMixin {
    @Inject(method = "handleEntityEvent", at = @At("HEAD"), cancellable = true)
    private void hideTotemAnimation(byte flag, CallbackInfo ci) {
        if (Config.hideTotemAnimation && flag == 35) {
            ci.cancel();
        }
    }
}
