package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Tool.AutoChestDepositManager;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
public class KeyboardInputMixin extends class_744 {
    @Inject(method = "tick", at = @At("TAIL"))
    private void blockMovementWhileDepositing(CallbackInfo ci) {
        if (AutoChestDepositManager.shouldBlockMovementInput()) {
            this.field_54155 = class_10185.field_54098;
            this.field_55868 = class_241.field_1340;
            return;
        }

        if (Config.autoSprint && this.field_54155.comp_3159() && !this.field_54155.comp_3164()) {
            this.field_54155 = new class_10185(
                    this.field_54155.comp_3159(),
                    this.field_54155.comp_3160(),
                    this.field_54155.comp_3161(),
                    this.field_54155.comp_3162(),
                    this.field_54155.comp_3163(),
                    this.field_54155.comp_3164(),
                    true
            );
        }
    }
}
