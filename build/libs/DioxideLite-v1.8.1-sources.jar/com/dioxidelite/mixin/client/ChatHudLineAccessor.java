package com.dioxidelite.mixin.client;

import net.minecraft.class_303;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_303.class)
public interface ChatHudLineAccessor {
    @Accessor("addedTime")
    int getCreationTick();
}
