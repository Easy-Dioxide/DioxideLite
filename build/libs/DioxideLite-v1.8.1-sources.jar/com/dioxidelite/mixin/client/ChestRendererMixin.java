package com.dioxidelite.mixin.client;

import com.dioxidelite.client.modules.impl.Tool.AutoChestDepositManager;
import net.minecraft.class_11683;
import net.minecraft.class_11959;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_826;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_826.class)
public class ChestRendererMixin {
    @Inject(method = "extractRenderState(Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/client/renderer/blockentity/state/ChestRenderState;FLnet/minecraft/world/phys/Vec3;Lnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V", at = @At("HEAD"))
    private void captureRenderedChest(class_2586 blockEntity, class_11959 state, float tickProgress, class_243 cameraPos, class_11683.class_11792 crumblingOverlay, CallbackInfo ci) {
        if (blockEntity instanceof class_2595 chest) {
            AutoChestDepositManager.onChestRendered(chest);
        }
    }
}
