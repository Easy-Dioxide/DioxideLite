package com.dioxidelite.mixin.client;

import com.dioxidelite.client.gui.clickgui.ClickGuiThemeController;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_465;
import com.dioxidelite.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin extends class_437 {
    protected AbstractContainerScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void addGlobalSettingsButton(CallbackInfo ci) {
        this.method_37063(class_4185.method_46430(class_2561.method_43470("DioxideLite"), (button) -> {
            Config.applyFirstUseLanguageDefault();
            if (this.field_22787 != null) this.field_22787.method_1507(ClickGuiThemeController.create(Config.clickGuiTheme, this));
        }).method_46434(this.field_22789 - 82, 2, 80, 20).method_46431());
    }
}
