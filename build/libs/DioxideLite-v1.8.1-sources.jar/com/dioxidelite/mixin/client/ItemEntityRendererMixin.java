package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.util.ItemPhysicsRenderState;
import net.minecraft.class_10039;
import net.minecraft.class_10442;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1542;
import net.minecraft.class_1747;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
public class ItemEntityRendererMixin {
    @Shadow private class_10442 itemModelResolver;
    @Unique private class_10039 dioxide_lite$currentItemState;

    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;F)V", at = @At("TAIL"))
    private void dioxide_lite$extractItemPhysics(class_1542 itemEntity, class_10039 state, float tickProgress, CallbackInfo ci) {
        boolean blockItem = itemEntity.method_6983().method_7909() instanceof class_1747;
        if (Config.item2DRender && !blockItem) {
            this.itemModelResolver.method_65595(state.field_55310, itemEntity.method_6983(), class_811.field_4317, itemEntity);
        }
        class_243 delta = itemEntity.method_18798();
        boolean moving = delta.method_37268() > 2.5E-3 || Math.abs(delta.field_1351) > 0.04;
        ((ItemPhysicsRenderState) state).dioxide_lite$setItemPhysics(itemEntity.method_24828(), moving, blockItem, itemEntity.method_5667().hashCode());
    }

    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V", at = @At("HEAD"))
    private void dioxide_lite$beginItemPhysics(class_10039 state, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo ci) {
        dioxide_lite$currentItemState = state;
    }

    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V", at = @At("RETURN"))
    private void dioxide_lite$endItemPhysics(class_10039 state, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo ci) {
        dioxide_lite$currentItemState = null;
    }

    @Redirect(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/item/ItemEntity;getSpin(FF)F")
    )
    private float dioxide_lite$replaceItemSpin(float ageInTicks, float bobOffset) {
        if (Config.item2DRender && dioxide_lite$currentItemState != null && !((ItemPhysicsRenderState) dioxide_lite$currentItemState).dioxide_lite$itemPhysicsBlockItem()) {
            return 0.0f;
        }
        if (!Config.itemPhysics || dioxide_lite$currentItemState == null) {
            return class_1542.method_27314(ageInTicks, bobOffset);
        }

        ItemPhysicsRenderState state = (ItemPhysicsRenderState) dioxide_lite$currentItemState;
        if (state.dioxide_lite$itemPhysicsOnGround()) {
            return stableAngleRad(state.dioxide_lite$itemPhysicsSeed(), 0);
        }
        return ageInTicks * 0.32f * Config.itemPhysicsRotationSpeed + stableAngleRad(state.dioxide_lite$itemPhysicsSeed(), 1);
    }

    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/ItemEntityRenderer;submitMultipleFromCount(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/ItemClusterRenderState;Lnet/minecraft/util/RandomSource;Lnet/minecraft/world/phys/AABB;)V")
    )
    private void dioxide_lite$applyItemPhysicsPose(class_10039 state, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo ci) {
        if (Config.item2DRender && !((ItemPhysicsRenderState) state).dioxide_lite$itemPhysicsBlockItem()) {
            poseStack.method_22907(cameraRenderState.field_63081);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0f));
            poseStack.method_22905(0.55f, 0.55f, 0.55f);
            return;
        }
        if (!Config.itemPhysics) {
            return;
        }

        ItemPhysicsRenderState physics = (ItemPhysicsRenderState) state;
        if (physics.dioxide_lite$itemPhysicsOnGround()) {
            float bob = (float) Math.sin(state.field_53328 / 10.0f + state.field_53435) * 0.1f + 0.1f;
            class_238 box = state.field_55310.method_72173();
            float groundOffset = box.method_17941() > 0.0625 ? 0.0125f : -0.1200f;
            poseStack.method_46416(0.0f, -bob + groundOffset, 0.0f);
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0f));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(stableAngleDeg(physics.dioxide_lite$itemPhysicsSeed(), 2) * 0.08f - 14.4f));
        } else {
            float age = state.field_53328;
            float speed = Config.itemPhysicsRotationSpeed;
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(age * 9.5f * speed + stableAngleDeg(physics.dioxide_lite$itemPhysicsSeed(), 3)));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(age * 6.0f * speed + stableAngleDeg(physics.dioxide_lite$itemPhysicsSeed(), 4)));
        }
    }

    @Unique
    private float stableAngleRad(int seed, int salt) {
        return (float) Math.toRadians(stableAngleDeg(seed, salt));
    }

    @Unique
    private float stableAngleDeg(int seed, int salt) {
        int mixed = seed ^ (salt * 0x9E3779B9);
        mixed ^= mixed >>> 16;
        mixed *= 0x7FEB352D;
        mixed ^= mixed >>> 15;
        return (mixed & 0xFFFF) / 65535.0f * 360.0f;
    }
}
