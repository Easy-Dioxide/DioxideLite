package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.LowHealthHandler;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {
    @Shadow public int swingTime;
    @Shadow public abstract float getHealth();

    @Inject(method = "tick", at = @At("HEAD"))
    private void checkLowHealth(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if ((Object) this == client.field_1724) {
            LowHealthHandler.onHealthUpdate(client, this.getHealth());
        }
    }

    @Inject(method = "getCurrentSwingDuration", at = @At("RETURN"), cancellable = true)
    private void modifySwingDuration(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this instanceof class_1657) {
            int original = cir.getReturnValue();
            cir.setReturnValue((int) (original / Config.animSpeed));
        }
    }

    @Inject(method = "swing(Lnet/minecraft/world/InteractionHand;Z)V", at = @At("HEAD"), cancellable = true)
    private void preventSwingReset(CallbackInfo ci) {
        if ((Object) this instanceof class_1657 && this.swingTime > 0 && Config.animSpeed < 1.0f) {
            ci.cancel();
        }
    }

    @Inject(method = "isUsingItem", at = @At("HEAD"), cancellable = true)
    private void trickIsUsingItemForSwing(CallbackInfoReturnable<Boolean> cir) {
        if (Config.useSwing && (Object) this instanceof class_1657) {
            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            for (StackTraceElement element : stackTrace) {
                String methodName = element.getMethodName();
                if (methodName.equals("swing") || methodName.equals("m_6674_") ||
                        methodName.contains("attack") || methodName.contains("handleAttack")) {
                    cir.setReturnValue(false);
                    return;
                }
            }
        }
    }
}
