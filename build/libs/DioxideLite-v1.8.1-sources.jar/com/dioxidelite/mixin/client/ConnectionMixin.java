package com.dioxidelite.mixin.client;

import net.minecraft.class_2535;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2535.class)
public class ConnectionMixin {
}
