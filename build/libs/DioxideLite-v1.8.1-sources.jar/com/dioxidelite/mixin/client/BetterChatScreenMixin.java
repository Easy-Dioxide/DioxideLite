package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.BetterChat.BetterChatState;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_408.class)
public class BetterChatScreenMixin {
    @Unique private final class_310 client = class_310.method_1551();

    @Inject(method = "render", at = @At("HEAD"))
    private void dioxide_lite$renderStart(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!Config.betterChat || !Config.betterChatInputAnimation) return;
        BetterChatState.getInstance().beginChatScreenIfNeeded(client);
        context.method_51448().translate(0, BetterChatState.getInstance().calculateChatScreenOffsetY(client));
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void dioxide_lite$renderEnd(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!Config.betterChat || !Config.betterChatInputAnimation) return;
        if (BetterChatState.getInstance().shouldCloseChatScreen() && client != null) {
            client.method_1507(null);
        }
    }

    @Inject(method = "onClose", at = @At("HEAD"))
    private void dioxide_lite$onClose(CallbackInfo ci) {
        if (!Config.betterChat || !Config.betterChatInputAnimation) return;
        if (BetterChatState.getInstance().hasActiveChatMessages(client)) {
            return;
        }
        BetterChatState.getInstance().startClosing();
    }

    @Inject(method = "removed", at = @At("HEAD"))
    private void dioxide_lite$removed(CallbackInfo ci) {
        BetterChatState.getInstance().resetChatScreenState();
    }
}
