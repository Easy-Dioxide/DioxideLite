package com.dioxidelite.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.BetterChat.BetterChatState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_338;
import net.minecraft.class_7469;
import net.minecraft.class_7591;

@Mixin(class_338.class)
public abstract class BetterChatChatMixin {
    private static final int CHAT_HEAD_SIZE = 8;
    private static final int CHAT_HEAD_GAP = 2;
    private static final int CHAT_HEAD_SHIFT = CHAT_HEAD_SIZE + CHAT_HEAD_GAP;
    @Shadow private int chatScrollbarPos;
    @Shadow @Final private List<class_303.class_7590> trimmedMessages;
    @Shadow private int getLineHeight() { return 0; }

    @ModifyReturnValue(method = "getWidth", at = @At("RETURN"))
    private int dioxide_lite$extendWidthForAvatars(int original) {
        return Config.betterChat && Config.betterChatAvatar ? original + CHAT_HEAD_SHIFT : original;
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void dioxide_lite$chatRenderStart(class_332 context, class_327 font, int currentTick, int mouseX, int mouseY, boolean focused, boolean open, CallbackInfo ci) {
        if (!Config.betterChat || !Config.betterChatMessageAnimation) return;
        int offset = BetterChatState.getInstance().calculateChatDisplacementY(this.getLineHeight(), this.chatScrollbarPos);
        context.method_51448().translate(0, offset);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void dioxide_lite$chatRenderEnd(class_332 context, class_327 font, int currentTick, int mouseX, int mouseY, boolean focused, boolean open, CallbackInfo ci) {
        if (!Config.betterChat || !Config.betterChatMessageAnimation) return;
        int offset = BetterChatState.getInstance().calculateChatDisplacementY(this.getLineHeight(), this.chatScrollbarPos);
        context.method_51448().translate(0, -offset);
    }

    @Inject(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V", at = @At("TAIL"))
    private void dioxide_lite$onAddMessage(class_2561 message, class_7469 signatureData, class_7591 indicator, CallbackInfo ci) {
        if (!Config.betterChat || !Config.betterChatMessageAnimation) return;
        BetterChatState.getInstance().recordMessage();
        BetterChatState.getInstance().trimMessageCount(this.trimmedMessages.size());
    }
}
