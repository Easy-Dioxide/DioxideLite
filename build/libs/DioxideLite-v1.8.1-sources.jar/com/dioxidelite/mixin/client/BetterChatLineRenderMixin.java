package com.dioxidelite.mixin.client;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_338;
import net.minecraft.class_7532;
import net.minecraft.class_8685;
import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.BetterChat.BetterChatLineProfileAccessor;
import com.dioxidelite.client.modules.impl.Render.BetterChat.BetterChatRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(targets = "net.minecraft.client.gui.components.ChatComponent$1")
public abstract class BetterChatLineRenderMixin {
    @Shadow @Final private int val$chatBottom;
    @Shadow @Final private int val$entryHeight;
    @Shadow @Final private int val$entryBottomToMessageY;
    @Shadow @Final private class_338.class_12233 val$graphics;
    @Shadow @Final private class_338 field_63873;

    @Unique private static final int AVATAR_SIZE = 8;
    @Unique private static final int AVATAR_GAP = 2;
    @Unique private static final int LINE_SHIFT = AVATAR_SIZE + AVATAR_GAP;
    @Unique private static final int AVATAR_X = 0;

    @Unique
    private boolean dioxide_lite$hasAvatar(class_303.class_7590 line) {
        if (!Config.betterChat || !Config.betterChatAvatar || line == null) return false;
        BetterChatLineProfileAccessor lineAccessor = (BetterChatLineProfileAccessor) (Object) line;
        return lineAccessor.dioxide_lite$getOwnerProfile() != null;
    }

    @Inject(method = "accept", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;handleMessage(IFLnet/minecraft/util/FormattedCharSequence;)Z"))
    private void dioxide_lite$beginAvatarTextShift(class_303.class_7590 line, int index, float alpha, CallbackInfo ci) {
        BetterChatRenderState.setShiftingAvatarLine(dioxide_lite$hasAvatar(line));
    }

    @Inject(method = "accept", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;handleMessage(IFLnet/minecraft/util/FormattedCharSequence;)Z", shift = At.Shift.AFTER))
    private void dioxide_lite$endAvatarTextShift(class_303.class_7590 line, int index, float alpha, CallbackInfo ci) {
        BetterChatRenderState.setShiftingAvatarLine(false);
    }

    @ModifyArgs(method = "accept", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;handleMessage(IFLnet/minecraft/util/FormattedCharSequence;)Z"))
    private void dioxide_lite$shiftMessageX(Args args, class_303.class_7590 line, int index, float alpha) {
        if (!Config.betterChat || !Config.betterChatAvatar) return;
        BetterChatLineProfileAccessor lineAccessor = line == null ? null : (BetterChatLineProfileAccessor) (Object) line;
        GameProfile profile = lineAccessor == null ? null : lineAccessor.dioxide_lite$getOwnerProfile();
        if (profile != null && lineAccessor.dioxide_lite$shouldDrawAvatar()) {
            int lineBottom = this.val$chatBottom - index * this.val$entryHeight;
            int lineTop = lineBottom - this.val$entryHeight;
            int avatarY = lineTop + ((this.val$entryHeight - AVATAR_SIZE) / 2);

            class_310 client = ((ChatComponentAccessor) this.field_63873).dioxide_lite$getMinecraft();
            if (client != null) {
                try {
                    class_332 graphics = this.dioxide_lite$getGraphics();
                    class_8685 skin = client.method_1582().method_73544(profile, false).get();
                    class_7532.method_52722(graphics, skin, AVATAR_X, avatarY, AVATAR_SIZE);
                } catch (Throwable ignored) {
                }
            }
        }
    }

    @Unique
    private class_332 dioxide_lite$getGraphics() {
        if (this.val$graphics instanceof ChatComponentDrawingBackgroundGraphicsAccessor background) {
            return background.dioxide_lite$getGraphics();
        }
        if (this.val$graphics instanceof ChatComponentDrawingFocusedGraphicsAccessor focused) {
            return focused.dioxide_lite$getGraphics();
        }
        throw new IllegalStateException("Unsupported ChatGraphicsAccess: " + this.val$graphics.getClass().getName());
    }

    @ModifyArgs(method = "accept", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;handleTag(IIIIFLnet/minecraft/client/GuiMessageTag;)V"))
    private void dioxide_lite$shiftTagX(Args args, class_303.class_7590 line, int index, float alpha) {
    }

    @ModifyArgs(method = "accept", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;handleTagIcon(IIZLnet/minecraft/client/GuiMessageTag;Lnet/minecraft/client/GuiMessageTag$Icon;)V"))
    private void dioxide_lite$shiftTagIconX(Args args, class_303.class_7590 line, int index, float alpha) {
    }
}
