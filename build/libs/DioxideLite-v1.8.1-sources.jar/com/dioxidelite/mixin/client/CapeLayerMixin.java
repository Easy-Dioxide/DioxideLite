package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.CustomCapeManager;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12079;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_8685;
import net.minecraft.class_972;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_972.class)
public abstract class CapeLayerMixin {
    private static boolean logged;

    @Inject(method = "submit", at = @At("HEAD"))
    private void dioxide_lite$customCape(class_4587 poseStack, class_11659 collector, int light, class_10055 state, float limbSwing, float limbSwingAmount, CallbackInfo ci) {
        if (!Config.customCape || state == null) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || state.field_53528 != client.field_1724.method_5628()) return;
        class_12079.class_12081 cape = CustomCapeManager.texture();
        if (cape == null) return;
        class_8685 skin = state.field_53520;
        if (skin == null) return;
        state.field_53520 = class_8685.method_74884(skin.comp_1626(), cape, cape, skin.comp_1629());
        state.field_53532 = true;
        if (!logged) {
            logged = true;
            System.out.println("[DioxideLite] CustomCape CapeLayer override applied: " + cape.comp_3627());
        }
    }
}
