package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_758.class)
public abstract class FogRendererMixin {
    @Shadow @Final private GpuBuffer emptyBuffer;

    @Inject(method = "getBuffer", at = @At("HEAD"), cancellable = true)
    private void dioxide_lite$useEmptyWorldFogBuffer(class_758.class_4596 fogMode, CallbackInfoReturnable<GpuBufferSlice> cir) {
        if (Config.hideFog && fogMode == class_758.class_4596.field_60102) {
            cir.setReturnValue(this.emptyBuffer.slice(0L, class_758.field_60096));
        }
    }
}
