package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_10529;
import net.minecraft.class_11659;
import net.minecraft.class_11971;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_10529.class)
public abstract class AbstractSignRendererMixin {
    @Inject(method = "submitSignText", at = @At("HEAD"), cancellable = true)
    private void hideSignText(class_11971 state, class_4587 poseStack, class_11659 submitNodeCollector, boolean front, CallbackInfo ci) {
        if (Config.hideSignText) ci.cancel();
    }
}
