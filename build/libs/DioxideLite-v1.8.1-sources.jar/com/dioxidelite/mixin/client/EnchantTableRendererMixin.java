package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_11659;
import net.minecraft.class_11964;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_828.class)
public abstract class EnchantTableRendererMixin {
    @Inject(method = "submit(Lnet/minecraft/client/renderer/blockentity/state/EnchantTableRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V", at = @At("HEAD"), cancellable = true)
    private void hideEnchantTableBook(class_11964 state, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo ci) {
        if (Config.hideEnchantTableBook) ci.cancel();
    }
}
