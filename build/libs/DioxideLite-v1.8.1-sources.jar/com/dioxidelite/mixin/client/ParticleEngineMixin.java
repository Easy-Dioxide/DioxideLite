package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_702.class)
public class ParticleEngineMixin {
    @Inject(method = "createParticle", at = @At("HEAD"), cancellable = true)
    private void hideExplosionParticles(class_2394 particleOptions, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<class_703> cir) {
        if (shouldHideParticle(particleOptions)) {
            cir.setReturnValue(null);
        }
    }

    private boolean shouldHideParticle(class_2394 particleOptions) {
        return (Config.hideExplosionParticles && isExplosionParticle(particleOptions))
                || (Config.hideRainParticles && isRainParticle(particleOptions));
    }

    private boolean isExplosionParticle(class_2394 particleOptions) {
        return particleOptions == class_2398.field_11236
                || particleOptions == class_2398.field_11221
                || particleOptions == class_2398.field_11203
                || particleOptions == class_2398.field_11251
                || particleOptions == class_2398.field_11237;
    }

    private boolean isRainParticle(class_2394 particleOptions) {
        return particleOptions == class_2398.field_11242
                || particleOptions == class_2398.field_11232
                || particleOptions == class_2398.field_18306;
    }
}
