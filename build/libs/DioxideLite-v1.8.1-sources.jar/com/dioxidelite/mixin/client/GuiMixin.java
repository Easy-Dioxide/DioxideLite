package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Tool.TitleDetector;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import com.dioxidelite.client.modules.impl.Render.NotificationOverlay;
import com.dioxidelite.client.modules.impl.Combat.HitMarkerRenderer;
import com.dioxidelite.client.modules.impl.Render.KeystrokesRenderer;
import com.dioxidelite.client.modules.impl.Render.ArmorHudRenderer;
import com.dioxidelite.client.modules.impl.Render.PotionStatusRenderer;
import com.dioxidelite.client.modules.impl.Render.TargetHudRenderer;
import com.dioxidelite.client.modules.impl.Render.FallDamagePredictor;
import com.dioxidelite.client.modules.impl.Render.DiggingStatusRenderer;
import com.dioxidelite.client.modules.impl.Render.DynamicIslandRenderer;
import com.dioxidelite.client.modules.impl.Render.HudEditOverlay;
import com.dioxidelite.client.modules.impl.Render.DioxideLiteVisualOverlay;
import com.dioxidelite.client.modules.impl.Tool.BlockCountDisplayRenderer;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class GuiMixin {

    @Inject(method = "setTitle", at = @At("HEAD"))
    private void onSetTitle(class_2561 title, CallbackInfo ci) {
        TitleDetector.check(title != null ? title.getString() : null, null);
    }

    @Inject(method = "setSubtitle", at = @At("HEAD"))
    private void onSetSubtitle(class_2561 subtitle, CallbackInfo ci) {
        TitleDetector.check(null, subtitle != null ? subtitle.getString() : null);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
        NotificationOverlay.getInstance().render(guiGraphics);
        HitMarkerRenderer.getInstance().render(guiGraphics);
        TargetHudRenderer.getInstance().render(guiGraphics);
        DynamicIslandRenderer.getInstance().render(guiGraphics);
        FallDamagePredictor.getInstance().render(guiGraphics);
        DiggingStatusRenderer.getInstance().render(guiGraphics);
        KeystrokesRenderer.getInstance().render(guiGraphics);
        ArmorHudRenderer.getInstance().render(guiGraphics);
        PotionStatusRenderer.getInstance().render(guiGraphics);
        DioxideLiteVisualOverlay.getInstance().render(guiGraphics);
        HudEditOverlay.getInstance().render(guiGraphics);
        BlockCountDisplayRenderer.getInstance().render(guiGraphics, null);
    }

    @Inject(method = "renderEffects", at = @At("HEAD"), cancellable = true)
    private void dioxide_lite$hideVanillaPotionEffects(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (PotionStatusRenderer.getInstance().shouldHideVanillaEffects()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderVignette", at = @At("HEAD"), cancellable = true)
    private void dioxide_lite$hideVignette(class_332 guiGraphics, @Nullable class_1297 entity, CallbackInfo ci) {
        if (Config.hideVignette) {
            ci.cancel();
        }
    }
}
