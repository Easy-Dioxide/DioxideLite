package com.dioxidelite.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

    public static class_304 openSettings;

    public static void register() {
        class_304.class_11900 category = class_304.class_11900.method_74698(
                class_2960.method_60655("dioxide_lite", "dioxide_lite")
        );

        openSettings = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.dioxide_lite.open_settings",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));
    }
}