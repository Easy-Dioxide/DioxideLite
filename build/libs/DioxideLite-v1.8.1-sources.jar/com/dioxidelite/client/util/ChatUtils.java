package com.dioxidelite.client.util;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public final class ChatUtils {
    public enum Mode {
        DEFAULT(class_124.field_1080, false),
        ERROR(class_124.field_1061, true),
        WARNING(class_124.field_1054, true),
        SUCCESS(class_124.field_1060, true),
        FAILURE(class_124.field_1061, true);

        private final class_124 color;
        private final boolean plainTextOnly;

        Mode(class_124 color, boolean plainTextOnly) {
            this.color = color;
            this.plainTextOnly = plainTextOnly;
        }
    }

    private ChatUtils() {
    }

    public static void send(String message) {
        send(Mode.DEFAULT, message);
    }

    public static void send(class_2561 message) {
        send(Mode.DEFAULT, message);
    }

    public static void send(Mode mode, String message) {
        send(mode, class_2561.method_43470(message == null ? "" : message));
    }

    public static void send(Mode mode, class_2561 message) {
        Mode resolvedMode = mode == null ? Mode.DEFAULT : mode;
        class_2561 resolvedMessage = message == null ? class_2561.method_43473() : message;
        class_5250 output = prefix().method_10852(formatMessage(resolvedMode, resolvedMessage));
        class_310 client = class_310.method_1551();
        if (client == null) return;
        client.execute(() -> {
            if (client.field_1705 != null) {
                client.field_1705.method_1743().method_1812(output);
            }
        });
    }

    public static void error(String message) {
        send(Mode.ERROR, message);
    }

    public static void error(class_2561 message) {
        send(Mode.ERROR, message);
    }

    public static void warning(String message) {
        send(Mode.WARNING, message);
    }

    public static void warning(class_2561 message) {
        send(Mode.WARNING, message);
    }

    public static void success(String message) {
        send(Mode.SUCCESS, message);
    }

    public static void success(class_2561 message) {
        send(Mode.SUCCESS, message);
    }

    public static void failure(String message) {
        send(Mode.FAILURE, message);
    }

    public static void failure(class_2561 message) {
        send(Mode.FAILURE, message);
    }

    private static class_5250 prefix() {
        return class_2561.method_43470("[")
                .method_27692(class_124.field_1068)
                .method_10852(class_2561.method_43470("P").method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470("] ").method_27692(class_124.field_1068));
    }

    private static class_2561 formatMessage(Mode mode, class_2561 message) {
        if (mode.plainTextOnly) {
            return class_2561.method_43470(message.getString()).method_27692(mode.color);
        }
        if (hasVanillaStyle(message)) {
            return message;
        }
        return message.method_27661().method_27692(mode.color);
    }

    private static boolean hasVanillaStyle(class_2561 component) {
        if (!component.method_10866().method_10967()) {
            return true;
        }
        for (class_2561 sibling : component.method_10855()) {
            if (hasVanillaStyle(sibling)) {
                return true;
            }
        }
        return false;
    }
}
