package com.dioxidelite.client;

import com.dioxidelite.Config;
import java.net.URI;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public final class VersionWarningManager {
    private static final String ISSUES_URL = "https://github.com/bakabaicai/DioxideLite/issues";
    private static boolean shown;

    private VersionWarningManager() {}

    public static void tick(class_310 client) {
        if (shown || client.field_1724 == null || client.field_1687 == null) return;
        if (Version.TYPE != 1 && Version.TYPE != 2) return;

        shown = true;
        client.field_1724.method_7353(Config.isChinese ? chineseMessage() : englishMessage(), false);
    }

    private static class_5250 chineseMessage() {
        if (Version.TYPE == 1) {
            return class_2561.method_43470("您当前正在使用 " + Version.NAME + " 的 ")
                    .method_27692(class_124.field_1054)
                    .method_10852(versionTypeText())
                    .method_10852(class_2561.method_43470(" 版本。该版本属于先行测试阶段，稳定性较低，可能存在大量已知或未知 Bug，且无法保证在所有设备上均可正常运行。发布此类版本的主要目的在于收集错误信息，以便开发者后续持续修复和完善模组内容，因此仅建议用于尝鲜体验。若在使用过程中遇到报错或异常情况，请优先通过 ")
                            .method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470("GitHub Issues").method_27696(linkStyle()))
                    .method_10852(class_2561.method_43470(" 向开发者反馈问题。").method_27692(class_124.field_1054));
        }

        return class_2561.method_43470("您当前正在使用 " + Version.NAME + " 的 ")
                .method_27692(class_124.field_1060)
                .method_10852(versionTypeText())
                .method_10852(class_2561.method_43470(" 版本。该版本已进入公开测试阶段，整体完成度与可用性相对更高，但仍可能存在部分 Bug、细节问题或兼容性异常。发布此类版本的主要目的在于进一步收集反馈并完善正式版体验，因此仍不保证在所有设备与环境下都能完全稳定运行。若在使用过程中发现异常，请通过 ")
                        .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470("GitHub Issues").method_27696(linkStyle()))
                .method_10852(class_2561.method_43470(" 提交反馈，帮助开发者在正式版发布前进一步优化体验。").method_27692(class_124.field_1060));
    }

    private static class_5250 englishMessage() {
        if (Version.TYPE == 1) {
            return class_2561.method_43470("You are currently using an ")
                    .method_27692(class_124.field_1054)
                    .method_10852(versionTypeText())
                    .method_10852(class_2561.method_43470(" version of " + Version.NAME + ". This build is part of the early testing stage and may be highly unstable, with many known or unknown bugs. Normal operation on all devices cannot be guaranteed. The main purpose of releasing this kind of version is to collect error reports so the mod can be improved and maintained more effectively. It is intended only for users who want an early preview. If you encounter crashes or abnormal behavior, please report them through ")
                            .method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470("GitHub Issues").method_27696(linkStyle()))
                    .method_10852(class_2561.method_43470(" first.").method_27692(class_124.field_1054));
        }

        return class_2561.method_43470("You are currently using a ")
                .method_27692(class_124.field_1060)
                .method_10852(versionTypeText())
                .method_10852(class_2561.method_43470(" version of " + Version.NAME + ". This build has entered the public testing stage, with a higher overall level of completion and usability, but some bugs, edge-case issues, or compatibility problems may still remain. The main purpose of releasing this kind of version is to gather more feedback and improve the final release. Stable operation on all devices and environments is still not guaranteed. If you find any issues during use, please submit them through ")
                        .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470("GitHub Issues").method_27696(linkStyle()))
                .method_10852(class_2561.method_43470(" to help improve the release version.").method_27692(class_124.field_1060));
    }

    private static class_5250 versionTypeText() {
        if (Version.TYPE == 1) {
            return class_2561.method_43470("Alpha").method_27695(class_124.field_1061, class_124.field_1067);
        }
        return class_2561.method_43470("Beta");
    }

    private static class_2583 linkStyle() {
        return class_2583.field_24360
                .method_10977(class_124.field_1060)
                .method_10982(true)
                .method_30938(true)
                .method_10958(new class_2558.class_10608(URI.create(ISSUES_URL)));
    }
}
