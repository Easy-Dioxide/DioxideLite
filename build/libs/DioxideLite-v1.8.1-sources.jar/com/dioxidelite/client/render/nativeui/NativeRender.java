package com.dioxidelite.client.render.nativeui;

import com.dioxidelite.client.render.font.FontRenderer;
import net.minecraft.class_310;
import net.minecraft.class_332;

/** Lightweight UI primitives backed directly by Minecraft's GuiGraphics renderer. */
public final class NativeRender {
    private NativeRender() {}
    public static int alpha(int color, float a) {
        int base = (color >>> 24) & 255;
        int out = Math.max(0, Math.min(255, Math.round(base * Math.max(0f, Math.min(1f, a)))));
        return (out << 24) | (color & 0xFFFFFF);
    }
    public static void panel(class_332 g, int x, int y, int w, int h, int fill, int outline, boolean outlineOnly) {
        if (!outlineOnly) g.method_25294(x, y, x + w, y + h, fill);
        if (((outline >>> 24) & 255) > 0) g.method_73198(x, y, Math.max(1, w), Math.max(1, h), outline);
    }
    public static void line(class_332 g, int x1, int y1, int x2, int y2, int color) {
        if (x1 == x2) g.method_25294(x1, Math.min(y1, y2), x1 + 1, Math.max(y1, y2) + 1, color);
        else if (y1 == y2) g.method_25294(Math.min(x1, x2), y1, Math.max(x1, x2) + 1, y1 + 1, color);
    }
    public static void text(class_332 g, String text, int x, int y, int color) {
        g.method_51439(class_310.method_1551().field_1772, FontRenderer.component(text), x, y, color, false);
    }
    public static int textWidth(String text) { return class_310.method_1551().field_1772.method_1727(text == null ? "" : text); }
    public static void centered(class_332 g, String text, int cx, int y, int color) {
        text(g, text, cx - textWidth(text) / 2, y, color);
    }
    public static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    public static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
}
