package com.dioxidelite.client.render.MainUI;

import com.dioxidelite.Config;
import com.dioxidelite.client.Version;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.system.MemoryUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;

import javax.imageio.ImageIO;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_4749;
import net.minecraft.class_500;
import net.minecraft.class_526;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * DioxideLite main menu. The composition and motion language follows the
 * supplied Setsuna reference, while the renderer/assets remain DioxideLite-owned.
 * It deliberately uses GuiGraphics only so the title screen never needs a
 * external raster/FBO path.
 */
public final class DioxideLiteMainUI extends class_437 {
    private static final class_2960 BACKGROUND_TEXTURE = class_2960.method_60655("dioxide_lite", "mainui_background");

    private final class_437 parent;
    private class_1043 backgroundTexture;
    private int backgroundW = -1, backgroundH = -1;
    private String loadedBackground = "";
    private float bgX, bgY;

    private boolean entryGate = true;
    private boolean settingsOpen;
    private long openedAt;
    private long lastFrame;
    private float transition;
    private float singleHover, multiHover, centerOpen;

    public DioxideLiteMainUI(class_437 parent) {
        super(class_2561.method_43470("DioxideLite"));
        this.parent = parent;
    }

    public DioxideLiteMainUI(class_437 parent, boolean ignored) { this(parent); }

    @Override
    protected void method_25426() {
        long now = System.nanoTime();
        openedAt = now;
        lastFrame = now;
        transition = 0.0f;
        entryGate = true;
        settingsOpen = false;
        singleHover = multiHover = centerOpen = 0.0f;
        ensureBackgroundTexture();
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, Math.max(0.0f, (now - lastFrame) / 1_000_000_000f));
        lastFrame = now;
        float elapsed = (now - openedAt) / 1_000_000_000f;

        // Setsuna-like staged entrance: background -> center point -> menu lines/text.
        float backgroundIntro = ease(clamp(elapsed / 0.70f));
        if (!entryGate) transition = Math.min(1.0f, transition + dt / 0.62f);
        float content = ease(clamp((elapsed - (entryGate ? 0.0f : 0.0f)) / 0.42f));

        drawBackground(g, mouseX, mouseY, backgroundIntro);
        if (entryGate) {
            drawEntry(g, backgroundIntro, elapsed);
        } else {
            updateHover(mouseX, mouseY, dt);
            drawMenu(g, ease(transition), elapsed);
            drawTopBar(g, ease(transition), mouseX, mouseY);
        }
        if (settingsOpen) drawBackgroundPanel(g, mouseX, mouseY, ease(transition));
    }

    private void drawBackground(class_332 g, int mouseX, int mouseY, float intro) {
        if (Config.mainUICustomBackground && ensureBackgroundTexture()) {
            float scale = Math.max(field_22789 / (float) backgroundW, field_22790 / (float) backgroundH) * 1.04f;
            float dw = backgroundW * scale, dh = backgroundH * scale;
            float tx = Config.mainUIMouseEffect
                    ? ((mouseX / (float) Math.max(1, field_22789)) - .5f) * -Math.max(8f, (dw - field_22789) * .22f) : 0f;
            float ty = Config.mainUIMouseEffect
                    ? ((mouseY / (float) Math.max(1, field_22790)) - .5f) * -Math.max(8f, (dh - field_22790) * .22f) : 0f;
            bgX += (tx - bgX) * .08f;
            bgY += (ty - bgY) * .08f;
            int alpha = Math.round(255f * intro);
            g.method_25294(0, 0, field_22789, field_22790, 0xFF000000);
            g.method_25302(class_10799.field_56883, BACKGROUND_TEXTURE,
                    Math.round((field_22789 - dw) / 2 + bgX), Math.round((field_22790 - dh) / 2 + bgY),
                    0, 0, Math.round(dw), Math.round(dh), backgroundW, backgroundH, backgroundW, backgroundH);
            g.method_25294(0, 0, field_22789, field_22790, ((Math.round(82f * intro) & 255) << 24) | 0x020509);
            return;
        }

        // Original lightweight fallback backdrop. The default install ships with a
        // dedicated image, so this path is only used if the external image is missing.
        g.method_25294(0, 0, field_22789, field_22790, 0xFF000000);
        if (intro <= 0) return;
        int alpha = Math.round(255f * intro);
        int line = ((Math.min(255, Math.round(20f * intro)) & 255) << 24) | 0xD8E6E3;
        int faint = ((Math.min(255, Math.round(10f * intro)) & 255) << 24) | 0x9BB8B2;
        int cx = field_22789 / 2;
        int horizon = Math.round(field_22790 * 0.56f);

        // Perspective plane / scan geometry, kept intentionally cheap.
        for (int i = 0; i < 9; i++) {
            int y = horizon + i * Math.max(18, field_22790 / 24);
            g.method_25294(0, y, field_22789, y + 1, faint);
        }
        for (int i = -10; i <= 10; i++) {
            int x = cx + i * Math.max(34, field_22789 / 18);
            g.method_25294(x, horizon, x + 1, field_22790, faint);
        }
        g.method_25294(cx, 0, cx + 1, field_22790, line);
        g.method_25294(0, horizon, field_22789, horizon + 1, line);

        // Two very subtle architectural light fields.
        int glowA = ((Math.min(255, Math.round(10f * intro)) & 255) << 24) | 0x58DDBE;
        int glowB = ((Math.min(255, Math.round(7f * intro)) & 255) << 24) | 0x8BD8FF;
        g.method_25294(0, Math.round(field_22790 * .18f), Math.round(field_22789 * .38f), Math.round(field_22790 * .82f), glowA);
        g.method_25294(Math.round(field_22789 * .62f), Math.round(field_22790 * .14f), field_22789, Math.round(field_22790 * .86f), glowB);

        // Vignette-like edge bands without shaders.
        g.method_25294(0, 0, field_22789, 22, ((Math.min(255, Math.round(44f * intro)) & 255) << 24));
        g.method_25294(0, field_22790 - 28, field_22789, field_22790, ((Math.min(255, Math.round(58f * intro)) & 255) << 24));
        if (alpha < 255) g.method_25294(0, 0, field_22789, field_22790, ((255 - alpha) << 24));
    }

    private void drawEntry(class_332 g, float intro, float elapsed) {
        int cx = field_22789 / 2, cy = field_22790 / 2;
        float pulse = .72f + .28f * (float) Math.sin(elapsed * 5.2f);
        int white = (Math.round(255f * intro) << 24) | 0xF3F7F6;
        int accent = (Math.round(150f * intro) << 24) | 0x58DDBE;

        g.method_73198(cx - 10, cy - 10, 20, 20, white);
        g.method_25294(cx - 2, cy - 2, cx + 3, cy + 3, white);
        g.method_25300(field_22793, "CLICK TO START", cx, cy + 38,
                (Math.round(255f * intro * pulse) << 24) | 0xF2F7F6);
        g.method_25300(field_22793, "DIOXIDELITE", cx, cy - 62, white);
        g.method_25300(field_22793, "LIQUID GLASS UI", cx, cy - 48,
                (Math.round(135f * intro) << 24) | 0x96A39F);
        g.method_25294(cx - 48, cy + 59, cx + 48, cy + 60, accent);
    }

    private void drawMenu(class_332 g, float t, float elapsed) {
        int cx = field_22789 / 2, cy = field_22790 / 2;
        float side = Math.max(160f, Math.min(280f, field_22789 * .24f));
        float open = ease(centerOpen);
        int accentLeft = 0x58DDBE, accentRight = 0x8BD8FF;

        // Central divider grows out from the center exactly as the menu opens.
        int dividerAlpha = Math.round(220f * t);
        int gap = Math.round(12f + open * 34f);
        int top = Math.round(lerp(cy - gap, 0, t));
        int bottom = Math.round(lerp(cy + gap, field_22790, t));
        g.method_25294(cx, top, cx + 1, cy - gap, (dividerAlpha << 24) | 0xFFFFFF);
        g.method_25294(cx, cy + gap, cx + 1, bottom, (dividerAlpha << 24) | 0xFFFFFF);

        float pulse = .5f + .5f * (float) Math.sin(elapsed * 6.0f);
        drawDestination(g, "SINGLE PLAYER", Math.round(cx - side), cy, -1, singleHover, t, accentLeft, pulse);
        drawDestination(g, "MULTI PLAYER", Math.round(cx + side), cy, 1, multiHover, t, accentRight, pulse);

        float r = lerp(7f, 38f, open);
        g.method_73198(Math.round(cx - r), Math.round(cy - r), Math.round(r * 2), Math.round(r * 2),
                (Math.round(235f * t) << 24) | 0xFFFFFF);
        g.method_25294(cx - 3, cy - 3, cx + 4, cy + 4, (Math.round(255f * (1f - open) * t) << 24) | 0xFFFFFF);

        g.method_25300(field_22793, "DIOXIDELITE", cx, cy - 58,
                (Math.round(255f * t) << 24) | 0xF2F7F6);
        g.method_25300(field_22793, Version.displayName(), cx, cy - 44,
                (Math.round(125f * t) << 24) | 0x96A39F);
        g.method_25300(field_22793, "OPTIONS", cx, cy + 72,
                (Math.round(180f * t) << 24) | 0xC9D3D0);
        g.method_25300(field_22793, "ESC  EXIT", cx, field_22790 - 22,
                (Math.round(100f * t) << 24) | 0x73807D);
    }

    private void drawDestination(class_332 g, String text, int cx, int cy, int dir,
                                 float hover, float intro, int accent, float pulse) {
        int tw = field_22793.method_1727(text);
        float x = cx + dir * (hover * 5f - 2f);
        int textAlpha = Math.round(255f * intro * (.72f + hover * .28f));
        int panelAlpha = Math.round((76f + pulse * 24f) * hover * intro);
        if (panelAlpha > 0) {
            g.method_25294(Math.round(cx - tw / 2f - 23), cy - 20,
                    Math.round(cx + tw / 2f + 23), cy + 19,
                    (panelAlpha << 24) | 0x000000);
        }
        int edge = Math.round((45f + hover * 135f) * intro);
        g.method_25294(Math.round(cx - tw / 2f - 23), cy + 18,
                Math.round(cx + tw / 2f + 23), cy + 19,
                (edge << 24) | accent);
        g.method_25300(field_22793, text, Math.round(x), cy - 5,
                (textAlpha << 24) | 0xF2F7F6);
    }

    private void drawTopBar(class_332 g, float a, int mx, int my) {
        int alpha = Math.round(255f * a);
        g.method_51433(field_22793, "DIOXIDELITE", 22, 18, (alpha << 24) | 0xF2F7F6, false);
        g.method_51433(field_22793, "LIQUID GLASS", 22, 31, (Math.round(135f * a) << 24) | 0x58DDBE, false);
        int themeW = 94, bgW = 112;
        int themeX = field_22789 - themeW - 24, bgX = themeX - bgW - 10;
        button(g, bgX, 16, bgW, 20,
                Config.mainUICustomBackground ? "BACKGROUND" : "BACKGROUND: SETSUNA", mx, my, a);
        button(g, themeX, 16, themeW, 20, "VANILLA", mx, my, a);
    }

    private void button(class_332 g, int x, int y, int w, int h, String text, int mx, int my, float a) {
        boolean hover = mx >= x && mx <= x + w && my >= y && my <= y + h;
        int fill = Math.round(255f * a * (hover ? .18f : .08f));
        g.method_25294(x, y, x + w, y + h, (fill << 24) | 0xFFFFFF);
        g.method_73198(x, y, w, h, (Math.round(255f * a * (hover ? .65f : .22f)) << 24) | 0x8EA7A2);
        g.method_25300(field_22793, text, x + w / 2, y + 6,
                (Math.round(255f * a * (hover ? 1f : .62f)) << 24) | 0xF2F7F6);
    }

    private void drawBackgroundPanel(class_332 g, int mx, int my, float a) {
        int w = 340, h = 142, x = field_22789 - w - 24, y = 48;
        g.method_25294(x, y, x + w, y + h, 0xE80A1014);
        g.method_73198(x, y, w, h, (Math.round(255f * a * .42f) << 24) | 0x71807C);
        g.method_51433(field_22793, "BACKGROUND", x + 16, y + 16, (Math.round(255f * a) << 24) | 0xF2F7F6, false);
        g.method_51433(field_22793, "PVPUtils-style image background", x + 16, y + 31,
                (Math.round(255f * a * .52f) << 24) | 0x96A39F, false);
        button(g, x + 16, y + 48, 145, 22, "IMAGE: " + shortName(Config.mainUIBackgroundImage), mx, my, a);
        button(g, x + 171, y + 48, 145, 22, "OPEN FOLDER", mx, my, a);
        button(g, x + 16, y + 78, 145, 22,
                Config.mainUIMouseEffect ? "MOUSE PARALLAX: ON" : "MOUSE PARALLAX: OFF", mx, my, a);
        button(g, x + 171, y + 78, 145, 22, "CLOSE", mx, my, a);
    }

    private void updateHover(int mx, int my, float dt) {
        int cx = field_22789 / 2, cy = field_22790 / 2;
        float side = Math.max(160f, Math.min(280f, field_22789 * .24f));
        boolean sh = Math.abs(mx - (cx - side)) < field_22793.method_1727("SINGLE PLAYER") / 2f + 42 && Math.abs(my - cy) < 30;
        boolean mh = Math.abs(mx - (cx + side)) < field_22793.method_1727("MULTI PLAYER") / 2f + 42 && Math.abs(my - cy) < 30;
        singleHover = approach(singleHover, sh ? 1f : 0f, dt * 9f);
        multiHover = approach(multiHover, mh ? 1f : 0f, dt * 9f);
        boolean center = Math.abs(mx - cx) < 46 && Math.abs(my - cy) < 46;
        centerOpen = approach(centerOpen, center ? 1f : 0f, dt * 7f);
    }

    @Override
    public boolean method_25402(class_11909 e, boolean consumed) {
        if (e.method_74245() != 0) return false;
        float mx = (float) e.comp_4798(), my = (float) e.comp_4799();

        int themeX = field_22789 - 94 - 24, bgX = themeX - 112 - 10;
        if (!entryGate) {
            if (mx >= themeX && mx <= themeX + 94 && my >= 16 && my <= 36) {
                Config.useMainUI = false;
                Config.save();
                if (field_22787 != null) field_22787.method_1507(new class_442());
                return true;
            }
            if (mx >= bgX && mx <= bgX + 112 && my >= 16 && my <= 36) {
                settingsOpen = !settingsOpen;
                return true;
            }
        }

        if (settingsOpen) {
            int x = field_22789 - 340 - 24, y = 48;
            if (hit(x + 16, y + 48, 145, 22, mx, my)) { cycleBackgroundImage(); return true; }
            if (hit(x + 171, y + 48, 145, 22, mx, my)) { MainUIBackgrounds.openFolder(); return true; }
            if (hit(x + 16, y + 78, 145, 22, mx, my)) {
                Config.mainUIMouseEffect = !Config.mainUIMouseEffect; Config.save(); return true;
            }
            if (hit(x + 171, y + 78, 145, 22, mx, my)) { settingsOpen = false; return true; }
        }

        if (entryGate) {
            entryGate = false;
            transition = 0f;
            openedAt = System.nanoTime();
            lastFrame = openedAt;
            playClick();
            return true;
        }

        int cx = field_22789 / 2, cy = field_22790 / 2;
        float side = Math.max(160f, Math.min(280f, field_22789 * .24f));
        if (Math.abs(mx - (cx - side)) < field_22793.method_1727("SINGLE PLAYER") / 2f + 42 && Math.abs(my - cy) < 32) {
            if (field_22787 != null) field_22787.method_1507(new class_526(this));
            return true;
        }
        if (Math.abs(mx - (cx + side)) < field_22793.method_1727("MULTI PLAYER") / 2f + 42 && Math.abs(my - cy) < 32) {
            if (field_22787 != null) field_22787.method_1507(field_22787.field_1690.field_21840 ? new class_500(this) : new class_4749(this));
            return true;
        }
        if (Math.abs(mx - cx) < 80 && Math.abs(my - (cy + 72)) < 24) {
            if (field_22787 != null) field_22787.method_1507(new class_429(this, field_22787.field_1690));
            return true;
        }
        return true;
    }

    @Override
    public boolean method_25404(class_11908 e) {
        if (e.comp_4795() == GLFW.GLFW_KEY_ESCAPE) {
            if (settingsOpen) { settingsOpen = false; return true; }
            method_25419();
            return true;
        }
        return super.method_25404(e);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent != null ? parent : new class_442());
    }

    @Override public boolean method_25421() { return false; }

    @Override public void method_25432() { destroyBackground(); }

    private boolean hit(int x, int y, int w, int h, float mx, float my) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void playClick() {
        if (field_22787 != null) field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1f));
    }

    private void cycleBackgroundImage() {
        List<String> files = MainUIBackgrounds.listPngs();
        if (files.isEmpty()) return;
        int i = files.indexOf(Config.mainUIBackgroundImage);
        Config.mainUIBackgroundImage = files.get((i + 1 + files.size()) % files.size());
        Config.mainUICustomBackground = true;
        Config.save();
        destroyBackground();
        ensureBackgroundTexture();
    }

    private boolean ensureBackgroundTexture() {
        if (!Config.mainUICustomBackground) return false;
        String selected = Config.mainUIBackgroundImage == null || Config.mainUIBackgroundImage.isBlank() ? "1.png" : Config.mainUIBackgroundImage;
        if (backgroundTexture != null && selected.equals(loadedBackground)) return true;
        destroyBackground();
        Path path = MainUIBackgrounds.resolve(selected);
        if (!Files.exists(path)) return false;
        try {
            BufferedImage image = ImageIO.read(path.toFile());
            if (image == null) return false;
            int w = image.getWidth(), h = image.getHeight();
            ByteBuffer b = MemoryUtil.memAlloc(w * h * 4);
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int c = image.getRGB(x, y);
                b.put((byte) (c >> 16)).put((byte) (c >> 8)).put((byte) c).put((byte) (c >> 24));
            }
            b.flip();
            backgroundTexture = new class_1043("dioxide_lite:mainui_background", w, h, false);
            class_310.method_1551().method_1531().method_4616(BACKGROUND_TEXTURE, backgroundTexture);
            GpuTexture tex = backgroundTexture.method_68004();
            RenderSystem.getDevice().createCommandEncoder().writeToTexture(tex, b, class_1011.class_1012.field_4997, 0, 0, 0, 0, w, h);
            MemoryUtil.memFree(b);
            backgroundW = w; backgroundH = h; loadedBackground = selected;
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private void destroyBackground() {
        if (backgroundTexture != null) {
            class_1060 manager = class_310.method_1551().method_1531();
            manager.method_4615(BACKGROUND_TEXTURE);
            backgroundTexture = null;
        }
        backgroundW = backgroundH = -1;
        loadedBackground = "";
        bgX = bgY = 0;
    }

    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float ease(float v) { v = clamp(v); return v * v * (3f - 2f * v); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float approach(float value, float target, float amount) {
        if (value < target) return Math.min(target, value + amount);
        return Math.max(target, value - amount);
    }
    private static String shortName(String s) { if (s == null) return "1.png"; return s.length() > 19 ? s.substring(0, 16) + "..." : s; }
}
