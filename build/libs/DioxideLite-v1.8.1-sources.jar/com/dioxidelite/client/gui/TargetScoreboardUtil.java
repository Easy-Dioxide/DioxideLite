package com.dioxidelite.client.gui;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_8646;
import net.minecraft.class_9013;

public class TargetScoreboardUtil {
    public static int getBelowNameHealth(class_1309 entity) {
        if (!(entity instanceof class_1657 player)) return -1;

        class_269 scoreboard = player.method_73183().method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45158);

        if (objective != null) {
            class_9013 scoreInfo = scoreboard.method_55430(player, objective);
            if (scoreInfo != null) {
                return scoreInfo.method_55397();
            }
        }
        return -1;
    }
}