package com.dioxidelite.client.gui.clickgui;

import com.dioxidelite.Config;
import net.minecraft.class_310;
import net.minecraft.class_437;

/** Centralized ClickGUI theme routing. Themes are presentation-only and share the same pages/config. */
public final class ClickGuiThemeController {
    private ClickGuiThemeController() {}

    public static class_437 create(Config.ClickGuiTheme theme, class_437 parent) {
        return switch (theme) {
            case ORIGINAL -> new NewSettingsScreen(parent);
            case MINIMAL_POP -> new DioxideLiteMinimalClickGuiScreen(parent);
            case SIGNATURE -> new DioxideLiteSignatureClickGuiScreen(parent);
            case GLASS -> new GlassThemeScreen(parent);
        };
    }

    public static void apply(Config.ClickGuiTheme theme, class_437 parent) {
        Config.clickGuiTheme = theme;
        Config.save();
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1755 != null) {
            class_437 nextParent = parent != null ? parent : client.field_1755;
            client.method_1507(create(theme, nextParent));
        }
    }
}
