package com.dioxidelite.client.gui;

import com.dioxidelite.Config;
import com.dioxidelite.client.ResetManager;
import java.util.Locale;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class SettingsScreen extends class_437 {
    private final class_437 lastScreen;
    private boolean inAnimPage = false;
    private boolean inOtherPage = false;
    private boolean inHitMarkerPage = false;
    private boolean inTargetHudPage = false;
    private boolean inSneakPage = false;
    private boolean inResetConfirmPage = false;
    private boolean resettingAll = true;

    public SettingsScreen(class_437 lastScreen) {
        super(class_2561.method_43470(Config.isChinese ? "DioxideLite 设置" : "DioxideLite Settings"));
        this.lastScreen = lastScreen;
    }

    @Override
    protected void method_25426() {
        this.method_37067();
        if (inResetConfirmPage) {
            initResetConfirmPage();
        } else if (inAnimPage) {
            initAnimPage();
        } else if (inHitMarkerPage) {
            initHitMarkerPage();
        } else if (inTargetHudPage) {
            initTargetHudPage();
        } else if (inSneakPage) {
            initSneakPage();
        } else if (inOtherPage) {
            initOtherPage();
        } else {
            initMainPage();
        }
    }

    private void initMainPage() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        boolean cn = Config.isChinese;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "动画设置" : "Animation Settings"),
                (button) -> {
                    inAnimPage = true;
                    inOtherPage = false;
                    inSneakPage = false;
                    this.method_25426();
                }).method_46434(centerX - 155, centerY - 44, 150, 40).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "其他功能" : "Other Features"),
                (button) -> {
                    inOtherPage = true;
                    inAnimPage = false;
                    inSneakPage = false;
                    this.method_25426();
                }).method_46434(centerX + 5, centerY - 44, 150, 40).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "潜行动画" : "Sneak Animation"),
                (button) -> {
                    inSneakPage = true;
                    inAnimPage = false;
                    inOtherPage = false;
                    inHitMarkerPage = false;
                    inTargetHudPage = false;
                    this.method_25426();
                }).method_46434(centerX - 75, centerY + 4, 150, 40).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "§c重置所有设置" : "§cReset All Settings"),
                (button) -> {
                    Config.offsetX = 0.0f;
                    Config.offsetY = 0.0f;
                    Config.offsetZ = 0.0f;
                    Config.animSpeed = 1.0f;
                    Config.range = 3.0;
                    Config.swordBlock = false;
                    Config.useSwing = false;
                    Config.autoMode = false;
                    Config.noSneakAnimation = false;
                    Config.sneakDropScale = 0.5f;
                    Config.sneakAnimationSpeed = 1.0f;
                    Config.autoScreenshot = false;
                    Config.hitMarker = false;
                    Config.hitSound = true;
                    Config.lowHealthNotify = true;
                    Config.targetHud = false;
                    Config.diggingStatus = false;
                    Config.fallDamagePredict = false;
                    Config.victorySound = false;
                    Config.gammaOverride = false;
                    Config.gammaValue = 15.0;
                    Config.autoSprint = false;
                    Config.blockCountDisplay = false;
                    Config.autoChestDeposit = false;
                    Config.autoChestDepositResourcesOnly = true;
                    Config.autoChestDepositDepositDelay = 4;
                    Config.autoChestDepositCloseDelay = 4;
                    Config.targetHudX = -300f;
                    Config.targetHudY = -100f;
                    Config.targetHudZ = 0f;
                    Config.targetHudScale = 1.0f;
                    Config.nameTag = false;
                    Config.nameTagScale = 1.0f;
                    Config.nameTagDynamicScale = false;
                    Config.nameTagOnlyPlayer = false;
                    Config.dynamicMotionBlur = false;
                    Config.dynamicMotionBlurStrength = 1.0f;
                    Config.dynamicMotionBlurRefreshRateScaling = true;
                    Config.armorHud = false;
                    Config.potionStatus = false;
                    Config.blockCountDisplayX = 0f;
                    Config.blockCountDisplayY = 0f;
                    Config.blockCountDisplayScale = 1.0f;
                    Config.notificationX = Float.NaN;
                    Config.notificationY = Float.NaN;
                    Config.notificationScale = 1.0f;
                    Config.potionStatusX = 0f;
                    Config.potionStatusY = 0f;
                    Config.potionStatusScale = 1.0f;
                    Config.hideSignText = false;
                    Config.hideEnchantTableBook = false;
                    Config.hideFireOverlay = false;
                    Config.hideHurtShake = false;
                    Config.hitSoundType = Config.HitSoundType.NETHERITE;
                    Config.hitSoundCondition = Config.HitSoundCondition.BOTH;
                    Config.targetHudMode = Config.TargetHudMode.NEW;
                    Config.keystrokesMode = Config.KeystrokesMode.NEW;
                    Config.animationMode = Config.AnimMode.MODE_1_7;
                    Config.motionBlurAlgorithm = Config.MotionBlurAlgorithm.VELOCITY_BASED;
                    Config.save();
                    if (this.field_22787 != null) this.field_22787.method_1507(new SettingsScreen(this.lastScreen));
                    inResetConfirmPage = true;
                    resettingAll = true;
                    this.method_25426();
                }).method_46434(5, this.field_22790 - 75, 90, 20).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "§a作者主页" : "§aAuthor"),
                (button) -> {
                    if (this.field_22787 != null) {
                        String url = "https://space.bilibili.com/3546915648047958";
                        this.field_22787.method_1507(new net.minecraft.class_407((confirmed) -> {
                            if (confirmed) {
                                class_156.method_668().method_670(url);
                            }
                            this.field_22787.method_1507(this);
                        }, url, true));
                    }
                }).method_46434(5, this.field_22790 - 50, 90, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470(cn ? "Language: CN" : "Language: EN"), (button) -> {
            Config.isChinese = !Config.isChinese;
            Config.save();
            if (this.field_22787 != null) this.field_22787.method_1507(new SettingsScreen(this.lastScreen));
        }).method_46434(5, this.field_22790 - 25, 90, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470(cn ? "完成" : "Done"), (button) -> this.method_25419())
                .method_46434(centerX - 75, this.field_22790 - 28, 150, 20).method_46431());
    }

    private void initAnimPage() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        boolean cn = Config.isChinese;

        String modePrefix = cn ? "动画模式: " : "Animation Mode: ";
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(modePrefix + getModeName()),
                (button) -> {
                    cycleMode();
                    button.method_25355(class_2561.method_43470(modePrefix + getModeName()));
                    Config.save();
                }).method_46434(centerX - 75, centerY - 110, 150, 20).method_46431());

        this.method_37063(new class_357(centerX - 75, centerY - 85, 150, 20, class_2561.method_43473(), (Config.offsetX + 1f) / 2f) {
            { method_25346(); }
            @Override protected void method_25346() { this.method_25355(class_2561.method_43470("X: " + String.format(Locale.ROOT, "%.2f", Config.offsetX))); }
            @Override protected void method_25344() { Config.offsetX = (float) (this.field_22753 * 2.0 - 1.0); Config.save(); }
        });

        this.method_37063(new class_357(centerX - 75, centerY - 60, 150, 20, class_2561.method_43473(), (Config.offsetY + 1f) / 2f) {
            { method_25346(); }
            @Override protected void method_25346() { this.method_25355(class_2561.method_43470("Y: " + String.format(Locale.ROOT, "%.2f", Config.offsetY))); }
            @Override protected void method_25344() { Config.offsetY = (float) (this.field_22753 * 2.0 - 1.0); Config.save(); }
        });

        this.method_37063(new class_357(centerX - 75, centerY - 35, 150, 20, class_2561.method_43473(), (Config.offsetZ + 1f) / 2f) {
            { method_25346(); }
            @Override protected void method_25346() { this.method_25355(class_2561.method_43470("Z: " + String.format(Locale.ROOT, "%.2f", Config.offsetZ))); }
            @Override protected void method_25344() { Config.offsetZ = (float) (this.field_22753 * 2.0 - 1.0); Config.save(); }
        });

        String speedName = cn ? "动画速度" : "Animation Speed";
        this.method_37063(new class_357(centerX - 75, centerY - 10, 150, 20, class_2561.method_43473(), Config.animSpeed / 4.0f) {
            { method_25346(); }
            @Override protected void method_25346() { this.method_25355(class_2561.method_43470(speedName + ": " + String.format(Locale.ROOT, "%.2f", Config.animSpeed))); }
            @Override protected void method_25344() { Config.animSpeed = (float) (this.field_22753 * 4.0); Config.save(); }
        });

        String reachName = cn ? "触发距离" : "Reach";
        this.method_37063(new class_357(centerX - 75, centerY + 15, 150, 20, class_2561.method_43473(), (float)((Config.range - 2.0) / 4.0)) {
            { method_25346(); }
            @Override protected void method_25346() { this.method_25355(class_2561.method_43470(reachName + ": " + String.format(Locale.ROOT, "%.2f", Config.range))); }
            @Override protected void method_25344() { Config.range = 2.0 + (this.field_22753 * 4.0); Config.save(); }
        });

        int btnW = 85;
        int sX = centerX - (btnW * 3 + 4) / 2;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "格挡动画" : "Sword Block", Config.swordBlock, cn)),
                (button) -> {
                    Config.swordBlock = !Config.swordBlock;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "格挡动画" : "Sword Block", Config.swordBlock, cn)));
                    Config.save();
                }).method_46434(sX, centerY + 40, btnW, 20).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "使用动画" : "UseSwing", Config.useSwing, cn)),
                (button) -> {
                    Config.useSwing = !Config.useSwing;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "使用动画" : "UseSwing", Config.useSwing, cn)));
                    Config.save();
                }).method_46434(sX + btnW + 2, centerY + 40, btnW, 20).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "自动格挡" : "Auto", Config.autoMode, cn)),
                (button) -> {
                    Config.autoMode = !Config.autoMode;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "自动格挡" : "Auto", Config.autoMode, cn)));
                    Config.save();
                }).method_46434(sX + (btnW + 2) * 2, centerY + 40, btnW, 20).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "§c重置此页所有设置" : "§cReset This Page"),
                (button) -> {
                    inResetConfirmPage = true;
                    resettingAll = false;
                    this.method_25426();
                }).method_46434(centerX - 75, centerY + 65, 150, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470(cn ? "返回" : "Back"), (button) -> {
            inAnimPage = false;
            inOtherPage = false;
            this.method_25426();
        }).method_46434(centerX - 75, centerY + 90, 150, 20).method_46431());
    }

    private void initOtherPage() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        boolean cn = Config.isChinese;

        int currentY = centerY - 85;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "自动截图" : "Auto Screenshot", Config.autoScreenshot, cn)),
                (button) -> {
                    Config.autoScreenshot = !Config.autoScreenshot;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "自动截图" : "Auto Screenshot", Config.autoScreenshot, cn)));
                    Config.save();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        currentY += 25;
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "低血量提示" : "Low Health Warning", Config.lowHealthNotify, cn)),
                (button) -> {
                    Config.lowHealthNotify = !Config.lowHealthNotify;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "低血量提示" : "Low Health Warning", Config.lowHealthNotify, cn)));
                    Config.save();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        currentY += 25;
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "击中标记..." : "Hit Marker..."),
                (button) -> {
                    inHitMarkerPage = true;
                    inOtherPage = false;
                    this.method_25426();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        currentY += 25;
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "目标HUD..." : "Target HUD..."),
                (button) -> {
                    inTargetHudPage = true;
                    inOtherPage = false;
                    this.method_25426();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        currentY += 25;
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "摔落伤害预测" : "Fall Damage Predict", Config.fallDamagePredict, cn)),
                (button) -> {
                    Config.fallDamagePredict = !Config.fallDamagePredict;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "摔落伤害预测" : "Fall Damage Predict", Config.fallDamagePredict, cn)));
                    Config.save();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        currentY += 25;
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "盔甲 HUD" : "Armor HUD", Config.armorHud, cn)),
                (button) -> {
                    Config.armorHud = !Config.armorHud;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "盔甲 HUD" : "Armor HUD", Config.armorHud, cn)));
                    Config.save();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        currentY += 25;
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "药水状态" : "Potion Status", Config.potionStatus, cn)),
                (button) -> {
                    Config.potionStatus = !Config.potionStatus;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "药水状态" : "Potion Status", Config.potionStatus, cn)));
                    Config.save();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        currentY += 25;
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "胜利音效" : "Victory Sound", Config.victorySound, cn)),
                (button) -> {
                    Config.victorySound = !Config.victorySound;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "胜利音效" : "Victory Sound", Config.victorySound, cn)));
                    Config.save();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470(cn ? "返回" : "Back"), (button) -> {
            inOtherPage = false;
            inAnimPage = false;
            this.method_25426();
        }).method_46434(centerX - 75, centerY + 100, 150, 20).method_46431());
    }

    private void initSneakPage() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        boolean cn = Config.isChinese;
        int currentY = centerY - 60;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "潜行动画" : "Sneak Animation", Config.noSneakAnimation, cn)),
                (button) -> {
                    Config.noSneakAnimation = !Config.noSneakAnimation;
                    button.method_25355(class_2561.method_43470(getToggleText(cn ? "潜行动画" : "Sneak Animation", Config.noSneakAnimation, cn)));
                    Config.save();
                    this.method_25426();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        String sliderName = cn ? "潜行下降高度" : "Sneak Drop";
        if (Config.noSneakAnimation) {
            currentY += 25;
            this.method_37063(new class_357(centerX - 75, currentY, 150, 20, class_2561.method_43473(), Config.sneakDropScale) {
                { method_25346(); }
                @Override protected void method_25346() {
                    int percent = Math.round(Config.sneakDropScale * 100.0f);
                    this.method_25355(class_2561.method_43470(sliderName + ": " + percent + "%"));
                }
                @Override protected void method_25344() {
                    Config.sneakDropScale = (float) this.field_22753;
                    Config.save();
                }
            });

            currentY += 25;
            String speedName = cn ? "动画速度" : "Animation Speed";
            this.method_37063(new class_357(centerX - 75, currentY, 150, 20, class_2561.method_43473(), Config.sneakAnimationSpeed) {
                { method_25346(); }
                @Override protected void method_25346() {
                    if (Config.sneakAnimationSpeed >= 1.0f) {
                        this.method_25355(class_2561.method_43470(speedName + ": " + (cn ? "无插帧" : "Instant")));
                    } else {
                        int percent = Math.round(Config.sneakAnimationSpeed * 100.0f);
                        this.method_25355(class_2561.method_43470(speedName + ": " + percent + "%"));
                    }
                }
                @Override protected void method_25344() {
                    Config.sneakAnimationSpeed = (float) this.field_22753;
                    Config.save();
                }
            });
        }

        this.method_37063(class_4185.method_46430(class_2561.method_43470(cn ? "返回" : "Back"), (button) -> {
            inSneakPage = false;
            this.method_25426();
        }).method_46434(centerX - 75, centerY + 65, 150, 20).method_46431());
    }

    private void initHitMarkerPage() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        boolean cn = Config.isChinese;

        int currentY = centerY - 85;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "击中标记" : "Hit Marker", Config.hitMarker, cn)),
                (button) -> {
                    Config.hitMarker = !Config.hitMarker;
                    Config.save();
                    this.method_25426();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        if (Config.hitMarker) {
            currentY += 25;
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470(getToggleText(cn ? "命中提示音" : "Hit Sound", Config.hitSound, cn)),
                    (button) -> {
                        Config.hitSound = !Config.hitSound;
                        Config.save();
                        this.method_25426();
                    }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

            if (Config.hitSound) {
                currentY += 25;
                String typeName = Config.hitSoundType == Config.HitSoundType.NETHERITE ?
                        (cn ? "下界合金块" : "Netherite Block") : (cn ? "经验声" : "Experience");
                this.method_37063(class_4185.method_46430(
                        class_2561.method_43470((cn ? "提示音: " : "Sound: ") + typeName),
                        (button) -> {
                            Config.hitSoundType = Config.hitSoundType == Config.HitSoundType.NETHERITE ?
                                    Config.HitSoundType.EXPERIENCE : Config.HitSoundType.NETHERITE;
                            Config.save();
                            this.method_25426();
                        }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

                currentY += 25;
                String conditionName = switch (Config.hitSoundCondition) {
                    case BOTH -> cn ? "近战、远程命中" : "Melee & Ranged";
                    case MELEE -> cn ? "近战命中" : "Melee Only";
                    case RANGED -> cn ? "远程命中" : "Ranged Only";
                };
                this.method_37063(class_4185.method_46430(
                        class_2561.method_43470((cn ? "提示音播放时机: " : "Play On: ") + conditionName),
                        (button) -> {
                            Config.hitSoundCondition = switch (Config.hitSoundCondition) {
                                case BOTH -> Config.HitSoundCondition.MELEE;
                                case MELEE -> Config.HitSoundCondition.RANGED;
                                case RANGED -> Config.HitSoundCondition.BOTH;
                            };
                            Config.save();
                            this.method_25426();
                        }).method_46434(centerX - 75, currentY, 150, 20).method_46431());
            }
        }

        this.method_37063(class_4185.method_46430(class_2561.method_43470(cn ? "返回" : "Back"), (button) -> {
            inHitMarkerPage = false;
            inOtherPage = true;
            this.method_25426();
        }).method_46434(centerX - 75, centerY + 100, 150, 20).method_46431());
    }

    private void initTargetHudPage() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        boolean cn = Config.isChinese;

        int currentY = centerY - 85;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(getToggleText(cn ? "目标HUD" : "Target HUD", Config.targetHud, cn)),
                (button) -> {
                    Config.targetHud = !Config.targetHud;
                    Config.save();
                    this.method_25426();
                }).method_46434(centerX - 75, currentY, 150, 20).method_46431());

        currentY += 30;

        this.method_37063(new class_357(centerX - 75, currentY, 150, 20, class_2561.method_43473(), (Config.targetHudX + 500f) / 1000f) {
            { method_25346(); }
            @Override protected void method_25346() { this.method_25355(class_2561.method_43470("HUD X: " + String.format(Locale.ROOT, "%.0f", Config.targetHudX))); }
            @Override protected void method_25344() { Config.targetHudX = (float) (this.field_22753 * 1000.0 - 500.0); Config.save(); }
        });

        currentY += 25;

        this.method_37063(new class_357(centerX - 75, currentY, 150, 20, class_2561.method_43473(), (Config.targetHudY + 500f) / 1000f) {
            { method_25346(); }
            @Override protected void method_25346() { this.method_25355(class_2561.method_43470("HUD Y: " + String.format(Locale.ROOT, "%.0f", Config.targetHudY))); }
            @Override protected void method_25344() { Config.targetHudY = (float) (this.field_22753 * 1000.0 - 500.0); Config.save(); }
        });

        currentY += 25;

        this.method_37063(new class_357(centerX - 75, currentY, 150, 20, class_2561.method_43473(), (Config.targetHudZ + 500f) / 1000f) {
            { method_25346(); }
            @Override protected void method_25346() { this.method_25355(class_2561.method_43470("HUD Z: " + String.format(Locale.ROOT, "%.0f", Config.targetHudZ))); }
            @Override protected void method_25344() { Config.targetHudZ = (float) (this.field_22753 * 1000.0 - 500.0); Config.save(); }
        });

        this.method_37063(class_4185.method_46430(class_2561.method_43470(cn ? "返回" : "Back"), (button) -> {
            inTargetHudPage = false;
            inOtherPage = true;
            this.method_25426();
        }).method_46434(centerX - 75, centerY + 100, 150, 20).method_46431());
    }

    private void initResetConfirmPage() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        boolean cn = Config.isChinese;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "§c是的，现在立刻重置所有设置" : "§cYes, reset all settings now"),
                (button) -> {
                    if (resettingAll) {
                        ResetManager.resetAll();
                        inAnimPage = false;
                        inOtherPage = false;
                    } else {
                        ResetManager.resetAnimPage();
                        inAnimPage = true;
                    }
                    inResetConfirmPage = false;
                    this.method_25426();
                }).method_46434(centerX - 100, centerY - 25, 200, 20).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(cn ? "§a不，我点错了" : "§aNo, I misclicked"),
                (button) -> {
                    inResetConfirmPage = false;
                    this.method_25426();
                }).method_46434(centerX - 100, centerY + 5, 200, 20).method_46431());
    }

    private String getToggleText(String prefix, boolean value, boolean isChinese) {
        if (isChinese) {
            return prefix + ": " + (value ? "开" : "关");
        } else {
            return prefix + ": " + (value ? "ON" : "OFF");
        }
    }

    private String getModeName() {
        return switch (Config.animationMode) {
            case MODE_1_7 -> "1.7";
            case MODE_PUSH -> "Push";
            case MODE_1_7_PLUS -> "1.7+";
            case MODE_NEW -> "New";
        };
    }

    private void cycleMode() {
        Config.animationMode = switch (Config.animationMode) {
            case MODE_1_7 -> Config.AnimMode.MODE_PUSH;
            case MODE_PUSH -> Config.AnimMode.MODE_1_7_PLUS;
            case MODE_1_7_PLUS -> Config.AnimMode.MODE_NEW;
            case MODE_NEW -> Config.AnimMode.MODE_1_7;
        };
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.method_52752(graphics);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25420(class_332 graphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) this.field_22787.method_1507(this.lastScreen);
    }
}
