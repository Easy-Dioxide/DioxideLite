package com.dioxidelite.client.modules.impl.Combat;

import com.dioxidelite.Config;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1671;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class ElytraAssistManager {
    private static int fireworkCooldown;
    private static boolean wasJumpDown;

    private ElytraAssistManager() {}

    public static void tick(class_310 client) {
        if (!Config.elytraAssist || client.field_1724 == null || client.field_1687 == null || client.field_1761 == null || client.field_1755 != null) {
            reset(client);
            return;
        }

        class_746 player = client.field_1724;
        boolean jumpDown = client.field_1690.field_1903.method_1434();
        if (Config.elytraAutoDeploy && jumpDown && !wasJumpDown && canStartFlying(player)) {
            player.field_3944.method_52787(new class_2848(player, class_2848.class_2849.field_12982));
            player.method_23668();
        }
        wasJumpDown = jumpDown;

        if (fireworkCooldown > 0) fireworkCooldown--;
        if (Config.elytraAutoFirework && player.method_6128() && fireworkCooldown <= 0 && isHoldingFirework(player) && !hasFireworkBoost(client, player)) {
            class_1268 hand = player.method_6047().method_31574(class_1802.field_8639) ? class_1268.field_5808 : class_1268.field_5810;
            client.field_1761.method_2919(player, hand);
            player.method_6104(hand);
            fireworkCooldown = 8;
        }
    }

    private static boolean canStartFlying(class_746 player) {
        class_1799 chest = player.method_6118(class_1304.field_6174);
        return chest.method_31574(class_1802.field_8833)
                && !player.method_24828()
                && !player.method_6128()
                && !player.method_5799()
                && !player.method_5771()
                && !player.method_6101()
                && !player.method_31549().field_7479;
    }

    private static boolean isHoldingFirework(class_746 player) {
        return player.method_6047().method_31574(class_1802.field_8639) || player.method_6079().method_31574(class_1802.field_8639);
    }

    private static boolean hasFireworkBoost(class_310 client, class_746 player) {
        class_238 area = player.method_5829().method_1014(2.5);
        return !client.field_1687.method_8333(player, area, entity -> entity instanceof class_1671).isEmpty();
    }

    private static void reset(class_310 client) {
        fireworkCooldown = 0;
        wasJumpDown = client != null && client.field_1690.field_1903.method_1434();
    }
}
