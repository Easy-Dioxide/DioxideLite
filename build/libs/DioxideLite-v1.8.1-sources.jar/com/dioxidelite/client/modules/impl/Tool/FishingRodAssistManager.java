package com.dioxidelite.client.modules.impl.Tool;

import com.dioxidelite.Config;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class FishingRodAssistManager {
    private static int lastSelectedSlot = -1;
    private static boolean lastHoldingRod;
    private static int pendingSlot = -1;
    private static int ticksRemaining;

    private FishingRodAssistManager() {}

    public static void tick(class_310 client) {
        if (!Config.fishingRodAssist || client.field_1724 == null || client.field_1761 == null || client.field_1755 != null) {
            reset(client);
            return;
        }

        class_746 player = client.field_1724;
        int selectedSlot = player.method_31548().method_67532();
        boolean holdingRod = player.method_6047().method_31574(class_1802.field_8378);

        if (holdingRod && (!lastHoldingRod || selectedSlot != lastSelectedSlot)) {
            pendingSlot = selectedSlot;
            ticksRemaining = Math.max(0, Config.fishingRodAssistUseDelay);
        }

        if (pendingSlot >= 0) {
            if (!holdingRod || selectedSlot != pendingSlot) {
                pendingSlot = -1;
                ticksRemaining = 0;
            } else if (ticksRemaining > 0) {
                ticksRemaining--;
            } else {
                client.field_1761.method_2919(player, class_1268.field_5808);
                player.method_6104(class_1268.field_5808);
                pendingSlot = -1;
            }
        }

        lastHoldingRod = holdingRod;
        lastSelectedSlot = selectedSlot;
    }

    private static void reset(class_310 client) {
        if (client != null && client.field_1724 != null) {
            lastHoldingRod = client.field_1724.method_6047().method_31574(class_1802.field_8378);
            lastSelectedSlot = client.field_1724.method_31548().method_67532();
        } else {
            lastHoldingRod = false;
            lastSelectedSlot = -1;
        }
        pendingSlot = -1;
        ticksRemaining = 0;
    }
}
