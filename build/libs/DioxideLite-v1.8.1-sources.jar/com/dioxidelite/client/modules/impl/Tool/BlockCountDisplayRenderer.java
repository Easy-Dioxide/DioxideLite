package com.dioxidelite.client.modules.impl.Tool;

import com.dioxidelite.Config; import com.dioxidelite.client.modules.impl.Render.HudEditOverlay; import com.dioxidelite.client.render.nativeui.NativeGlassVisualSystem;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

/** Native block count/status display. */
public final class BlockCountDisplayRenderer {
    private static final BlockCountDisplayRenderer INSTANCE=new BlockCountDisplayRenderer(); private final RateCounter clicks=new RateCounter(),placements=new RateCounter(); private boolean visible; private long until; private class_1799 stack=class_1799.field_8037; private float anim; private int lastSlot=-1,lastCount=-1;
    public static BlockCountDisplayRenderer getInstance(){return INSTANCE;}
    public boolean needsCanvas(){return false;} public float getEditWidth(){return 190*Math.max(.5f,Config.blockCountDisplayScale);}public float getEditHeight(){return 58*Math.max(.5f,Config.blockCountDisplayScale);}public float getDefaultY(int h){return h*.5f-getEditHeight()/2;}public float getRenderX(int w){return w*.5f+Config.blockCountDisplayX-getEditWidth()/2;}public float getRenderY(int h){return h*.5f+Config.blockCountDisplayY-getEditHeight()/2;}
    public void tick(class_310 mc){if(!Config.blockCountDisplay||mc.field_1724==null)return;class_1799 held=mc.field_1724.method_6047();int slot=mc.field_1724.method_31548().method_67532(),count=held.method_7960()?0:held.method_7947();if(slot!=lastSlot||count!=lastCount){if(!held.method_7960()){stack=held.method_7972();visible=true;until=System.currentTimeMillis()+900;anim=0;}lastSlot=slot;lastCount=count;}}
    public void triggerUse(class_310 mc){if(!Config.blockCountDisplay)return;clicks.record();visible=true;until=System.currentTimeMillis()+900;stack=mc.field_1724==null?class_1799.field_8037:mc.field_1724.method_6047().method_7972();}
    public void recordPlacement(class_310 mc){if(!Config.blockCountDisplay)return;placements.record();visible=true;until=System.currentTimeMillis()+900;stack=mc.field_1724==null?class_1799.field_8037:mc.field_1724.method_6047().method_7972();}
    public void render(class_332 g, Object ignored){class_310 mc=class_310.method_1551();if(!Config.blockCountDisplay||mc.field_1724==null)return;long now=System.currentTimeMillis();float dt=.016f;if(visible)anim=Math.min(1,anim+dt*6);else anim=Math.max(0,anim-dt*6);if(now>until)visible=false;if(!visible&&anim<=0)return;float s=Math.max(.5f,Config.blockCountDisplayScale),w=190,h=58;int x=Math.round(getRenderX(mc.method_22683().method_4486())),y=Math.round(getRenderY(mc.method_22683().method_4502()));NativeGlassVisualSystem.renderHudDock(g,x,y,Math.round(w*s),Math.round(h*s),.78f*anim);g.method_51448().pushMatrix();g.method_51448().translate(x,y);g.method_51448().scale(s,s);if(!stack.method_7960()){g.method_51445(stack,12,12);g.method_51431(mc.field_1772,stack,12,12);}String name=stack.method_7960()?"Block":stack.method_7964().getString();if(name.length()>18)name=name.substring(0,18)+"…";g.method_51433(mc.field_1772,name,48,12,0xF0F5F7,false);g.method_51433(mc.field_1772,"COUNT "+(stack.method_7960()?0:stack.method_7947()),48,27,0xB9C6CC,false);g.method_51433(mc.field_1772,"RMB "+clicks.getCps()+"   PLACE "+placements.getCps(),48,41,0x788992,false);g.method_51448().popMatrix();}
    public void renderFrameEnd(){}
    private static final class RateCounter{private final java.util.ArrayDeque<Long> q=new java.util.ArrayDeque<>();void record(){long n=System.currentTimeMillis();q.add(n);while(!q.isEmpty()&&n-q.peek()>1000)q.poll();}int getCps(){long n=System.currentTimeMillis();while(!q.isEmpty()&&n-q.peek()>1000)q.poll();return q.size();}}
}
