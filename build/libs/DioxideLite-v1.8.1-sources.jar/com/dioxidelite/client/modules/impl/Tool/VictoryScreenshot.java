package com.dioxidelite.client.modules.impl.Tool;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.NotificationOverlay;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_642;

public class VictoryScreenshot {
    private static long lastShotTime = 0;
    private static final long COOLDOWN_MS = 5000;

    public static void tryCapture() {
        if (!Config.autoScreenshot) return;

        long now = System.currentTimeMillis();
        if (now - lastShotTime < COOLDOWN_MS) return;
        lastShotTime = now;

        class_310 client = class_310.method_1551();
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy_MM_dd"));
        String serverPart = getServerPart(client);
        String customFileName = "Victory_" + date + serverPart + "_" + (now % 10000) + ".png";

        CompletableFuture.delayedExecutor(600, TimeUnit.MILLISECONDS).execute(() -> {
            client.execute(() -> {
                class_318.method_1659(client.field_1697, client.method_1522(), (component) -> {
                    String fileName = extractFileName(component.getString());
                    if (fileName != null) {
                        transferFile(client, fileName, customFileName);
                    }
                });
            });
        });
    }

    private static String extractFileName(String message) {
        if (message == null) return null;
        Pattern pattern = Pattern.compile("(\\d{4}-\\d{2}-\\d{2}_\\d{2}\\.\\d{2}\\.\\d{2}\\.png)");
        Matcher matcher = pattern.matcher(message);
        if (matcher.find()) return matcher.group(1);
        if (message.contains("[") && message.contains("]")) {
            return message.substring(message.lastIndexOf("[") + 1, message.lastIndexOf("]"));
        }
        return null;
    }

    private static void transferFile(class_310 client, String originalName, String newName) {
        new Thread(() -> {
            try {
                Thread.sleep(1000);
                Path source = client.field_1697.toPath().resolve("screenshots").resolve(originalName);
                Path desktop = getDesktopPath();
                if (desktop != null && Files.exists(source)) {
                    Path target = desktop.resolve(newName);
                    Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
                    if (Files.exists(target)) {
                        Files.delete(source);
                        client.execute(() -> {
                            String msg = Config.isChinese ? "截图已保存至桌面" : "Screenshot saved to desktop";
                            NotificationOverlay.getInstance().show(msg, 0xFFFFFF);
                        });
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private static String getServerPart(class_310 client) {
        class_642 server = client.method_1558();
        if (server != null && server.field_3761 != null) {
            return "_" + server.field_3761.split(":")[0].toLowerCase().replaceAll("[^a-z0-9]", "_");
        }
        return client.field_1687 != null ? "_singleplayer" : "";
    }

    private static Path getDesktopPath() {
        String home = System.getProperty("user.home");
        if (home == null) return null;
        Path[] paths = {Path.of(home, "Desktop"), Path.of(home, "桌面"), Path.of(home, "OneDrive", "Desktop"), Path.of(home, "OneDrive", "桌面")};
        for (Path p : paths) { if (Files.exists(p)) return p; }
        return null;
    }
}
