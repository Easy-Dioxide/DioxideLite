package com.dioxidelite.client.modules.impl.Render.BetterChat;

import com.dioxidelite.Config;
import com.dioxidelite.mixin.client.ChatHudAccessor;
import com.dioxidelite.mixin.client.ChatHudLineAccessor;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_303;
import net.minecraft.class_310;

public final class BetterChatState {
    private static final BetterChatState INSTANCE = new BetterChatState();

    public static BetterChatState getInstance() {
        return INSTANCE;
    }

    private final List<Long> messageTimestamps = new ArrayList<>();
    private int chatDisplacementY;
    private boolean chatScreenOpenedLastFrame;
    private boolean chatScreenClosing;
    private long chatScreenAnimationStart;
    private float chatScreenOffsetY;

    private BetterChatState() {}

    public void recordMessage() {
        messageTimestamps.addFirst(System.currentTimeMillis());
    }

    public void trimMessageCount(int maxCount) {
        while (messageTimestamps.size() > maxCount) {
            messageTimestamps.removeLast();
        }
    }

    public int calculateChatDisplacementY(int lineHeight, int chatScrollbarPos) {
        if (!Config.betterChat || !Config.betterChatMessageAnimation || messageTimestamps.isEmpty()) {
            chatDisplacementY = 0;
            return 0;
        }
        if (chatScrollbarPos != 0) {
            chatDisplacementY = 0;
            return 0;
        }
        long timeAlive = System.currentTimeMillis() - messageTimestamps.getFirst();
        int fadeTime = Math.max(1, Config.betterChatMessageFadeTime);
        if (timeAlive >= fadeTime) {
            chatDisplacementY = 0;
            return 0;
        }
        float maxDisplacement = lineHeight * 0.8f;
        chatDisplacementY = (int) (maxDisplacement - (((float) timeAlive / fadeTime) * maxDisplacement));
        return chatDisplacementY;
    }

    public void beginChatScreenIfNeeded(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1724.method_6113()) return;
        if (!chatScreenOpenedLastFrame) {
            chatScreenOpenedLastFrame = true;
            chatScreenAnimationStart = System.currentTimeMillis();
            chatScreenClosing = false;
        }
    }

    public float calculateChatScreenOffsetY(class_310 client) {
        if (!Config.betterChat || !Config.betterChatInputAnimation) {
            chatScreenOffsetY = 0;
            return 0;
        }
        if (client == null) {
            chatScreenOffsetY = 0;
            return 0;
        }
        float elapsed = System.currentTimeMillis() - chatScreenAnimationStart;
        int fadeTime = Math.max(1, Config.betterChatInputFadeTime);
        float alpha = chatScreenClosing ? elapsed / fadeTime : 1 - (elapsed / fadeTime);
        alpha = Math.max(0, Math.min(1, alpha));
        float eased = (float) (1.70158f + 1f) * alpha * alpha * alpha - 1.70158f * alpha * alpha;
        float screenFactor = (float) client.method_22683().method_4507() / 1080f;
        chatScreenOffsetY = eased * 10f * screenFactor;
        return chatScreenOffsetY;
    }

    public void startClosing() {
        if (!Config.betterChatInputAnimation) return;
        chatScreenClosing = true;
        chatScreenAnimationStart = System.currentTimeMillis();
    }

    public boolean isChatScreenClosing() {
        return chatScreenClosing;
    }

    public boolean shouldCloseChatScreen() {
        if (!chatScreenClosing) return false;
        int fadeTime = Math.max(1, Config.betterChatInputFadeTime);
        return (System.currentTimeMillis() - chatScreenAnimationStart) >= fadeTime;
    }

    public void resetChatScreenState() {
        chatScreenOpenedLastFrame = false;
        chatScreenClosing = false;
        chatScreenAnimationStart = 0L;
        chatScreenOffsetY = 0f;
    }

    public boolean hasActiveChatMessages(class_310 client) {
        if (client == null || client.field_1705 == null || client.field_1705.method_1743() == null) return false;
        try {
            List<?> messages = ((ChatHudAccessor) client.field_1705.method_1743()).getVisibleMessages();
            int ticks = client.field_1705.method_1738();
            final int fadeTicks = 200;
            for (Object msg : messages) {
                if (msg instanceof class_303 line) {
                    int creationTick = ((ChatHudLineAccessor) (Object) line).getCreationTick();
                    if (ticks - creationTick < fadeTicks) {
                        return true;
                    }
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }
}
