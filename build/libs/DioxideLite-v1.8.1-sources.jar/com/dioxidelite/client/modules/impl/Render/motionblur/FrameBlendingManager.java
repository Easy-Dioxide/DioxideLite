package com.dioxidelite.client.modules.impl.Render.motionblur;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.dioxidelite.mixin.client.PostChainAccessor;
import com.dioxidelite.mixin.client.PostPassAccessor;
import com.dioxidelite.mixin.client.ShaderManagerAccessor;
import org.jspecify.annotations.NonNull;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_283;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_6364;
import net.minecraft.class_9916;
import net.minecraft.class_9922;
import net.minecraft.class_9925;
import net.minecraft.class_9960;

public final class FrameBlendingManager {
    private static final int FRAME_BLEND_UBO_SIZE = 64;
    private static final int ACCUM_UBO_SIZE = 16;
    private static final int MAX_HISTORY = 12;
    private static final int UBO_RING_SIZE = 3;
    private static final String MAIN_SAMPLER = "Main";
    private static final String PREV_SAMPLER = "Prev";
    private static final String FRAME_BLEND_UBO = "FrameBlendParamsUniforms";
    private static final String ACCUM_UBO = "AccumulationUniforms";
    private static final class_2960 FRAME_BLENDING_ID = class_2960.method_60655("dioxide_lite", "frame_blending");
    private static final class_2960 ACCUMULATION_MAX_ID = class_2960.method_60655("dioxide_lite", "accumulation_max");
    private static final class_2960 ACCUMULATION_MIX_ID = class_2960.method_60655("dioxide_lite", "accumulation_mix");
    private static final String[] SAMPLE_NAMES = new String[MAX_HISTORY];

    static {
        for (int i = 0; i < MAX_HISTORY; i++) SAMPLE_NAMES[i] = "Sample" + i;
    }

    private static class_279 cachedCombineChain = null;
    private static final ManagedUniformBuffer.Ring combineUBORing = new ManagedUniformBuffer.Ring(FRAME_BLEND_UBO, FRAME_BLEND_UBO_SIZE, UBO_RING_SIZE);
    private static final class_276[] historyTargets = new class_276[MAX_HISTORY];
    private static final MutableTextureInput[] historyInputs = new MutableTextureInput[MAX_HISTORY];
    private static final double[] historyTimestamps = new double[MAX_HISTORY];
    private static final int[] weightedHistoryIndices = new int[MAX_HISTORY];
    private static final float[] weightedHistoryWeights = new float[MAX_HISTORY];
    private static int historyWriteIndex = 0;
    private static int historyFilled = 0;
    private static float smoothedFPS = 0;
    private static class_279 cachedAccumMaxChain = null;
    private static class_279 cachedAccumMixChain = null;
    private static final ManagedUniformBuffer accumSimpleUBO = new ManagedUniformBuffer(ACCUM_UBO, ACCUM_UBO_SIZE);
    private static class_276 accumReadTarget = null;
    private static class_276 accumWriteTarget = null;
    private static MutableTextureInput injectedMainInput = null;
    private static MutableTextureInput injectedPrevInput = null;
    private static boolean accumHasPrevious = false;
    private static int targetW = 0;
    private static int targetH = 0;
    private static final Set<String> loadErrorLogged = new HashSet<>();

    private FrameBlendingManager() {}

    public static void applyFrameBlending(class_9922 allocator, float fps, int refreshRate) {
        class_310 client = class_310.method_1551();
        class_276 main = client.method_1522();
        updateSmoothedFPS(fps);
        if (refreshRate <= 0) {
            historyWriteIndex = 0;
            historyFilled = 0;
            return;
        }

        ensureTargets(main.field_1482, main.field_1481);
        double now = currentTimeSeconds();
        pushHistoryFrame(main, now);
        int sampleCount = buildWeightedSampleList(now, refreshRate, smoothedFPS);
        if (sampleCount <= 1) return;

        class_279 combineChain = loadFrameBlendChain(client);
        if (combineChain == null) return;
        class_283 combinePass = firstPass(combineChain);
        if (combinePass == null) return;
        Map<String, GpuBuffer> combineUniforms = ((PostPassAccessor) combinePass).getCustomUniforms();
        if (!combineUniforms.containsKey(FRAME_BLEND_UBO)) return;

        GpuBuffer combineUBO = combineUBORing.putNext(combineChain, combineUniforms, FRAME_BLEND_UBO);
        try {
            writeBlendParamsUBO(combineUBO, inverseTotalWeight(sampleCount), sampleCount);
            class_276 fallback = historyTargets[weightedHistoryIndices[sampleCount - 1]];
            for (int i = 0; i < MAX_HISTORY; i++) {
                class_276 target = i < sampleCount ? historyTargets[weightedHistoryIndices[i]] : fallback;
                MutableTextureInput input = historyInputs[i];
                if (input == null) {
                    input = new MutableTextureInput(SAMPLE_NAMES[i], target);
                    historyInputs[i] = input;
                } else {
                    input.setTarget(target);
                }
                setSampler(combinePass, SAMPLE_NAMES[i], input);
            }
            combineChain.method_1258(main, allocator);
        } catch (RuntimeException e) {
            if (combineUBORing.resetIfClosed(e)) return;
            throw e;
        }
    }

    public static void applyAccumulationMax(class_9922 allocator, float strength) {
        applyAccumulationInternal(allocator, strength * 7.0f, "accumulation_max", true);
    }

    public static void applyAccumulationMix(class_9922 allocator, float strength) {
        applyAccumulationInternal(allocator, strength * 5.0f, "accumulation_mix", false);
    }

    public static void invalidate() {
        for (int i = 0; i < historyTargets.length; i++) {
            if (historyTargets[i] != null) {
                historyTargets[i].method_1238();
                historyTargets[i] = null;
            }
            historyInputs[i] = null;
            historyTimestamps[i] = 0.0;
        }
        if (accumReadTarget != null) {
            accumReadTarget.method_1238();
            accumReadTarget = null;
        }
        if (accumWriteTarget != null) {
            accumWriteTarget.method_1238();
            accumWriteTarget = null;
        }
        combineUBORing.reset();
        accumSimpleUBO.reset();
        targetW = 0;
        targetH = 0;
        historyWriteIndex = 0;
        historyFilled = 0;
        smoothedFPS = 0;
        Arrays.fill(weightedHistoryIndices, 0);
        Arrays.fill(weightedHistoryWeights, 0.0f);
        cachedCombineChain = null;
        cachedAccumMaxChain = null;
        cachedAccumMixChain = null;
        injectedMainInput = null;
        injectedPrevInput = null;
        accumHasPrevious = false;
        loadErrorLogged.clear();
    }

    private static void updateSmoothedFPS(float fps) {
        if (fps > 0.0f) smoothedFPS = smoothedFPS <= 0.0f ? fps : smoothedFPS * 0.85f + fps * 0.15f;
    }

    private static void pushHistoryFrame(class_276 src, double timestamp) {
        if (historyTargets[historyWriteIndex] == null) return;
        copyTexture(src, historyTargets[historyWriteIndex]);
        historyTimestamps[historyWriteIndex] = timestamp;
        historyWriteIndex = (historyWriteIndex + 1) % MAX_HISTORY;
        if (historyFilled < MAX_HISTORY) historyFilled++;
    }

    private static int buildWeightedSampleList(double exposureEnd, int refreshRate, float fps) {
        Arrays.fill(weightedHistoryWeights, 0.0f);
        if (historyFilled <= 0) return 0;

        double exposureStart = exposureEnd - (1.0 / refreshRate);
        double estimatedFrameTime = fps > 0.0f ? 1.0 / fps : 1.0 / refreshRate;
        double totalWeight = 0.0;
        int sampleCount = 0;
        int firstIndex = historyWriteIndex - historyFilled;
        if (firstIndex < 0) firstIndex += MAX_HISTORY;

        for (int i = 0; i < historyFilled; i++) {
            int idx = (firstIndex + i) % MAX_HISTORY;
            double frameEnd = historyTimestamps[idx];
            if (frameEnd <= 0.0) continue;
            double frameStart;
            if (i > 0) {
                int prevIdx = (firstIndex + i - 1) % MAX_HISTORY;
                frameStart = historyTimestamps[prevIdx];
            } else {
                frameStart = frameEnd - estimatedFrameTime;
            }
            if (frameStart >= frameEnd) frameStart = frameEnd - estimatedFrameTime;

            double overlap = Math.min(frameEnd, exposureEnd) - Math.max(frameStart, exposureStart);
            if (overlap > 0.0000001) {
                weightedHistoryIndices[sampleCount] = idx;
                weightedHistoryWeights[sampleCount] = (float) overlap;
                totalWeight += overlap;
                sampleCount++;
            }
        }
        if (sampleCount <= 0 || totalWeight <= 0.0000001) return 0;
        return sampleCount;
    }

    private static float inverseTotalWeight(int sampleCount) {
        float totalWeight = 0.0f;
        for (int i = 0; i < sampleCount; i++) totalWeight += weightedHistoryWeights[i];
        return totalWeight > 0.0f ? 1.0f / totalWeight : 1.0f;
    }

    private static double currentTimeSeconds() {
        return System.nanoTime() * 1.0E-9;
    }

    private static void applyAccumulationInternal(class_9922 allocator, float strength, String shaderName, boolean isMax) {
        class_310 client = class_310.method_1551();
        class_276 main = client.method_1522();
        ensureTargets(main.field_1482, main.field_1481);
        if (!accumHasPrevious) {
            copyTexture(main, accumReadTarget);
            accumHasPrevious = true;
            return;
        }

        class_279 chain = loadAccumSimpleChain(client, shaderName, isMax);
        if (chain == null) return;
        class_283 pass = firstPass(chain);
        if (pass == null) return;
        Map<String, GpuBuffer> uniforms = ((PostPassAccessor) pass).getCustomUniforms();
        if (!uniforms.containsKey(ACCUM_UBO)) return;

        GpuBuffer ubo = accumSimpleUBO.put(chain, uniforms, ACCUM_UBO);
        try {
            writeFloatUBO(ubo, strengthToBlendFactor(strength));
            if (injectedMainInput == null) injectedMainInput = new MutableTextureInput(MAIN_SAMPLER, main);
            else injectedMainInput.setTarget(main);
            setSampler(pass, MAIN_SAMPLER, injectedMainInput);

            if (injectedPrevInput == null) injectedPrevInput = new MutableTextureInput(PREV_SAMPLER, accumReadTarget);
            else injectedPrevInput.setTarget(accumReadTarget);
            setSampler(pass, PREV_SAMPLER, injectedPrevInput);

            chain.method_1258(accumWriteTarget, allocator);
            copyTexture(accumWriteTarget, main);
            swapAccumTargets();
        } catch (RuntimeException e) {
            if (accumSimpleUBO.resetIfClosed(e)) return;
            throw e;
        }
    }

    private static float strengthToBlendFactor(float strength) {
        return (float) (1.0 - Math.pow(0.5, strength / 3.0));
    }

    private static class_279 loadAccumSimpleChain(class_310 client, String shaderName, boolean isMax) {
        try {
            net.minecraft.class_10151.class_10170 cache = ((ShaderManagerAccessor) client.method_62887()).getCompilationCache();
            if (cache == null) return null;
            class_279 result = cache.method_63523(isMax ? ACCUMULATION_MAX_ID : ACCUMULATION_MIX_ID, class_9960.field_53902);
            if (isMax && result != cachedAccumMaxChain) {
                cachedAccumMaxChain = result;
                injectedMainInput = null;
                injectedPrevInput = null;
            } else if (!isMax && result != cachedAccumMixChain) {
                cachedAccumMixChain = result;
                injectedMainInput = null;
                injectedPrevInput = null;
            }
            loadErrorLogged.remove(shaderName);
            return result;
        } catch (Exception e) {
            if (loadErrorLogged.add(shaderName)) System.err.println("[DioxideLite] Failed to load dynamic blur " + shaderName + " shader: " + e.getMessage());
            return null;
        }
    }

    private static void ensureTargets(int w, int h) {
        if (targetW == w && targetH == h && historyTargets[0] != null && accumReadTarget != null && accumWriteTarget != null) return;
        for (int i = 0; i < historyTargets.length; i++) {
            if (historyTargets[i] != null) historyTargets[i].method_1238();
            historyTargets[i] = new class_6364(w, h);
            historyInputs[i] = null;
            historyTimestamps[i] = 0.0;
        }
        if (accumReadTarget != null) accumReadTarget.method_1238();
        if (accumWriteTarget != null) accumWriteTarget.method_1238();
        accumReadTarget = new class_6364(w, h);
        accumWriteTarget = new class_6364(w, h);
        targetW = w;
        targetH = h;
        historyWriteIndex = 0;
        historyFilled = 0;
        Arrays.fill(weightedHistoryIndices, 0);
        Arrays.fill(weightedHistoryWeights, 0.0f);
        injectedMainInput = null;
        injectedPrevInput = null;
        accumHasPrevious = false;
    }

    private static void swapAccumTargets() {
        class_276 temp = accumReadTarget;
        accumReadTarget = accumWriteTarget;
        accumWriteTarget = temp;
    }

    private static void copyTexture(class_276 src, class_276 dst) {
        if (src == null || dst == null) return;
        assert src.method_30277() != null;
        assert dst.method_30277() != null;
        RenderSystem.getDevice().createCommandEncoder().copyTextureToTexture(src.method_30277(), dst.method_30277(), 0, 0, 0, 0, 0, dst.field_1482, dst.field_1481);
    }

    private static class_283 firstPass(class_279 chain) {
        List<class_283> passes = ((PostChainAccessor) chain).getPasses();
        return passes.isEmpty() ? null : passes.getFirst();
    }

    private static void setSampler(class_283 pass, String samplerName, class_283.class_9971 replacement) {
        List<class_283.class_9971> inputs = ((PostPassAccessor) pass).getInputs();
        for (int i = 0; i < inputs.size(); i++) {
            if (samplerName.equals(inputs.get(i).comp_3038())) {
                if (inputs.get(i) != replacement) inputs.set(i, replacement);
                return;
            }
        }
    }

    private static void writeFloatUBO(GpuBuffer ubo, float value) {
        try (GpuBuffer.MappedView view = RenderSystem.getDevice().createCommandEncoder().mapBuffer(ubo, false, true)) {
            Std140Builder b = Std140Builder.intoBuffer(view.data());
            b.putFloat(value);
            b.putInt(0);
            b.putInt(0);
            b.putInt(0);
        }
    }

    private static void writeBlendParamsUBO(GpuBuffer ubo, float invTotalWeight, int sampleCount) {
        try (GpuBuffer.MappedView view = RenderSystem.getDevice().createCommandEncoder().mapBuffer(ubo, false, true)) {
            Std140Builder b = Std140Builder.intoBuffer(view.data());
            b.putFloat(invTotalWeight);
            b.putInt(sampleCount);
            for (int i = 0; i < MAX_HISTORY; i++) b.putFloat(i < sampleCount ? weightedHistoryWeights[i] : 0.0f);
            b.putFloat(0.0f);
            b.putFloat(0.0f);
        }
    }

    private static class_279 loadFrameBlendChain(class_310 client) {
        try {
            net.minecraft.class_10151.class_10170 cache = ((ShaderManagerAccessor) client.method_62887()).getCompilationCache();
            if (cache == null) return null;
            class_279 result = cache.method_63523(FRAME_BLENDING_ID, class_9960.field_53902);
            if (result != cachedCombineChain) cachedCombineChain = result;
            loadErrorLogged.remove("frame_blending");
            return result;
        } catch (Exception e) {
            if (loadErrorLogged.add("frame_blending")) System.err.println("[DioxideLite] Failed to load dynamic blur frame_blending shader: " + e.getMessage());
            return null;
        }
    }

    private static class MutableTextureInput implements class_283.class_9971 {
        private final String samplerName;
        private class_276 target;

        MutableTextureInput(String samplerName, class_276 target) {
            this.samplerName = samplerName;
            this.target = target;
        }

        void setTarget(class_276 target) {
            this.target = target;
        }

        @Override public void method_62259(@NonNull class_9916 pass, @NonNull Map<class_2960, class_9925<class_276>> targets) {}
        @Override public @NonNull GpuTextureView method_71128(@NonNull Map<class_2960, class_9925<class_276>> targets) {
            assert target.method_71639() != null;
            return target.method_71639();
        }
        @Override public @NonNull String comp_3038() { return samplerName; }
        @Override public boolean comp_3037() { return false; }
    }
}
