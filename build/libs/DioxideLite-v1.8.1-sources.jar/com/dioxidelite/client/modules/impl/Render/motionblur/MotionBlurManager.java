package com.dioxidelite.client.modules.impl.Render.motionblur;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.dioxidelite.Config;
import com.dioxidelite.mixin.client.PostChainAccessor;
import com.dioxidelite.mixin.client.PostPassAccessor;
import com.dioxidelite.mixin.client.ShaderManagerAccessor;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_279;
import net.minecraft.class_283;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_9922;
import net.minecraft.class_9960;

public final class MotionBlurManager {
    private static final FrameTimer frameTimer = new FrameTimer();
    private static final CameraState cameraState = new CameraState();
    private static final BlurStrengthCalculator strengthCalc = new BlurStrengthCalculator();
    private static final Set<String> loadErrorLogged = new HashSet<>();

    private static class_9922 frameAllocator = null;
    private static class_279 cachedPreProcessor = null;
    private static class_279 cachedF5Processor = null;
    private static class_279 cachedPostProcessor = null;
    private static final int UBO_SIZE = 304;
    private static final ManagedUniformBuffer preEntityUBO = new ManagedUniformBuffer("PreEntityBlurUniforms", UBO_SIZE);
    private static final ManagedUniformBuffer f5EntityUBO = new ManagedUniformBuffer("PreEntityBlurUniforms", UBO_SIZE);
    private static final ManagedUniformBuffer postRenderUBO = new ManagedUniformBuffer("PostRenderBlurUniforms", UBO_SIZE);

    private enum BlurPass { NORMAL_PRE, SPECIAL_F5, NORMAL_POST }

    private MotionBlurManager() {}

    public static void captureAllocator(class_9922 allocator) { frameAllocator = allocator; }
    public static void clearFrameAllocator() { frameAllocator = null; }
    public static void beginFrame() { frameTimer.beginFrame(); }

    public static void invalidate() {
        preEntityUBO.reset();
        f5EntityUBO.reset();
        postRenderUBO.reset();
        FrameBlendingManager.invalidate();
        cachedPreProcessor = null;
        cachedF5Processor = null;
        cachedPostProcessor = null;
        loadErrorLogged.clear();
    }

    public static boolean shouldRun() {
        return Config.dynamicMotionBlur && Config.dynamicMotionBlurStrength != 0.0f;
    }

    public static void setFrameMotionBlur(Matrix4f modelView, Matrix4f prevModelView, Matrix4f projection, Matrix4f prevProjection, float dx, float dy, float dz) {
        cameraState.setFrame(modelView, prevModelView, projection, prevProjection, dx, dy, dz);
    }

    public static void applyPreEntityBlur() {
        if (shouldRun() && usesVelocityBlur()) applyBlurInternal(BlurPass.NORMAL_PRE);
    }

    public static void applyF5EntityRideBlur() {
        if (shouldRun() && usesVelocityBlur()) applyBlurInternal(BlurPass.SPECIAL_F5);
    }

    public static void applyPostRenderVelocityOnly() {
        if (shouldRun() && usesVelocityBlur()) applyBlurInternal(BlurPass.NORMAL_POST);
    }

    public static void applyTemporalBlur() {
        if (frameAllocator == null || !shouldRun()) return;

        switch (Config.motionBlurAlgorithm) {
            case FRAME_BLENDING, HYBRID_BLENDING -> FrameBlendingManager.applyFrameBlending(frameAllocator, frameTimer.getFPS(), frameTimer.getRefreshRate());
            case ACCUMULATION_MAX -> FrameBlendingManager.applyAccumulationMax(frameAllocator, Config.dynamicMotionBlurStrength);
            case ACCUMULATION_MIX -> FrameBlendingManager.applyAccumulationMix(frameAllocator, Config.dynamicMotionBlurStrength);
            default -> {}
        }
    }

    private static boolean usesVelocityBlur() {
        return Config.motionBlurAlgorithm == Config.MotionBlurAlgorithm.VELOCITY_BASED || Config.motionBlurAlgorithm == Config.MotionBlurAlgorithm.HYBRID_BLENDING;
    }

    private static void applyBlurInternal(BlurPass pass) {
        if (frameAllocator == null) return;

        class_310 client = class_310.method_1551();
        BlurStrengthCalculator.Result blur = strengthCalc.calculate(
                Config.dynamicMotionBlurStrength,
                frameTimer.getFPS(),
                frameTimer.getRefreshRate(),
                Config.dynamicMotionBlurRefreshRateScaling);
        float viewW = client.method_1522().field_1482;
        float viewH = client.method_1522().field_1481;

        switch (pass) {
            case NORMAL_PRE -> {
                class_279 processor = getPreProcessor(client);
                if (processor != null) writeAndRun(processor, "PreEntityBlurUniforms", preEntityUBO, blur.strength(), viewW, viewH, blur.sampleAmount(), client);
            }
            case SPECIAL_F5 -> {
                class_279 processor = getF5Processor(client);
                if (processor != null) writeAndRun(processor, "PreEntityBlurUniforms", f5EntityUBO, blur.strength(), viewW, viewH, blur.sampleAmount(), client);
            }
            case NORMAL_POST -> {
                class_279 processor = getPostProcessor(client);
                if (processor != null) writeAndRun(processor, "PostRenderBlurUniforms", postRenderUBO, blur.strength(), viewW, viewH, blur.sampleAmount(), client);
            }
        }
    }

    private static class_279 getPreProcessor(class_310 client) {
        class_279 result = loadProcessor(client, "velocity_pre", "pre-entity");
        if (result == null) { cachedPreProcessor = null; return null; }
        if (result != cachedPreProcessor) cachedPreProcessor = result;
        return cachedPreProcessor;
    }

    private static class_279 getF5Processor(class_310 client) {
        class_279 result = loadProcessor(client, "velocity_f5", "F5/entity-riding");
        if (result == null) { cachedF5Processor = null; return null; }
        if (result != cachedF5Processor) cachedF5Processor = result;
        return cachedF5Processor;
    }

    private static class_279 getPostProcessor(class_310 client) {
        class_279 result = loadProcessor(client, "velocity_post", "post-render");
        if (result == null) { cachedPostProcessor = null; return null; }
        if (result != cachedPostProcessor) cachedPostProcessor = result;
        return cachedPostProcessor;
    }

    private static class_279 loadProcessor(class_310 client, String shaderName, String displayName) {
        try {
            net.minecraft.class_10151.class_10170 cache = ((ShaderManagerAccessor) client.method_62887()).getCompilationCache();
            if (cache == null) return null;
            class_279 chain = cache.method_63523(class_2960.method_60655("dioxide_lite", shaderName), class_9960.field_53902);
            loadErrorLogged.remove(shaderName);
            return chain;
        } catch (Exception e) {
            if (loadErrorLogged.add(shaderName)) {
                System.err.println("[DioxideLite] Failed to load dynamic blur " + displayName + " shader: " + e.getMessage());
            }
            return null;
        }
    }

    private static void writeAndRun(class_279 processor, String uboKey, ManagedUniformBuffer managedUBO, float blendFactor, float viewW, float viewH, int sampleAmount, class_310 client) {
        List<class_283> passes = ((PostChainAccessor) processor).getPasses();
        if (passes.isEmpty()) return;

        Map<String, GpuBuffer> uniformBuffers = ((PostPassAccessor) passes.getFirst()).getCustomUniforms();
        if (!uniformBuffers.containsKey(uboKey)) return;

        GpuBuffer ubo = managedUBO.put(processor, uniformBuffers, uboKey);
        try {
            try (GpuBuffer.MappedView view = RenderSystem.getDevice().createCommandEncoder().mapBuffer(ubo, false, true)) {
                Std140Builder b = Std140Builder.intoBuffer(view.data());
                b.putMat4f(cameraState.getMvInverse());
                b.putMat4f(cameraState.getProjInverse());
                b.putMat4f(cameraState.getPrevModelView());
                b.putMat4f(cameraState.getPrevProjection());
                b.putVec3(cameraState.getDx(), cameraState.getDy(), cameraState.getDz());
                b.putVec2(viewW, viewH);
                b.putFloat(blendFactor);
                b.putInt(sampleAmount);
                b.putInt(0);
                b.putInt(1);
            }
            processor.method_1258(client.method_1522(), frameAllocator);
        } catch (RuntimeException e) {
            if (managedUBO.resetIfClosed(e)) return;
            throw e;
        }
    }
}
