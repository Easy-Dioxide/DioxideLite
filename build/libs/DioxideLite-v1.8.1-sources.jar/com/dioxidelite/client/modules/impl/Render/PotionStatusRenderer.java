package com.dioxidelite.client.modules.impl.Render;

import com.dioxidelite.Config;
import com.dioxidelite.client.render.nativeui.NativeGlassVisualSystem;
import java.util.*;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;

/** Native potion/effect HUD with lightweight animation and no off-screen rendering. */
public final class PotionStatusRenderer {
    private static final PotionStatusRenderer INSTANCE=new PotionStatusRenderer(); private static final int WIDTH=134,ROW=28,GAP=5,PAD=7,ICON=18; private static final long HIDE=260;
    private final Map<String,Visual> visuals=new HashMap<>(); private long lastMs;
    public static PotionStatusRenderer getInstance(){return INSTANCE;}
    public void render(class_332 g){class_310 mc=class_310.method_1551();if(!Config.potionStatus){visuals.clear();return;}if(mc.field_1724==null||mc.field_1687==null||mc.field_1690.field_1842)return;long now=System.currentTimeMillis();float dt=lastMs==0?.016f:Math.min(.05f,(now-lastMs)/1000f);lastMs=now;List<class_1293> effects=HudEditOverlay.getInstance().isActive()?preview():visible(mc);Map<String,Boolean> seen=new HashMap<>();int i=0;for(class_1293 e:effects){String k=key(e);seen.put(k,true);Visual v=visuals.computeIfAbsent(k,z->{Visual nv=new Visual();nv.key=k;return nv;});v.e=e;v.targetY=PAD+i*(ROW+GAP);v.visible=true;v.alpha=Math.min(1,v.alpha+dt*9);v.y+=(v.targetY-v.y)*Math.min(1,dt*12);v.fill+=(targetFill(e)-v.fill)*Math.min(1,dt*8);i++;}for(Iterator<Map.Entry<String,Visual>> it=visuals.entrySet().iterator();it.hasNext();){Visual v=it.next().getValue();if(!seen.containsKey(v.key)){v.visible=false;v.alpha-=dt*8;if(v.alpha<=0)it.remove();}}
        if(visuals.isEmpty())return;float h=PAD+effects.size()*(ROW+GAP);float scale=Math.max(.5f,Config.potionStatusScale);int sw=Math.round(WIDTH*scale),sh=Math.round(h*scale);int x=Math.round(Math.max(0,Math.min(mc.method_22683().method_4486()-sw,8+Config.potionStatusX))),y=Math.round(Math.max(0,Math.min(mc.method_22683().method_4502()-sh,(mc.method_22683().method_4502()-sh)/2f+Config.potionStatusY)));NativeGlassVisualSystem.renderHudDock(g,x-4,y-4,sw+8,sh+8,.68f);g.method_51448().pushMatrix();g.method_51448().translate(x,y);g.method_51448().scale(scale,scale);for(Visual v:visuals.values()){if(v.alpha<=.01)continue;int yy=Math.round(v.y);int ea=Math.round(255*v.alpha);int c=0xFF000000|(v.e==null?0x78CFFF:v.e.method_5579().comp_349().method_5556());g.method_25294(PAD,yy,PAD+WIDTH-2,yy+ROW,(Math.round(ea*.72f)<<24)|0x10161C);g.method_25294(PAD,yy,PAD+Math.round((WIDTH-2)*v.fill),yy+ROW,(Math.round(ea*.28f)<<24)|(c&0xFFFFFF));g.method_73198(PAD,yy,WIDTH-2,ROW,(Math.round(ea*.20f)<<24)|0x78CFFF);g.method_25294(PAD+5,yy+5,PAD+5+ICON,yy+5+ICON,(ea<<24)|(c&0xFFFFFF));if(v.e!=null){String n=shortName(v.e);g.method_51433(mc.field_1772,n,PAD+ICON+10,yy+7,(ea<<24)|0xF0F6F8,false);if(Config.potionStatusCountdown){g.method_51433(mc.field_1772,duration(v.e),PAD+ICON+10,yy+18,(Math.round(ea*.72f)<<24)|0xB9C6CC,false);}}}g.method_51448().popMatrix();}
    public int getEditWidth(){return Math.round(WIDTH*Math.max(.5f,Config.potionStatusScale));}public int getEditHeight(){return Math.round((PAD+3*(ROW+GAP))*Math.max(.5f,Config.potionStatusScale));}public float getDefaultX(){return 8;}public float getDefaultY(int h){return (h-getEditHeight())/2f;}public float getRenderX(int w){return Math.max(0,Math.min(w-getEditWidth(),getDefaultX()+Config.potionStatusX));}public float getRenderY(int h){return Math.max(0,Math.min(h-getEditHeight(),getDefaultY(h)+Config.potionStatusY));}
    public boolean shouldHideVanillaEffects(){if(!Config.potionStatus||!Config.potionStatusHideVanilla)return false;class_310 mc=class_310.method_1551();return mc.field_1724!=null&&mc.field_1687!=null&&!mc.field_1690.field_1842&&!visible(mc).isEmpty();}
    private List<class_1293> visible(class_310 mc){List<class_1293> l=new ArrayList<>();for(class_1293 e:mc.field_1724.method_6026())if(e.method_5581())l.add(e);l.sort(Comparator.comparing(class_1293::method_5586));return l;}
    private List<class_1293> preview(){return List.of(new class_1293(class_1294.field_5904,3600,1),new class_1293(class_1294.field_5910,1800,0),new class_1293(class_1294.field_5918,9600,0));}
    private String key(class_1293 e){return e.method_5586()+"#"+e.method_5578();}private float targetFill(class_1293 e){return e.method_48559()?1f:class_3532.method_15363(e.method_5584()/3600f,0,1);}
    private String shortName(class_1293 e){String s=net.minecraft.class_2561.method_43471(e.method_5586()).getString();return s.length()>17?s.substring(0,17)+"…":s;}
    private String duration(class_1293 e){if(e.method_48559())return "∞";int sec=Math.max(0,e.method_5584()/20);return (sec/60)+":"+String.format(Locale.ROOT,"%02d",sec%60);}
    private static final class Visual{String key;class_1293 e;float y,targetY,alpha,fill;boolean visible;Visual(){}}
}
