package com.dioxidelite.client.modules.impl.Tool;

import com.dioxidelite.Config;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_636;
import net.minecraft.class_746;

public final class AutoChestDepositManager {
    private enum Phase { IDLE, WAIT_TRANSFER, WAIT_CLOSE }

    private static Phase phase = Phase.IDLE;
    private static class_3965 targetHit;
    private static int ticksRemaining;
    private static int transferWaitTimeout;
    private static boolean wasAttackDown;
    private static boolean rotationLocked;
    private static float lockedYaw;
    private static float lockedPitch;

    private AutoChestDepositManager() {}

    public static void onChestRendered(class_2595 chest) {
    }

    public static void tick(class_310 client) {
        boolean attackDown = client.field_1690.field_1886.method_1434();
        if (attackDown && !wasAttackDown) {
            tryStart(client);
        }
        wasAttackDown = attackDown;

        if (phase == Phase.IDLE) return;
        if (!Config.autoChestDeposit || client.field_1724 == null || client.field_1761 == null) {
            reset();
            return;
        }

        if (ticksRemaining > 0) {
            ticksRemaining--;
            return;
        }

        switch (phase) {
            case WAIT_TRANSFER -> transferHeldItem(client);
            case WAIT_CLOSE -> closeChest(client.field_1724);
            default -> {}
        }
    }

    public static boolean shouldBlockMovementInput() {
        return phase != Phase.IDLE;
    }

    public static boolean shouldHideContainerScreen(class_437 screen) {
        return phase != Phase.IDLE && screen instanceof class_465<?>;
    }

    private static void tryStart(class_310 client) {
        if (!Config.autoChestDeposit || phase != Phase.IDLE || client.field_1724 == null || client.field_1687 == null || client.field_1755 != null) return;
        if (client.field_1724.method_6047().method_7960()) return;
        if (!canDepositItem(client.field_1724.method_6047())) return;

        class_3965 hit = getCurrentContainerHit(client);
        if (hit == null) return;

        targetHit = hit;
        lockRotation(client.field_1724);
        openChest(client);
    }

    private static class_3965 getCurrentContainerHit(class_310 client) {
        if (client.field_1765 instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332) {
            class_2338 pos = hit.method_17777();
            if (client.field_1687 != null && isSupportedContainer(client, pos)) {
                return hit;
            }
        }
        return null;
    }

    private static boolean isSupportedContainer(class_310 client, class_2338 pos) {
        class_2680 state = client.field_1687.method_8320(pos);
        return getMenuProvider(client, pos) != null || state.method_26204() instanceof class_2336;
    }

    private static class_3908 getMenuProvider(class_310 client, class_2338 pos) {
        if (client.field_1687 == null) return null;
        return client.field_1687.method_8320(pos).method_26196(client.field_1687, pos);
    }

    private static void openChest(class_310 client) {
        if (targetHit == null) {
            reset();
            return;
        }

        class_636 gameMode = client.field_1761;
        class_746 player = client.field_1724;
        if (gameMode == null || player == null) {
            reset();
            return;
        }

        gameMode.method_2896(player, class_1268.field_5808, targetHit);
        ticksRemaining = Math.max(0, Config.autoChestDepositDepositDelay);
        transferWaitTimeout = Math.max(40, ticksRemaining + 40);
        phase = Phase.WAIT_TRANSFER;
    }

    private static void transferHeldItem(class_310 client) {
        class_1703 menu = client.field_1724.field_7512;
        if (menu == client.field_1724.field_7498) {
            if (transferWaitTimeout-- <= 0) reset();
            else ticksRemaining = 1;
            return;
        }

        class_746 player = client.field_1724;
        class_636 gameMode = client.field_1761;
        if (gameMode == null || player.method_6047().method_7960()) {
            reset();
            return;
        }
        if (!canDepositItem(player.method_6047())) {
            reset();
            return;
        }

        int menuSlot = findSelectedHotbarSlot(menu, player);
        if (menuSlot >= 0) {
            gameMode.method_2906(menu.field_7763, menuSlot, 0, class_1713.field_7794, player);
        }

        ticksRemaining = Math.max(0, Config.autoChestDepositCloseDelay);
        phase = Phase.WAIT_CLOSE;
    }

    private static int findSelectedHotbarSlot(class_1703 menu, class_746 player) {
        class_1661 inventory = player.method_31548();
        int selectedSlot = inventory.method_67532();
        for (int i = 0; i < menu.field_7761.size(); i++) {
            class_1735 slot = menu.field_7761.get(i);
            if (slot.field_7871 == inventory && slot.method_34266() == selectedSlot) {
                return i;
            }
        }
        return -1;
    }

    private static boolean canDepositItem(class_1799 stack) {
        if (!Config.autoChestDepositResourcesOnly) return true;
        return stack.method_31574(class_1802.field_8620) || stack.method_31574(class_1802.field_8695) || stack.method_31574(class_1802.field_8687) || stack.method_31574(class_1802.field_8477);
    }

    private static void closeChest(class_746 player) {
        if (player.field_7512 != player.field_7498) {
            player.method_7346();
        }
        reset();
    }

    public static void applyRotationLock(class_746 player) {
        if (!rotationLocked || phase == Phase.IDLE || player == null) return;
        player.method_36456(lockedYaw);
        player.method_36457(lockedPitch);
        player.field_5982 = lockedYaw;
        player.field_6004 = lockedPitch;
    }

    private static void lockRotation(class_746 player) {
        if (player == null) return;
        lockedYaw = player.method_36454();
        lockedPitch = player.method_36455();
        rotationLocked = true;
    }

    private static void reset() {
        phase = Phase.IDLE;
        targetHit = null;
        ticksRemaining = 0;
        transferWaitTimeout = 0;
        rotationLocked = false;
    }
}
