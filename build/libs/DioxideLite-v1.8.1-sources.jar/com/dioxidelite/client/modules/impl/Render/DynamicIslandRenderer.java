package com.dioxidelite.client.modules.impl.Render;

import com.dioxidelite.Config;
import com.dioxidelite.client.render.nativeui.NativeGlassVisualSystem;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1934;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_640;
import net.minecraft.class_642;

/** Native Dynamic Island renderer. No off-screen surfaces or external rasterizer. */
public final class DynamicIslandRenderer {
    private static final DynamicIslandRenderer INSTANCE=new DynamicIslandRenderer();
    private static final int MIN_W=250, TOP=10, H=30;
    private long lastTabRequest;
    private float width=-1, height=-1;
    private long lastNs=System.nanoTime();
    public static DynamicIslandRenderer getInstance(){return INSTANCE;}
    public void requestTabListFrame(){lastTabRequest=System.currentTimeMillis();}
    public void render(class_332 g){
        class_310 mc=class_310.method_1551(); if(!Config.dynamicIsland||mc.field_1724==null||mc.method_22683()==null||mc.field_1755 instanceof class_465<?>)return;
        boolean tab=isTabOpen(mc); List<class_640> players=tab?getPlayers(mc):List.of();
        float targetW=tab?measureTab(mc,players):measureCompact(mc); float targetH=tab?Math.min(20+Math.max(1,(players.size()+5)/6)*15,mc.method_22683().method_4502()-20):H;
        float dt=Math.min(.05f,(System.nanoTime()-lastNs)/1e9f);lastNs=System.nanoTime(); if(width<0){width=targetW;height=targetH;} else {width+=(targetW-width)*Math.min(1,dt*13);height+=(targetH-height)*Math.min(1,dt*13);}
        int x=Math.round((mc.method_22683().method_4486()-width)/2), y=TOP; int iw=Math.round(width), ih=Math.round(height);
        NativeGlassVisualSystem.renderHudDock(g,x,y,iw,ih,.82f);
        if(tab)drawTab(g,mc,players,x,y,iw,ih); else drawCompact(g,mc,x,y,iw);
    }
    private boolean isTabOpen(class_310 mc){return (mc.field_1690!=null&&mc.field_1690.field_1907.method_1434())||System.currentTimeMillis()-lastTabRequest<120;}
    private float measureCompact(class_310 mc){String server=location(mc);String s=(mc.method_1548()==null?"Player":mc.method_1548().method_1676())+"  ·  "+server+"  ·  FPS "+mc.method_47599();return Math.max(MIN_W,mc.field_1772.method_1727(s)+36)*Config.dynamicIslandWidthScale;}
    private float measureTab(class_310 mc,List<class_640> p){int cols=Math.max(1,Math.min(6,(p.size()+19)/20));int rows=Math.max(1,(p.size()+cols-1)/cols);return Math.min(mc.method_22683().method_4486()-34,Math.max(340,cols*150+(cols-1)*16+36));}
    private void drawCompact(class_332 g,class_310 mc,int x,int y,int w){String server=location(mc);String user=mc.method_1548()==null?"Player":mc.method_1548().method_1676();String left=user+"  ·  "+server;g.method_51433(mc.field_1772,left,x+18,y+10,0xEFFFFFFF,false);String fps="FPS "+mc.method_47599();g.method_51433(mc.field_1772,fps,x+w-18-mc.field_1772.method_1727(fps),y+10,0xFF78CFFF,false);}
    private void drawTab(class_332 g,class_310 mc,List<class_640> p,int x,int y,int w,int h){int cols=Math.max(1,Math.min(6,(p.size()+19)/20));int rows=Math.max(1,(p.size()+cols-1)/cols);int colW=(w-36-(cols-1)*16)/cols;for(int i=0;i<p.size();i++){int c=i/rows,r=i%rows;class_640 info=p.get(i);String n=info.method_2966().name();if(n==null)n="Player";if(n.length()>18)n=n.substring(0,18);String ping=info.method_2959()+"ms";int xx=x+18+c*(colW+16),yy=y+12+r*15;int color=info.method_2958()==class_1934.field_9219?0xFF8E98A2:0xFFEAF2F4;g.method_51433(mc.field_1772,n,xx,yy,color,false);g.method_51433(mc.field_1772,ping,xx+colW-mc.field_1772.method_1727(ping),yy,0xFF6D7D86,false);}}
    private List<class_640> getPlayers(class_310 mc){if(mc.method_1562()==null)return List.of();List<class_640> p=new ArrayList<>(mc.method_1562().method_45732());p.sort(Comparator.comparingInt(class_640::method_62154).thenComparing(i->i.method_2966().name().toLowerCase()));return p;}
    private String location(class_310 mc){class_642 s=mc.method_1558();return s==null?"Singleplayer":s.field_3761;}
}
