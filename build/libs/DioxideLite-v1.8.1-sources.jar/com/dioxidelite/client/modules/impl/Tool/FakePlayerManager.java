package com.dioxidelite.client.modules.impl.Tool;

import com.mojang.authlib.GameProfile;
import com.dioxidelite.client.Version;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3966;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.minecraft.class_746;

public class FakePlayerManager {
    private static class_745 fakePlayer;
    private static boolean enabled = false;
    private static boolean armor = true;
    private static boolean totem = false;
    private static class_638 level;
    private static long respawnAt = 0L;
    private static int regenerationTicks = 0;
    private static int particleTicks = 0;

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean value) {
        enabled = value;
        if (!value) {
            remove();
        }
    }

    public static boolean hasArmor() {
        return armor;
    }

    public static void setArmor(boolean value) {
        armor = value;
        applyEquipment();
    }

    public static boolean hasTotem() {
        return totem;
    }

    public static void setTotem(boolean value) {
        totem = value;
        applyEquipment();
    }

    public static void tick(class_310 client) {
        if (!Version.DEBUG || !enabled) {
            remove();
            return;
        }

        long now = System.currentTimeMillis();
        class_746 player = client.field_1724;
        class_638 currentLevel = client.field_1687;
        if (player == null || currentLevel == null) {
            remove();
            return;
        }

        if (level != null && level != currentLevel) {
            remove();
        }

        if (fakePlayer == null && respawnAt > 0L) {
            if (now < respawnAt) return;
            respawnAt = 0L;
        }

        if (fakePlayer == null || fakePlayer.method_31481()) {
            clearFakePlayerOnly();
            spawn(client, currentLevel, player);
        }

        if (fakePlayer != null) {
            applyEquipment();
            tickTotemEffects(currentLevel);
            if (!fakePlayer.method_5805() || fakePlayer.method_31481()) {
                scheduleRespawn(currentLevel, fakePlayer);
                return;
            }
        }
    }

    public static boolean tryAttack(class_310 client) {
        if (!Version.DEBUG || !enabled || fakePlayer == null || client.field_1724 == null || client.field_1687 == null) return false;
        if (fakePlayer.method_31481() || !fakePlayer.method_5805()) return false;
        if (!(client.field_1765 instanceof class_3966 hitResult) || hitResult.method_17782() != fakePlayer) return false;

        client.field_1724.method_6104(class_1268.field_5808);
        float damage = armor ? 4.0f : 7.0f;
        class_243 look = client.field_1724.method_5720();
        applyDamageSound(fakePlayer);
        fakePlayer.field_6235 = 10;
        fakePlayer.field_6254 = 10;
        fakePlayer.method_5879((float) client.field_1724.method_36454());
        fakePlayer.method_6005(0.45, -look.field_1352, -look.field_1350);
        if (fakePlayer.method_6032() - damage <= 0.0f && totem && fakePlayer.method_6079().method_31574(class_1802.field_8288)) {
            triggerTotem(client);
            return true;
        }

        fakePlayer.method_6033(Math.max(0.0f, fakePlayer.method_6032() - damage));
        if (!fakePlayer.method_5805() || fakePlayer.method_6032() <= 0.0f) {
            fakePlayer.method_6033(0.0f);
            scheduleRespawn(client.field_1687, fakePlayer);
            return true;
        }
        com.dioxidelite.client.modules.impl.Render.TargetHudRenderer.getInstance().onHit(fakePlayer);
        return true;
    }

    private static void spawn(class_310 client, class_638 currentLevel, class_746 player) {
        GameProfile profile = new GameProfile(UUID.randomUUID(), player.method_5820());
        fakePlayer = new class_745(currentLevel, profile);
        level = currentLevel;

        class_243 look = player.method_5720();
        class_243 pos = player.method_73189().method_1031(look.field_1352 * 2.5, 0.0, look.field_1350 * 2.5);
        fakePlayer.method_5814(pos.field_1352, player.method_23318(), pos.field_1350);
        fakePlayer.method_36456(player.method_36454() + 180.0f);
        fakePlayer.method_36457(0.0f);
        fakePlayer.field_6283 = fakePlayer.method_36454();
        fakePlayer.field_6241 = fakePlayer.method_36454();
        fakePlayer.method_6033(fakePlayer.method_6063());
        currentLevel.method_53875(fakePlayer);
        applyEquipment();
    }

    private static void applyEquipment() {
        if (fakePlayer == null) return;

        fakePlayer.method_5673(class_1304.field_6169, armor ? new class_1799(class_1802.field_22027) : class_1799.field_8037);
        fakePlayer.method_5673(class_1304.field_6174, armor ? new class_1799(class_1802.field_22028) : class_1799.field_8037);
        fakePlayer.method_5673(class_1304.field_6172, armor ? new class_1799(class_1802.field_22029) : class_1799.field_8037);
        fakePlayer.method_5673(class_1304.field_6166, armor ? new class_1799(class_1802.field_22030) : class_1799.field_8037);
        fakePlayer.method_5673(class_1304.field_6171, totem ? new class_1799(class_1802.field_8288) : class_1799.field_8037);
    }

    private static void triggerTotem(class_310 client) {
        if (fakePlayer == null) return;
        fakePlayer.method_6033(1.0f);
        fakePlayer.method_6073(4.0f);
        fakePlayer.method_6092(new class_1293(class_1294.field_5924, 900, 1));
        fakePlayer.method_6092(new class_1293(class_1294.field_5918, 800, 0));
        fakePlayer.method_6092(new class_1293(class_1294.field_5898, 100, 1));
        fakePlayer.method_5711((byte) 35);
        fakePlayer.method_5783(class_3417.field_14931, 1.0f, 1.0f);
        regenerationTicks = 900;
        particleTicks = 40;
        spawnTotemParticles(client.field_1687, 45);
        com.dioxidelite.client.modules.impl.Render.TargetHudRenderer.getInstance().onHit(fakePlayer);
    }

    private static void applyDamageSound(class_745 player) {
        player.method_5783(class_3417.field_15115, 1.0f, 1.0f);
    }

    private static void tickTotemEffects(class_638 currentLevel) {
        if (fakePlayer == null) return;
        if (regenerationTicks > 0) {
            regenerationTicks--;
            if (fakePlayer.method_6067() < 4.0f) {
                fakePlayer.method_6073(4.0f);
            }
            if (regenerationTicks % 25 == 0 && fakePlayer.method_6032() < fakePlayer.method_6063()) {
                fakePlayer.method_6033(Math.min(fakePlayer.method_6063(), fakePlayer.method_6032() + 1.0f));
                com.dioxidelite.client.modules.impl.Render.TargetHudRenderer.getInstance().onHit(fakePlayer);
            }
        }
        if (particleTicks > 0) {
            particleTicks--;
            spawnTotemParticles(currentLevel, 4);
        }
    }

    private static void spawnTotemParticles(class_638 currentLevel, int count) {
        if (currentLevel == null || fakePlayer == null) return;
        for (int i = 0; i < count; i++) {
            double x = fakePlayer.method_23317() + (currentLevel.field_9229.method_43058() - 0.5) * fakePlayer.method_17681() * 1.7;
            double y = fakePlayer.method_23318() + currentLevel.field_9229.method_43058() * fakePlayer.method_17682();
            double z = fakePlayer.method_23321() + (currentLevel.field_9229.method_43058() - 0.5) * fakePlayer.method_17681() * 1.7;
            double vx = (currentLevel.field_9229.method_43058() - 0.5) * 0.35;
            double vy = currentLevel.field_9229.method_43058() * 0.35;
            double vz = (currentLevel.field_9229.method_43058() - 0.5) * 0.35;
            currentLevel.method_8406(class_2398.field_11220, x, y, z, vx, vy, vz);
        }
    }

    private static void remove() {
        clearFakePlayerOnly();
        level = null;
        respawnAt = 0L;
        regenerationTicks = 0;
        particleTicks = 0;
    }

    private static void clearFakePlayerOnly() {
        if (fakePlayer != null) {
            class_638 currentLevel = level;
            if (currentLevel != null) {
                currentLevel.method_2945(fakePlayer.method_5628(), class_1297.class_5529.field_26999);
            } else {
                fakePlayer.method_5650(class_1297.class_5529.field_26999);
            }
            fakePlayer = null;
        }
    }

    private static void scheduleRespawn(class_638 currentLevel, class_745 player) {
        if (currentLevel != null && player != null) {
            currentLevel.method_2945(player.method_5628(), class_1297.class_5529.field_26999);
        }
        fakePlayer = null;
        level = currentLevel;
        respawnAt = System.currentTimeMillis() + 3000L;
        regenerationTicks = 0;
        particleTicks = 0;
    }
}
