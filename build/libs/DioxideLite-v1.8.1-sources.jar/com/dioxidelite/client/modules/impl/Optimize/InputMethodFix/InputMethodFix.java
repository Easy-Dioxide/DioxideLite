package com.dioxidelite.client.modules.impl.Optimize.InputMethodFix;

import com.dioxidelite.Config;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import org.lwjgl.glfw.GLFWNativeWin32;

import java.util.Locale;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_408;
import net.minecraft.class_423;
import net.minecraft.class_437;
import net.minecraft.class_463;
import net.minecraft.class_471;
import net.minecraft.class_473;
import net.minecraft.class_7529;
import net.minecraft.class_7743;

public final class InputMethodFix {
    private static final boolean WINDOWS = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");

    private static Pointer windowHandle;
    private static Pointer previousInputContext;
    private static boolean disabled;

    private InputMethodFix() {}

    public static void tick(class_310 client) {
        if (!WINDOWS || client == null || client.method_22683() == null) {
            return;
        }
        if (!Config.disableImeInGame || client.field_1724 == null || shouldAllowInputMethod(client.field_1755)) {
            restore();
            return;
        }
        disable(client);
    }

    public static void onWindowActiveChanged(boolean active, class_310 client) {
        if (!active) {
            restore();
            return;
        }
        tick(client);
    }

    public static void onScreenChanged(class_437 screen, class_310 client) {
        if (!WINDOWS) {
            return;
        }
        if (!Config.disableImeInGame || client == null || client.field_1724 == null || shouldAllowInputMethod(screen)) {
            restore();
            return;
        }
        disable(client);
    }

    public static boolean shouldAllowInputMethod(class_437 screen) {
        if (screen == null) return false;
        if (screen instanceof class_408 || screen instanceof class_423) return true;
        if (screen instanceof class_7743 || screen instanceof class_473) return true;
        if (screen instanceof class_463 || screen instanceof class_471) return true;

        class_364 focused = screen.method_25399();
        return focused instanceof class_342 || focused instanceof class_7529;
    }

    public static void refreshForFocusedTextField(class_310 client) {
        if (!WINDOWS || client == null) return;
        if (Config.disableImeInGame && client.field_1724 != null && shouldAllowInputMethod(client.field_1755)) {
            restore();
        }
    }

    private static void disable(class_310 client) {
        Pointer hwnd = getWindowHandle(client);
        if (hwnd == null) return;

        if (disabled && windowHandle != null && Pointer.nativeValue(windowHandle) != Pointer.nativeValue(hwnd)) {
            restore();
        }

        if (disabled) return;

        Pointer inputContext = Imm32.INSTANCE.ImmAssociateContext(hwnd, null);
        previousInputContext = inputContext;
        windowHandle = hwnd;
        disabled = true;
    }

    private static void restore() {
        if (!disabled || windowHandle == null) return;

        Imm32.INSTANCE.ImmAssociateContext(windowHandle, previousInputContext);
        windowHandle = null;
        previousInputContext = null;
        disabled = false;
    }

    private static Pointer getWindowHandle(class_310 client) {
        long hwnd = GLFWNativeWin32.glfwGetWin32Window(client.method_22683().method_4490());
        return hwnd == 0 ? null : Pointer.createConstant(hwnd);
    }

    private interface Imm32 extends Library {
        Imm32 INSTANCE = Native.load("imm32", Imm32.class);

        Pointer ImmAssociateContext(Pointer hwnd, Pointer inputContext);
    }
}
