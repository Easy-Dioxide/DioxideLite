package com.dioxidelite.client.modules.impl.Render;

import com.dioxidelite.Config;
import com.dioxidelite.client.render.nativeui.NativeGlassVisualSystem;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_7532;
import net.minecraft.class_8685;

/** Native Target HUD. Avatar and text are drawn directly through Minecraft's GUI pipeline. */
public final class TargetHudRenderer {
    private static final TargetHudRenderer INSTANCE=new TargetHudRenderer(); private class_1309 target; private long hitAt,appearAt; private float lastHealth=-1; private long lastNs;
    public static TargetHudRenderer getInstance(){return INSTANCE;}
    public void onHit(class_1309 entity){if(!Config.targetHud||entity==null)return;long n=System.currentTimeMillis();if(target!=entity){appearAt=n;}target=entity;hitAt=n;}
    public void render(class_332 g){class_310 mc=class_310.method_1551();long n=System.currentTimeMillis();boolean edit=HudEditOverlay.getInstance().isActive()&&Config.targetHud;if(edit&&mc.field_1724!=null){target=mc.field_1724;appearAt=n;hitAt=n;}if(target==null)return;if(!target.method_5805()&&!edit&&n-hitAt>200)return;float in=class_3532.method_15363((n-appearAt)/200f,0,1);float out=1-class_3532.method_15363((n-hitAt-3000)/200f,0,1);float a=Math.min(in,out);if(a<=0&&!edit){target=null;return;}float scale=Math.max(.5f,Config.targetHudScale);int w=190,h=58;int x=Math.round(mc.method_22683().method_4486()*.5f+Config.targetHudX),y=Math.round(mc.method_22683().method_4502()*.5f+Config.targetHudY);x=Math.max(0,Math.min(mc.method_22683().method_4486()-Math.round(w*scale),x));y=Math.max(0,Math.min(mc.method_22683().method_4502()-Math.round(h*scale),y));int ai=Math.round(255*a);NativeGlassVisualSystem.renderHudDock(g,x,y,Math.round(w*scale),Math.round(h*scale),.82f);g.method_51448().pushMatrix();g.method_51448().translate(x,y);g.method_51448().scale(scale,scale);String name=target.method_5476().getString();if(name.length()>18)name=name.substring(0,18)+"…";g.method_51433(mc.field_1772,name,54,11,(ai<<24)|0xF2F7F8,false);float hp=target.method_6032(),max=Math.max(1,target.method_6063()),ratio=class_3532.method_15363(hp/max,0,1);g.method_25294(54,34,180,40,(ai<<24)|0x26333A);int hc=ratio>.5?0x58DDBE:(ratio>.25?0xF2C94C:0xFF6570);g.method_25294(54,34,54+Math.round(126*ratio),40,(ai<<24)|hc);String hs=String.format(java.util.Locale.ROOT,"%.1f / %.1f",hp,max);g.method_51433(mc.field_1772,hs,54,43,(Math.round(ai*.7f)<<24)|0xB8C5CA,false);drawAvatar(g,mc,8,10,38,a);if(mc.field_1724!=null){String status=mc.field_1724.method_6032()>hp?"W":"L";g.method_51433(mc.field_1772,status,171,11,(ai<<24)|(status.equals("W")?0x58DDBE:0xFF6570),false);}g.method_51448().popMatrix();lastHealth=hp;lastNs=n;}
    private void drawAvatar(class_332 g,class_310 mc,int x,int y,int size,float a){if(target instanceof class_1657 p){try{class_8685 skin=mc.method_1582().method_73544(p.method_7334(),false).get();class_7532.method_52722(g,skin,x,y,size);return;}catch(Exception ignored){}}class_1826 egg=class_1826.method_8019(target.method_5864());if(egg!=null){g.method_51445(new class_1799(egg),x+11,y+11);return;}g.method_25294(x,y,x+size,y+size,(Math.round(255*a)<<24)|0x202830);}
    public int getEditWidth(){return Math.round(190*Math.max(.5f,Config.targetHudScale));}public int getEditHeight(){return Math.round(58*Math.max(.5f,Config.targetHudScale));}
}
