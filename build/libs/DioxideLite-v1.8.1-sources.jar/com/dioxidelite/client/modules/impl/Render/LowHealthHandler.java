package com.dioxidelite.client.modules.impl.Render;

import com.dioxidelite.Config;
import net.minecraft.class_1109;
import net.minecraft.class_310;
import net.minecraft.class_3417;

public class LowHealthHandler {
    private static int lastStage = 0;

    public static void onHealthUpdate(class_310 client, float health) {
        if (!Config.lowHealthNotify || client.field_1724 == null || !client.field_1724.method_5805()) {
            reset(500);
            return;
        }

        int currentStage = 0;
        if (health <= 6.0f) {
            currentStage = 2;
        } else if (health <= 10.0f) {
            currentStage = 1;
        }

        if (currentStage != lastStage) {
            if (currentStage == 0) {
                reset(1000);
            } else if (currentStage == 1) {
                String msg = Config.isChinese ? "低血量警告，请及时补充血量" : "Low health warning, please replenish health";
                NotificationOverlay.getInstance().showPersistentSymbol(msg, 0xFFFF55, "\uE001", 0xFFFF55);
                playAnvil(client, 1);
            } else if (currentStage == 2) {
                String msg = Config.isChinese ? "极低生命值警告，请及时补充血量！！！" : "CRITICAL health warning, replenish health NOW!!!";
                NotificationOverlay.getInstance().showPersistentSymbol(msg, 0xFF5555, "\uE002", 0xFF5555);
                playAnvil(client, 3);
            }
            lastStage = currentStage;
        }
    }

    private static void reset(long delay) {
        if (lastStage != 0) {
            NotificationOverlay.getInstance().stopPersistent(delay);
            lastStage = 0;
        }
    }

    private static void playAnvil(class_310 client, int count) {
        new Thread(() -> {
            try {
                for (int i = 0; i < count; i++) {
                    client.execute(() -> {
                        client.method_1483().method_4873(class_1109.method_4758(class_3417.field_14833, 1.0f));
                    });
                    if (count > 1) Thread.sleep(160);
                }
            } catch (InterruptedException ignored) {}
        }).start();
    }

    public static void tick(class_310 client) {}
}
