package com.dioxidelite.client.modules.impl.Render;

import com.dioxidelite.Config; import com.dioxidelite.client.render.nativeui.NativeGlassVisualSystem;
import java.util.ArrayList; import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

/** Native armor HUD. */
public final class ArmorHudRenderer {
    private static final ArmorHudRenderer INSTANCE=new ArmorHudRenderer(); public static ArmorHudRenderer getInstance(){return INSTANCE;}
    public void render(class_332 g){class_310 mc=class_310.method_1551();if(!Config.armorHud||mc.field_1724==null)return;List<class_1799> items=new ArrayList<>();items.add(mc.field_1724.method_6118(class_1304.field_6166));items.add(mc.field_1724.method_6118(class_1304.field_6172));items.add(mc.field_1724.method_6118(class_1304.field_6174));items.add(mc.field_1724.method_6118(class_1304.field_6169));float s=Math.max(.5f,Config.armorHudScale);int w=items.size()*22+12,h=30;int x=Math.round(mc.method_22683().method_4486()/2f+Config.armorHudX-w*s/2f),y=Math.round(mc.method_22683().method_4502()/2f+Config.armorHudY);NativeGlassVisualSystem.renderHudDock(g,x,y,Math.round(w*s),Math.round(h*s),.72f);g.method_51448().pushMatrix();g.method_51448().translate(x,y);g.method_51448().scale(s,s);for(int i=0;i<4;i++){class_1799 stack=items.get(i);int xx=6+i*22;g.method_51445(stack,xx,6);if(!stack.method_7960()&&Config.armorHudShowPercentage){int max=stack.method_7936(),rem=stack.method_7919();if(max>0){int pct=Math.round(100f*(max-rem)/max);g.method_51433(mc.field_1772,String.valueOf(pct),xx+8,21,0xDFFFFFFF,false);}}}g.method_51448().popMatrix();}
    public float getEditWidth(){return 100*Math.max(.5f,Config.armorHudScale);}
    public float getEditHeight(){return 30*Math.max(.5f,Config.armorHudScale);}
    public float getRenderX(int w){return w*.5f+Config.armorHudX-getEditWidth()/2f;}
    public float getRenderY(int h){return h*.5f+Config.armorHudY;}
    public boolean isPositionLockedToAdaptiveLayout(){return false;}
}
