package com.dioxidelite.client.modules.impl.Tool;

import com.dioxidelite.Config;
import net.minecraft.class_310;
import net.minecraft.class_638;

public final class TimeWeatherChanger {
    private static boolean wasWeatherChangeEnabled = false;
    private static boolean savedRaining = false;
    private static float savedRainLevel = 0.0f;
    private static float savedThunderLevel = 0.0f;

    private TimeWeatherChanger() {}

    public static void tick(class_310 client) {
        class_638 level = client.field_1687;
        if (level == null) {
            wasWeatherChangeEnabled = false;
            return;
        }

        if (Config.timeChange) {
            long time = Math.floorMod(Config.clientTime, 24000);
            level.method_29089(level.method_75260(), time, false);
        }

        if (Config.weatherChange) {
            if (!wasWeatherChangeEnabled) {
                saveWeather(level);
                wasWeatherChangeEnabled = true;
            }
            applyWeather(level);
        } else if (wasWeatherChangeEnabled) {
            restoreWeather(level);
            wasWeatherChangeEnabled = false;
        }
    }

    private static void saveWeather(class_638 level) {
        savedRaining = level.method_28104().method_156();
        savedRainLevel = level.method_8430(1.0f);
        savedThunderLevel = level.method_8478(1.0f);
    }

    private static void restoreWeather(class_638 level) {
        level.method_28104().method_157(savedRaining);
        level.method_8519(savedRainLevel);
        level.method_8496(savedThunderLevel);
    }

    private static void applyWeather(class_638 level) {
        boolean rain = Config.weatherMode != Config.WeatherMode.CLEAR;
        boolean thunder = Config.weatherMode == Config.WeatherMode.THUNDER;

        level.method_28104().method_157(rain);
        level.method_8519(rain ? 1.0f : 0.0f);
        level.method_8496(thunder ? 1.0f : 0.0f);
    }
}
