package com.dioxidelite.client.modules.impl.Render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.dioxidelite.Config;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_12079;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class CustomCapeManager {
    private static final Path EXTERNAL_PATH = FabricLoader.getInstance().getGameDir().resolve("DioxideLite/cape");
    private static final String DEFAULT_IMAGE = "default.png";
    private static boolean initLogged;
    private static class_1043 texture;
    private static class_2960 loadedTextureId;
    private static String loaded = "";
    private static String lastLoggedTexture = "";
    private static String lastLoggedList = "";
    private static boolean initialized;

    private CustomCapeManager() {}

    public static void init() {
        if (initialized) return;
        initialized = true;
        try {
            Files.createDirectories(EXTERNAL_PATH);
            Path target = EXTERNAL_PATH.resolve(DEFAULT_IMAGE);
            try (InputStream is = CustomCapeManager.class.getResourceAsStream("/cape/" + DEFAULT_IMAGE)) {
                if (is != null) {
                    Files.copy(is, target, StandardCopyOption.REPLACE_EXISTING);
                    if (!initLogged) {
                        initLogged = true;
                        System.out.println("[DioxideLite] CustomCape extracted default cape to " + target.toAbsolutePath());
                    }
                } else {
                    System.out.println("[DioxideLite] CustomCape default cape resource missing: /cape/" + DEFAULT_IMAGE);
                }
            }
        } catch (IOException e) {
            System.out.println("[DioxideLite] CustomCape init failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void openFolder() {
        init();
        class_156.method_668().method_60932(EXTERNAL_PATH);
    }

    public static List<String> listPngs() {
        init();
        List<String> files = new ArrayList<>();
        try (var stream = Files.list(EXTERNAL_PATH)) {
            stream.filter(Files::isRegularFile)
                    .map(path -> path.getFileName().toString())
                    .filter(name -> name.toLowerCase(Locale.ROOT).endsWith(".png"))
                    .sorted(Comparator.naturalOrder())
                    .forEach(files::add);
        } catch (IOException e) {
            System.out.println("[DioxideLite] CustomCape list failed: " + e.getMessage());
            e.printStackTrace();
        }
        if (files.isEmpty()) files.add(DEFAULT_IMAGE);
        String listLog = files.toString();
        if (!listLog.equals(lastLoggedList)) {
            lastLoggedList = listLog;
            System.out.println("[DioxideLite] CustomCape available pngs: " + listLog);
        }
        return files;
    }

    public static void cycleCape() {
        List<String> files = listPngs();
        int index = files.indexOf(Config.customCapeImage);
        Config.customCapeImage = files.get((index + 1 + files.size()) % files.size());
        Config.save();
        destroy();
        System.out.println("[DioxideLite] CustomCape switched to " + Config.customCapeImage);
    }

    public static class_12079.class_12081 texture() {
        if (!Config.customCape) return null;
        init();
        String selected = Config.customCapeImage == null || Config.customCapeImage.isBlank() ? DEFAULT_IMAGE : Path.of(Config.customCapeImage).getFileName().toString();
        Path path = EXTERNAL_PATH.resolve(selected);
        if (!Files.exists(path)) {
            System.out.println("[DioxideLite] CustomCape selected file missing, fallback to default: " + path.toAbsolutePath());
            selected = DEFAULT_IMAGE;
            Config.customCapeImage = selected;
            Config.save();
            path = EXTERNAL_PATH.resolve(selected);
        }
        String key = selected.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_.-]", "_");
        class_2960 texturePath = class_2960.method_60655("dioxide_lite", "custom_cape/" + key);
        if (texture == null || !selected.equals(loaded)) {
            destroy();
            try {
                class_1011 image = class_1011.method_4309(Files.newInputStream(path));
                texture = new class_1043("dioxide_lite:custom_cape/" + key, image.method_4307(), image.method_4323(), false);
                class_310.method_1551().method_1531().method_4616(texturePath, texture);
                GpuTexture gpuTexture = texture.method_68004();
                RenderSystem.getDevice().createCommandEncoder().writeToTexture(gpuTexture, image);
                image.close();
                loadedTextureId = texturePath;
                loaded = selected;
            } catch (IOException e) {
                System.out.println("[DioxideLite] CustomCape texture upload failed: " + e.getMessage());
                e.printStackTrace();
                return null;
            }
        }
        String textureLog = selected + " -> " + texturePath + " exists=" + Files.exists(path) + " registered=" + (loadedTextureId != null);
        if (!textureLog.equals(lastLoggedTexture)) {
            lastLoggedTexture = textureLog;
            System.out.println("[DioxideLite] CustomCape texture: " + textureLog);
        }
        return new class_12079.class_10726(texturePath, texturePath);
    }

    private static void destroy() {
        if (loadedTextureId != null) {
            class_310.method_1551().method_1531().method_4615(loadedTextureId);
        }
        texture = null;
        loadedTextureId = null;
        loaded = "";
    }
}
