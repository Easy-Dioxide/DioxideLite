package com.dioxidelite.client.modules.impl.Render;

import com.dioxidelite.Config;
import com.dioxidelite.mixin.client.MultiPlayerGameModeAccessor;
import java.util.Locale;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class DiggingStatusRenderer {
    private static final DiggingStatusRenderer INSTANCE = new DiggingStatusRenderer();
    private static final float MIN_SPEED_PER_SECOND = 0.0001f;

    private class_2338 lastPos;
    private float lastProgress;
    private long lastSampleTime;
    private float speedPerSecond;

    public static DiggingStatusRenderer getInstance() {
        return INSTANCE;
    }

    public void render(class_332 graphics) {
        if (!Config.diggingStatus) {
            reset();
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            reset();
            return;
        }

        class_437 screen = client.field_1755;
        if (screen != null) {
            reset();
            return;
        }

        MultiPlayerGameModeAccessor accessor = (MultiPlayerGameModeAccessor) client.field_1761;
        if (!accessor.dioxideLite$isDestroying() || accessor.dioxideLite$getDestroyDelay() > 0) {
            reset();
            return;
        }

        class_2338 pos = accessor.dioxideLite$getDestroyBlockPos();
        float progress = Math.max(0.0f, Math.min(1.0f, accessor.dioxideLite$getDestroyProgress()));
        if (pos == null || progress <= 0.0f || progress >= 1.0f) {
            reset();
            return;
        }

        updateSpeed(pos, progress);

        if (speedPerSecond <= MIN_SPEED_PER_SECOND) return;

        int percent = Math.max(1, Math.min(99, Math.round(progress * 100.0f)));
        float seconds = Math.max(0.0f, (1.0f - progress) / speedPerSecond);
        String text = percent + "%(" + formatSeconds(seconds) + "s)";

        int screenW = client.method_22683().method_4486();
        int screenH = client.method_22683().method_4502();
        int textX = (screenW - client.field_1772.method_1727(text)) / 2;
        int textY = screenH / 2 + 18;

        graphics.method_51439(client.field_1772, class_2561.method_43470(text), textX, textY, getProgressColor(progress), true);
    }

    private void updateSpeed(class_2338 pos, float progress) {
        long now = System.nanoTime();
        if (!pos.equals(lastPos) || progress < lastProgress) {
            lastPos = pos;
            lastProgress = progress;
            lastSampleTime = now;
            speedPerSecond = 0.0f;
            return;
        }

        if (progress > lastProgress && lastSampleTime > 0L) {
            float elapsed = (now - lastSampleTime) / 1_000_000_000.0f;
            if (elapsed > 0.0f) {
                float instantSpeed = (progress - lastProgress) / elapsed;
                speedPerSecond = speedPerSecond <= 0.0f ? instantSpeed : speedPerSecond * 0.65f + instantSpeed * 0.35f;
            }
            lastProgress = progress;
            lastSampleTime = now;
        }
    }

    private String formatSeconds(float seconds) {
        if (seconds >= 10.0f) return String.valueOf(Math.round(seconds));
        return String.format(Locale.ROOT, "%.1f", seconds);
    }

    private int getProgressColor(float progress) {
        progress = Math.max(0.0f, Math.min(1.0f, progress));
        int r;
        int g;
        if (progress < 0.5f) {
            float t = progress * 2.0f;
            r = 255;
            g = Math.round(255.0f * t);
        } else {
            float t = (progress - 0.5f) * 2.0f;
            r = Math.round(255.0f * (1.0f - t));
            g = 255;
        }
        return 0xFF000000 | (r << 16) | (g << 8);
    }

    private void reset() {
        lastPos = null;
        lastProgress = 0.0f;
        lastSampleTime = 0L;
        speedPerSecond = 0.0f;
    }
}
