package com.dioxidelite.client.modules.impl.Render;

import com.dioxidelite.Config;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_5134;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class FallDamagePredictor {
    private static final FallDamagePredictor INSTANCE = new FallDamagePredictor();

    private static final float IMMUNE = 0.0f;
    private static final float HAY_REDUCTION = 0.2f;
    private static final float HONEY_REDUCTION = 0.2f;
    private static final float BED_REDUCTION = 0.5f;

    public static FallDamagePredictor getInstance() {
        return INSTANCE;
    }

    public void render(class_332 graphics) {
        if (!Config.fallDamagePredict) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_1657 player = client.field_1724;
        class_1937 level = client.field_1687;

        if (player.method_24828()) return;
        if (player.method_5799() || player.method_5771()) return;
        if (player.method_31549().field_7479 || player.method_31549().field_7480) return;
        if (player.method_6128()) return;
        if (player.method_6059(class_1294.field_5906)) return;
        if (player.method_6059(class_1294.field_5902)) return;

        float fallDist = (float) player.field_6017;
        if (fallDist <= 0.0f) return;

        class_243 pos = player.method_73189();
        if (isResettingFallDistance(level, player.method_5829())) return;

        LandingInfo landing = findLanding(player, level, pos);
        if (landing == null) return;
        if (willResetBeforeLanding(player, level, pos.field_1351, landing.y)) return;

        double totalFall = fallDist + Math.max(0.0, pos.field_1351 - landing.y);
        float safeFall = (float) player.method_45325(class_5134.field_49079);
        float landingMultiplier = getLandingMultiplier(level, landing.pos);

        if (landingMultiplier == IMMUNE) return;

        float fallMultiplier = (float) player.method_45325(class_5134.field_49077);
        int rawDamage = (int) Math.floor((totalFall + 1.0E-6 - safeFall) * landingMultiplier * fallMultiplier);

        if (rawDamage <= 0) return;

        if (player.method_6059(class_1294.field_5907)) {
            int amplifier = player.method_6112(class_1294.field_5907).method_5578();
            int resistance = (amplifier + 1) * 5;
            rawDamage = Math.max((int) Math.floor(rawDamage * (25 - resistance) / 25.0f), 0);
        }

        if (rawDamage <= 0) return;

        float protection = getFallProtection(player);
        float afterProtection = protection > 0.0f ? rawDamage * (1.0f - Math.min(protection, 20.0f) / 25.0f) : rawDamage;

        if (afterProtection <= 0) return;

        boolean cn = Config.isChinese;
        boolean lethal = afterProtection >= player.method_6032();
        String text = (cn ? "预测伤害: " : "Predicted Damage: ") + String.format("%.1f", afterProtection)
                + (lethal ? (cn ? " (致死)" : " (Lethal)") : "");

        int screenW = client.method_22683().method_4486();
        int screenH = client.method_22683().method_4502();
        int textW = client.field_1772.method_1727(text);
        int textX = (screenW - textW) / 2;
        int textY = screenH / 2 + 16;

        int color = getDamageColor(afterProtection, player.method_6063());
        graphics.method_51439(client.field_1772, class_2561.method_43470(text), textX, textY, color, true);
    }

    private boolean isResettingFallDistance(class_1937 level, class_238 box) {
        int minX = (int) Math.floor(box.field_1323 + 1.0E-7);
        int maxX = (int) Math.floor(box.field_1320 - 1.0E-7);
        int minY = (int) Math.floor(box.field_1322 + 1.0E-7);
        int maxY = (int) Math.floor(box.field_1325 - 1.0E-7);
        int minZ = (int) Math.floor(box.field_1321 + 1.0E-7);
        int maxZ = (int) Math.floor(box.field_1324 - 1.0E-7);

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    class_2338 pos = new class_2338(x, y, z);
                    if (isResettingState(level, pos)) return true;
                }
            }
        }
        return false;
    }

    private float getLandingMultiplier(class_1937 level, class_2338 landPos) {
        class_2680 state = level.method_8320(landPos);

        if (!level.method_8316(landPos).method_15769()) return IMMUNE;
        if (isResettingBlock(state)) return IMMUNE;

        if (state.method_27852(class_2246.field_10030)) return IMMUNE;
        if (state.method_27852(class_2246.field_27879)) return IMMUNE;

        if (state.method_27852(class_2246.field_10359)) return HAY_REDUCTION;
        if (state.method_27852(class_2246.field_21211)) return HONEY_REDUCTION;
        if (state.method_26164(class_3481.field_16443)) return BED_REDUCTION;

        return 1.0f;
    }

    private boolean willResetBeforeLanding(class_1657 player, class_1937 level, double startY, double landingY) {
        class_238 box = player.method_5829();
        double width = box.method_17939() / 2.0 - 0.01;
        double depth = box.method_17941() / 2.0 - 0.01;
        double x = player.method_23317();
        double z = player.method_23321();

        for (double y = startY; y >= landingY; y -= 0.25) {
            if (isResettingState(level, class_2338.method_49637(x, y, z))) return true;
            if (isResettingState(level, class_2338.method_49637(x - width, y, z - depth))) return true;
            if (isResettingState(level, class_2338.method_49637(x - width, y, z + depth))) return true;
            if (isResettingState(level, class_2338.method_49637(x + width, y, z - depth))) return true;
            if (isResettingState(level, class_2338.method_49637(x + width, y, z + depth))) return true;
        }

        return false;
    }

    private boolean isResettingState(class_1937 level, class_2338 pos) {
        if (level.method_8316(pos).method_15767(class_3486.field_15517)) return true;
        if (level.method_8316(pos).method_15767(class_3486.field_15518)) return true;
        return isResettingBlock(level.method_8320(pos));
    }

    private boolean isResettingBlock(class_2680 state) {
        return state.method_26164(class_3481.field_36327) || state.method_27852(class_2246.field_27879);
    }

    private LandingInfo findLanding(class_1657 player, class_1937 level, class_243 pos) {
        double searchY = pos.field_1351;
        double minY = Math.max(level.method_31607(), searchY - 256);
        class_238 playerBox = player.method_5829();
        double width = playerBox.method_17939() / 2.0 - 0.01;
        double depth = playerBox.method_17941() / 2.0 - 0.01;

        for (double y = searchY; y >= minY; y -= 0.5) {
            class_2338 bp = class_2338.method_49637(pos.field_1352, y - 0.01, pos.field_1350);
            class_2680 state = level.method_8320(bp);

            if (!level.method_8316(bp).method_15769()) return new LandingInfo(y, bp);

            if (!state.method_26215() && !state.method_26220(level, bp).method_1110()) {
                class_238 blockBox = state.method_26220(level, bp).method_1107().method_996(bp);
                if (blockBox.field_1325 >= y) return new LandingInfo(blockBox.field_1325, bp);
            }

            for (class_2338 corner : new class_2338[]{
                    class_2338.method_49637(pos.field_1352 - width, y - 0.01, pos.field_1350),
                    class_2338.method_49637(pos.field_1352 + width, y - 0.01, pos.field_1350),
                    class_2338.method_49637(pos.field_1352, y - 0.01, pos.field_1350 - depth),
                    class_2338.method_49637(pos.field_1352, y - 0.01, pos.field_1350 + depth)
            }) {
                class_2680 cs = level.method_8320(corner);
                if (!cs.method_26215() && !cs.method_26220(level, corner).method_1110()) {
                    class_238 cb = cs.method_26220(level, corner).method_1107().method_996(corner);
                    if (cb.field_1325 >= y) return new LandingInfo(cb.field_1325, corner);
                }
            }
        }

        return null;
    }

    private float getFallProtection(class_1657 player) {
        float protection = 0.0f;
        for (class_1304 slot : new class_1304[]{class_1304.field_6166, class_1304.field_6172, class_1304.field_6174, class_1304.field_6169}) {
            class_1799 stack = player.method_6118(slot);
            class_9304 enchantments = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
            for (Object2IntMap.Entry<net.minecraft.class_6880<net.minecraft.class_1887>> entry : enchantments.method_57539()) {
                if (entry.getKey().method_40225(class_1893.field_9111)) {
                    protection += entry.getIntValue();
                } else if (entry.getKey().method_40225(class_1893.field_9129)) {
                    protection += entry.getIntValue() * 3.0f;
                }
            }
        }
        return protection;
    }

    private int getDamageColor(float damage, float maxHealth) {
        float ratio = damage / maxHealth;
        if (ratio < 0.25f) return 0xFFFFFF55;
        if (ratio < 0.5f) return 0xFFFFAA00;
        if (ratio < 0.75f) return 0xFFFF5500;
        return 0xFFFF2222;
    }

    private record LandingInfo(double y, class_2338 pos) {}
}
