package com.dioxidelite.client.modules.impl.Combat;

import com.dioxidelite.Config;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;

public class HitMarkerRenderer {
    private static final HitMarkerRenderer INSTANCE = new HitMarkerRenderer();
    private long hitTime = 0;
    private static final long DURATION = 250;
    private int currentColor = 0xFFFFFF;

    public static HitMarkerRenderer getInstance() {
        return INSTANCE;
    }

    public void onHit(boolean isRanged, int color) {
        if (Config.hitMarker) {
            this.hitTime = System.currentTimeMillis();
            this.currentColor = color;

            if (Config.hitSound) {
                boolean shouldPlay = false;
                if (Config.hitSoundCondition == Config.HitSoundCondition.BOTH) {
                    shouldPlay = true;
                } else if (Config.hitSoundCondition == Config.HitSoundCondition.MELEE && !isRanged) {
                    shouldPlay = true;
                } else if (Config.hitSoundCondition == Config.HitSoundCondition.RANGED && isRanged) {
                    shouldPlay = true;
                }

                if (shouldPlay) {
                    class_310 client = class_310.method_1551();
                    if (client.field_1724 != null) {
                        if (Config.hitSoundType == Config.HitSoundType.NETHERITE) {
                            client.field_1724.method_5783(class_3417.field_15016, 1.0F, 1.0F);
                        } else {
                            client.field_1724.method_5783(class_3417.field_14627, 1.0F, 0.5F);
                        }
                    }
                }
            }
        }
    }

    public void render(class_332 graphics) {
        if (!Config.hitMarker || hitTime == 0) return;

        long elapsed = System.currentTimeMillis() - hitTime;
        if (elapsed > DURATION) {
            hitTime = 0;
            return;
        }

        float alphaProgress = 1.0f - (float) elapsed / DURATION;
        int alpha = (int) (alphaProgress * 255);
        int color = (alpha << 24) | (currentColor & 0xFFFFFF);

        class_310 client = class_310.method_1551();
        int centerX = client.method_22683().method_4486() / 2;
        int centerY = client.method_22683().method_4502() / 2;

        int length = 5;
        int gap = 3;

        drawDiagonal(graphics, centerX - gap, centerY - gap, -1, -1, length, color);
        drawDiagonal(graphics, centerX + gap, centerY - gap, 1, -1, length, color);
        drawDiagonal(graphics, centerX - gap, centerY + gap, -1, 1, length, color);
        drawDiagonal(graphics, centerX + gap, centerY + gap, 1, 1, length, color);
    }

    private void drawDiagonal(class_332 graphics, int x, int y, int dx, int dy, int len, int color) {
        for (int i = 0; i < len; i++) {
            graphics.method_25294(x + i * dx, y + i * dy, x + i * dx + 1, y + i * dy + 1, color);
        }
    }
}
