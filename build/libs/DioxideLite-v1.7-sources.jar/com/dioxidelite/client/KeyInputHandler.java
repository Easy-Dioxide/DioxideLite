package com.dioxidelite.client;

import com.dioxidelite.client.gui.clickgui.TermsScreen;
import com.dioxidelite.client.gui.clickgui.ClickGuiThemeController;
import com.dioxidelite.Config;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;

public class KeyInputHandler {

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (KeyBindings.openSettings.method_1436()) {
                if (client.field_1755 == null) {
                    Config.applyFirstUseLanguageDefault();
                    class_310.method_1551().method_1507(Config.termsRead
                        ? ClickGuiThemeController.create(Config.clickGuiTheme, null)
                        : new TermsScreen(null));
                }
            }
        });
    }
}
