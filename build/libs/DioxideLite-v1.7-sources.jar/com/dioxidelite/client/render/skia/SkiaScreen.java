package com.dioxidelite.client.render.skia;

import io.github.humbleui.skija.Canvas;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public abstract class SkiaScreen extends class_437 {

    protected final class_437 parent;
    private boolean redrawRequested = true;
    private int lastFrameWidth = -1;
    private int lastFrameHeight = -1;

    protected SkiaScreen(class_2561 title, class_437 parent) {
        super(title);
        this.parent = parent;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        if (shouldRedraw()) {
            Canvas canvas = SkiaRenderer.begin();
            if (canvas != null) {
                drawSkia(canvas, this.field_22789, this.field_22790, mouseX, mouseY, delta);
            }
            SkiaRenderer.end(graphics, this.field_22789, this.field_22790);
            redrawRequested = false;
            lastFrameWidth = this.field_22789;
            lastFrameHeight = this.field_22790;
            return;
        }
        SkiaRenderer.drawCached(graphics, this.field_22789, this.field_22790);
    }

    protected boolean shouldRedraw() {
        return redrawRequested
                || !SkiaRenderer.supportsFrameCache()
                || needsContinuousRedraw()
                || this.field_22789 != lastFrameWidth
                || this.field_22790 != lastFrameHeight
                || !SkiaRenderer.hasFrameCache();
    }

    protected void requestRedraw() {
        redrawRequested = true;
        SkiaRenderer.markFrameDirty();
    }

    protected boolean needsContinuousRedraw() {
        return false;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        requestRedraw();
    }

    @Override
    public void method_25410(int width, int height) {
        super.method_25410(width, height);
        requestRedraw();
    }

    @Override
    protected void method_57734(class_332 guiGraphics) {}

    @Override
    protected void method_57735(class_332 guiGraphics) {}

    @Override
    public void method_25420(class_332 guiGraphics, int i, int j, float f) {}

    protected abstract void drawSkia(Canvas canvas, int width, int height, int mouseX, int mouseY, float delta);

    @Override
    public void method_25419() {
        closing();
    }

    protected void closing() {
        SkiaRenderer.resetFrameState();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
