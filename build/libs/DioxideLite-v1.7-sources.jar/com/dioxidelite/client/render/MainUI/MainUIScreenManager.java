package com.dioxidelite.client.render.MainUI;

import com.dioxidelite.Config;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_442;

public final class MainUIScreenManager {
    private MainUIScreenManager() {}

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof class_442 titleScreen)) return;
            if (Config.useMainUI) {
                client.method_1507(new DioxideLiteMainUI(titleScreen));
                return;
            }
            class_4185 button = class_4185.method_46430(class_2561.method_43470("P"), b -> {
                Config.useMainUI = true;
                Config.save();
                client.method_1507(new DioxideLiteMainUI(titleScreen, true));
            }).method_46434(scaledWidth / 2 + 104, scaledHeight / 4 + 48 + 36 - 24, 20, 20).method_46431();
            Screens.getButtons(titleScreen).add(button);
        });
    }
}
