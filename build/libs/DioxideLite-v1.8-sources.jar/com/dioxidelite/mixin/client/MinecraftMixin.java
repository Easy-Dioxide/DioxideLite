package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Tool.AutoChestDepositManager;
import com.dioxidelite.client.modules.impl.Tool.BlockCountDisplayRenderer;
import com.dioxidelite.client.modules.impl.Tool.FakePlayerManager;
import com.dioxidelite.client.modules.impl.Tool.TimeWeatherChanger;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_238;
import net.minecraft.class_2388;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_5819;
import net.minecraft.class_636;
import com.dioxidelite.client.modules.impl.Render.HudEditOverlay;
import com.dioxidelite.client.modules.impl.Render.KeystrokesRenderer;
import com.dioxidelite.client.modules.impl.Render.PotionStatusRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void dioxide_lite$tickToolOverrides(CallbackInfo ci) {
        TimeWeatherChanger.tick((class_310) (Object) this);
    }

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void hideAutoChestDepositScreen(class_437 screen, CallbackInfo ci) {
        if (AutoChestDepositManager.shouldHideContainerScreen(screen)) {
            ci.cancel();
        }
    }

    @Inject(method = "startAttack", at = @At("HEAD"), cancellable = true)
    private void attackFakePlayer(CallbackInfoReturnable<Boolean> cir) {
        if (FakePlayerManager.tryAttack((class_310) (Object) this)) {
            cir.setReturnValue(true);
        }
    }

    @Redirect(
            method = "startAttack",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;attack(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/Entity;)V"
            )
    )
    private void dioxide_lite$attackWithEffects(class_636 gameMode, class_1657 player, class_1297 target) {
        gameMode.method_2918(player, target);
        class_310 client = (class_310) (Object) this;
        if (client.field_1687 == null || client.field_1724 == null || player != client.field_1724 || target == null) {
            return;
        }
        if (Config.attackEffectsCritParticles) {
            spawnAttackParticles(client, target, class_2398.field_11205, Config.attackEffectsCritMultiplier);
        }
        if (Config.attackEffectsSharpnessParticles) {
            spawnAttackParticles(client, target, class_2398.field_11208, Config.attackEffectsSharpnessMultiplier);
        }
        if (Config.attackEffectsFlameParticles) {
            spawnAttackParticles(client, target, class_2398.field_11240, Config.attackEffectsFlameMultiplier);
        }
        if (Config.attackEffectsBloodParticles) {
            spawnAttackParticles(client, target, new class_2388(class_2398.field_11217, class_2246.field_10002.method_9564()), Config.attackEffectsBloodMultiplier);
        }
        if (Config.attackEffectsLightning) {
            spawnAttackLightning(client, target);
        }
    }

    private void spawnAttackParticles(class_310 client, class_1297 target, class_2394 particle, float multiplier) {
        int count = getAttackParticleCount(multiplier);
        class_238 box = target.method_5829();
        class_5819 random = target.method_59922();
        for (int i = 0; i < count; i++) {
            double x = box.field_1323 + random.method_43058() * box.method_17939();
            double y = box.field_1322 + random.method_43058() * box.method_17940();
            double z = box.field_1321 + random.method_43058() * box.method_17941();
            double vx = (random.method_43058() - 0.5D) * 0.08D;
            double vy = random.method_43058() * 0.08D;
            double vz = (random.method_43058() - 0.5D) * 0.08D;
            client.field_1687.method_8406(particle, x, y, z, vx, vy, vz);
        }
    }

    private int getAttackParticleCount(float multiplier) {
        if (!Float.isFinite(multiplier)) {
            return 1;
        }
        return Math.max(1, Math.min(32, Math.round(multiplier * 4.0f)));
    }

    private void spawnAttackLightning(class_310 client, class_1297 target) {
        int count = Math.max(1, Math.min(5, Config.attackEffectsLightningCount));
        class_238 box = target.method_5829();
        class_5819 random = target.method_59922();
        for (int i = 0; i < count; i++) {
            class_1538 lightning = new class_1538(class_1299.field_6112, client.field_1687);
            lightning.method_29498(true);
            double x = target.method_23317() + (random.method_43058() - 0.5D) * Math.max(0.2D, box.method_17939());
            double z = target.method_23321() + (random.method_43058() - 0.5D) * Math.max(0.2D, box.method_17941());
            lightning.method_5814(x, target.method_23318(), z);
            client.field_1687.method_53875(lightning);
        }
    }

    @Inject(
            method = "runTick",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/platform/Window;updateDisplay(Lcom/mojang/blaze3d/TracyFrameCapture;)V"
            )
    )
    private void dioxide_lite$renderSkiaFrameEnd(boolean advanceGameTime, CallbackInfo ci) {
        PotionStatusRenderer.getInstance().renderFrameEnd();
        KeystrokesRenderer.getInstance().renderFrameEnd();
        BlockCountDisplayRenderer.getInstance().renderFrameEnd();
        HudEditOverlay.getInstance().renderFrameEnd();
    }
}
