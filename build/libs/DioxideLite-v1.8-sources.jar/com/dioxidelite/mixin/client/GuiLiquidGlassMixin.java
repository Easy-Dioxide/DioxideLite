package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.render.skia.LiquidGlassVisualSystem;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Material plate for the vanilla hotbar/decorations, drawn before its contents. */
@Mixin(class_329.class)
public abstract class GuiLiquidGlassMixin {
    @Inject(method = "renderHotbarAndDecorations", at = @At("HEAD"))
    private void dioxide_lite$liquidGlassHotbar(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (!Config.liquidGlassAllVisuals) return;
        int w = graphics.method_51421();
        int h = graphics.method_51443();
        float hotbarW = Math.min(190f, w * .72f);
        float x = (w - hotbarW) * .5f;
        float y = h - 24f;
        LiquidGlassVisualSystem.renderHudDock(graphics, x - 5f, y - 4f, hotbarW + 10f, 24f, .78f);
    }
}
