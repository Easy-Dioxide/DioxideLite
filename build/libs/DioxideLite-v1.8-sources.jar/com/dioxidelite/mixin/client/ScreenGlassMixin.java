package com.dioxidelite.mixin.client;

import com.dioxidelite.Config;
import com.dioxidelite.client.render.skia.LiquidGlassVisualSystem;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_442;
import com.dioxidelite.client.gui.clickgui.ClickGuiScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Shared glass material for vanilla-style screens. Skia screens and the main menu opt out. */
@Mixin(class_437.class)
public abstract class ScreenGlassMixin {
    @Inject(method = "renderBackground", at = @At("TAIL"))
    private void dioxide_lite$screenGlass(class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!Config.liquidGlassAllVisuals) return;
        class_437 screen = (class_437) (Object) this;
        if (screen instanceof ClickGuiScreen || screen instanceof class_442) return;
        if (screen.field_22789 <= 120 || screen.field_22790 <= 80) return;
        float marginX = Math.max(24f, screen.field_22789 * .10f);
        float marginY = Math.max(18f, screen.field_22790 * .12f);
        LiquidGlassVisualSystem.renderSurface(graphics, marginX, marginY,
                screen.field_22789 - marginX * 2f, screen.field_22790 - marginY * 2f,
                Math.min(Config.glassRadius, 18f), .34f);
    }
}
