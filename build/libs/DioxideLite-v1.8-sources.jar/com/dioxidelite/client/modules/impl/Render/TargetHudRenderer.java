package com.dioxidelite.client.modules.impl.Render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.dioxidelite.client.gui.TargetScoreboardUtil;

import com.dioxidelite.Config;
import com.dioxidelite.client.render.font.FontRenderer;
import com.dioxidelite.client.render.skia.SkiaBlurRenderer;
import io.github.humbleui.skija.*;
import io.github.humbleui.skija.impl.Library;
import io.github.humbleui.types.Rect;
import io.github.humbleui.types.RRect;
import org.lwjgl.system.MemoryUtil;

import java.io.InputStream;
import java.net.URI;
import java.nio.ByteBuffer;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_12079;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_7532;
import net.minecraft.class_8685;

public class TargetHudRenderer {
    private static final TargetHudRenderer INSTANCE = new TargetHudRenderer();

    private class_1309 target = null;
    private long lastHitTime = 0;
    private long appearanceTime = 0;
    private boolean isFullyHidden = true;
    private boolean editPreview = false;
    private boolean wasEditActive = false;
    private Surface surface;
    private Surface overlaySurface;
    private Surface avatarMaskSurface;
    private Surface avatarFlashSurface;
    private class_1043 dynamicTexture;
    private class_1043 overlayTexture;
    private class_1043 avatarMaskTexture;
    private class_1043 avatarFlashTexture;
    private class_1043 roundedAvatarTexture;
    private boolean nativeLoaded = false;
    private int textureW = -1;
    private int textureH = -1;
    private int overlayTextureW = -1;
    private int overlayTextureH = -1;
    private int avatarMaskW = -1;
    private int avatarMaskH = -1;
    private int avatarFlashW = -1;
    private int avatarFlashH = -1;
    private int roundedAvatarW = -1;
    private int roundedAvatarH = -1;
    private String lastTextureName = "";
    private String lastTextureHealthText = "";
    private int lastTextureHealth = -1;
    private int lastTextureAbsorption = -1;
    private int lastTextureHealthTextAnim = -1;
    private Config.HudTheme lastTextureTheme = null;
    private Config.HudTheme lastOverlayTextureTheme = null;
    private Config.HudTheme lastAvatarMaskTheme = null;
    private boolean lastTextureBlurMode = false;
    private boolean lastOverlayTextureBlurMode = false;
    private int lastAvatarFlashKey = -1;
    private String lastRoundedAvatarKey = "";
    private String pendingRoundedAvatarKey = "";
    private CompletableFuture<class_1011> pendingRoundedAvatarImage = null;
    private String lastRawName = "";
    private String lastTruncatedName = "";
    private float animatedHealthRatio = 1f;
    private float animatedAbsorptionRatio = 0f;
    private long lastRenderTime = 0L;
    private String currentHealthText = "";
    private String previousHealthText = "";
    private long healthTextAnimStart = 0L;
    private int healthTextDirection = 0;
    private float lastHealthTextValue = -1f;
    private final Paint newHudBgPaint = new Paint();
    private final Paint newHudAvatarPaint = new Paint();
    private final Paint newHudTrackPaint = new Paint();
    private final Paint newHudFillPaint = new Paint();
    private final Paint newHudAbsorbPaint = new Paint();
    private final Paint avatarMaskCoverPaint = new Paint();
    private final Paint avatarMaskHolePaint = new Paint();
    private final Paint avatarFlashPaint = new Paint();
    private class_8685 cachedPlayerSkin = null;
    private int cachedPlayerSkinEntityId = Integer.MIN_VALUE;
    private final float[] healthCharWidthCache = new float[128];
    private final boolean[] healthCharWidthCached = new boolean[128];

    private long lastDamageTime = 0;
    private long lastHealTime = 0;
    private float lastObservedHealth = -1f;
    private static final long DAMAGE_FLASH_DURATION = 300;

    private static final long HIDE_DELAY = 3000;
    private static final long ANIM_DURATION = 200;
    private static final long HEALTH_TEXT_ANIM_DURATION = 220;

    private static final int HUD_WIDTH = 160;
    private static final int HUD_HEIGHT = 40;
    private static final int NEW_HUD_WIDTH = 190;
    private static final int NEW_HUD_HEIGHT = 58;
    private static final int NEW_AVATAR_SIZE = 38;
    private static final int NEW_OVERLAY_X = 58;
    private static final int NEW_OVERLAY_Y = 18;
    private static final int NEW_OVERLAY_WIDTH = 120;
    private static final int NEW_OVERLAY_HEIGHT = 34;
    private static final float NEW_AVATAR_RADIUS = 12f;
    private static final int AVATAR_SIZE = 28;
    private static final int PADDING = 6;
    private static final int BORDER = 1;
    private static final class_2960 TEXTURE_ID = class_2960.method_60655("dioxide_lite", "target_hud_new");
    private static final class_2960 OVERLAY_TEXTURE_ID = class_2960.method_60655("dioxide_lite", "target_hud_new_overlay");
    private static final class_2960 AVATAR_MASK_TEXTURE_ID = class_2960.method_60655("dioxide_lite", "target_hud_avatar_mask");
    private static final class_2960 AVATAR_FLASH_TEXTURE_ID = class_2960.method_60655("dioxide_lite", "target_hud_avatar_flash");
    private static final class_2960 ROUNDED_AVATAR_TEXTURE_ID = class_2960.method_60655("dioxide_lite", "target_hud_rounded_avatar");
    private static final SurfaceProps SURFACE_PROPS = new SurfaceProps(false, PixelGeometry.RGB_H);

    public static TargetHudRenderer getInstance() {
        return INSTANCE;
    }

    private TargetHudRenderer() {
        newHudBgPaint.setAntiAlias(true);
        newHudAvatarPaint.setAntiAlias(true);
        newHudTrackPaint.setAntiAlias(true);
        newHudFillPaint.setAntiAlias(true);
        newHudAbsorbPaint.setAntiAlias(true);
        avatarMaskCoverPaint.setAntiAlias(true);
        avatarMaskHolePaint.setAntiAlias(true);
        avatarMaskHolePaint.setBlendMode(BlendMode.CLEAR);
        avatarFlashPaint.setAntiAlias(true);
    }

    private class_8685 resolvePlayerSkin(class_310 client, class_1657 player) {
        int entityId = player.method_5628();
        if (cachedPlayerSkin != null && cachedPlayerSkinEntityId == entityId) {
            return cachedPlayerSkin;
        }
        cachedPlayerSkin = client.method_1582().method_73544(player.method_7334(), false).get();
        cachedPlayerSkinEntityId = entityId;
        return cachedPlayerSkin;
    }

    private void invalidatePlayerSkinCache(class_1297 entity) {
        if (entity == null || entity.method_5628() == cachedPlayerSkinEntityId) {
            cachedPlayerSkin = null;
            cachedPlayerSkinEntityId = Integer.MIN_VALUE;
        }
    }

    private float getHealthCharWidth(String ch) {
        if (ch.length() == 1) {
            char c = ch.charAt(0);
            if (c < healthCharWidthCache.length) {
                if (!healthCharWidthCached[c]) {
                    healthCharWidthCache[c] = FontRenderer.measureTextWidth(ch, 10f);
                    healthCharWidthCached[c] = true;
                }
                return healthCharWidthCache[c];
            }
        }
        return FontRenderer.measureTextWidth(ch, 10f);
    }

    public void onHit(class_1309 entity) {
        if (!Config.targetHud || entity == null) return;

        long now = System.currentTimeMillis();

        if (this.target == null || isFullyHidden) {
            this.appearanceTime = now;
            this.isFullyHidden = false;
        }
        if (this.target != entity) {
            invalidatePlayerSkinCache(this.target);
        }
        float currentHealth = entity.method_6032();
        if (this.target != entity || lastObservedHealth < 0f || currentHealth < lastObservedHealth - 0.001f) {
            this.lastDamageTime = now;
        } else if (currentHealth > lastObservedHealth + 0.001f) {
            this.lastHealTime = now;
        }
        this.target = entity;
        this.lastHitTime = now;
    }

    public void render(class_332 graphics) {
        long now = System.currentTimeMillis();
        class_310 client = class_310.method_1551();
        boolean editActive = HudEditOverlay.getInstance().isActive() && Config.targetHud;

        if (editActive && client.field_1724 != null) {
            if (!editPreview || target != client.field_1724 || isFullyHidden) {
                appearanceTime = now;
                isFullyHidden = false;
            }
            target = client.field_1724;
            lastHitTime = now;
            lastDamageTime = 0;
            lastHealTime = 0;
            lastObservedHealth = -1f;
            editPreview = true;
        } else if (editPreview && wasEditActive) {
            lastHitTime = now - HIDE_DELAY;
            editPreview = false;
        }
        wasEditActive = editActive;

        if ((!Config.targetHud && !editPreview) || target == null) {
            if (!Config.targetHud) {
                destroyTexture(client);
                resetNewHudRuntimeState();
            }
            return;
        }

        if (!target.method_5805() && now - lastHitTime < HIDE_DELAY) {
            lastHitTime = now - HIDE_DELAY;
        }

        float fadeIn = (float) (now - appearanceTime) / ANIM_DURATION;
        float fadeOut = 1.0f - (float) (now - (lastHitTime + HIDE_DELAY)) / ANIM_DURATION;

        float alpha = class_3532.method_15363(Math.min(fadeIn, fadeOut), 0.0f, 1.0f);

        if (alpha <= 0.0f) {
            if (now - lastHitTime > HIDE_DELAY || !target.method_5805()) {
                isFullyHidden = true;
                invalidatePlayerSkinCache(target);
                target = null;
                resetHealthTextAnimation();
                resetNewHudRuntimeState();
                lastObservedHealth = -1f;
                destroyTexture(client);
            }
            return;
        }

        if (Config.targetHudMode == Config.TargetHudMode.NEW || Config.targetHudMode == Config.TargetHudMode.BLUR) {
            renderNew(graphics, client, alpha, now, Config.targetHudMode == Config.TargetHudMode.BLUR);
            return;
        }

        destroyTexture(client);
        renderLite(graphics, client, alpha, now);
    }

    private void renderLite(class_332 graphics, class_310 client, float alpha, long now) {
        int screenW = client.method_22683().method_4486();
        int screenH = client.method_22683().method_4502();
        float hudScale = Math.max(0.5f, Config.targetHudScale);
        int scaledW = Math.round(HUD_WIDTH * hudScale);
        int scaledH = Math.round(HUD_HEIGHT * hudScale);

        int x = (int) (screenW * 0.5f + Config.targetHudX);
        int y = (int) (screenH * 0.5f + Config.targetHudY);
        x = Math.max(0, Math.min(x, screenW - scaledW));
        y = Math.max(0, Math.min(y, screenH - scaledH));

        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(x, y);
        graphics.method_51448().scale(hudScale, hudScale);
        graphics.method_51448().translate(-x, -y);

        int alphaInt = Math.round(alpha * 255);
        int alphaBits = alphaInt << 24;
        int whiteWithAlpha = alphaBits | 0xFFFFFF;
        int grayWithAlpha = alphaBits | 0x444444;

        graphics.method_73198(x, y, HUD_WIDTH, HUD_HEIGHT, whiteWithAlpha);

        int avatarX = x + BORDER + PADDING;
        int avatarY = y + (HUD_HEIGHT - AVATAR_SIZE) / 2;
        int avatarX2 = avatarX + AVATAR_SIZE;
        int avatarY2 = avatarY + AVATAR_SIZE;
        int iconX = avatarX + (AVATAR_SIZE - 16) / 2;
        int iconY = avatarY + (AVATAR_SIZE - 16) / 2;

        float scale = 1.0f;
        float flashAlphaFactor = 0.0f;
        long damageElapsed = now - lastDamageTime;
        if (damageElapsed < DAMAGE_FLASH_DURATION) {
            float damageFactor = (float) damageElapsed / DAMAGE_FLASH_DURATION;
            float scaleProgress = (float) Math.sin(damageFactor * Math.PI);
            scale = 1.0f - scaleProgress * 0.2f;
            flashAlphaFactor = 1.0f - damageFactor;
        }

        graphics.method_51448().pushMatrix();
        float centerX = avatarX + AVATAR_SIZE * 0.5f;
        float centerY = avatarY + AVATAR_SIZE * 0.5f;

        graphics.method_51448().translate(centerX, centerY);
        graphics.method_51448().scale(scale, scale);
        graphics.method_51448().translate(-centerX, -centerY);

        if (target instanceof class_1657 player) {
            try {
                class_8685 skin = resolvePlayerSkin(client, player);
                class_7532.method_52722(graphics, skin, avatarX, avatarY, AVATAR_SIZE);
            } catch (Exception e) {
                graphics.method_25294(avatarX, avatarY, avatarX2, avatarY2, alphaBits | 0x000000);
            }
        } else {
            class_1826 eggItem = class_1826.method_8019(target.method_5864());
            if (eggItem != null) {
                graphics.method_51445(new class_1799(eggItem), iconX, iconY);
            } else {
                graphics.method_25294(avatarX, avatarY, avatarX2, avatarY2, alphaBits | 0x000000);
            }
        }

        if (flashAlphaFactor > 0.0f) {
            int damageAlphaInt = (int) (alphaInt * flashAlphaFactor * 0.6f);
            int flashColor = (damageAlphaInt << 24) | 0xFF0000;
            graphics.method_25294(avatarX, avatarY, avatarX2, avatarY2, flashColor);
        }
        graphics.method_51448().popMatrix();

        int infoX = avatarX + AVATAR_SIZE + PADDING;
        int infoW = HUD_WIDTH - BORDER - PADDING - AVATAR_SIZE - PADDING * 2 - BORDER;

        String name = target.method_5476().getString();
        if (name.length() > 16) name = name.substring(0, 16) + "..";
        graphics.method_51439(client.field_1772, class_2561.method_43470(name), infoX, y + PADDING + 2, whiteWithAlpha, false);

        float maxHealth = target.method_6063();
        float currentHealth = target.method_6032();

        int scoreboardHealth = TargetScoreboardUtil.getBelowNameHealth(target);
        if (scoreboardHealth != -1) {
            currentHealth = (float) scoreboardHealth;
            if (currentHealth > maxHealth) maxHealth = currentHealth;
        }

        float ratio = maxHealth > 0 ? Math.max(0, Math.min(1, currentHealth / maxHealth)) : 0;

        int barY = y + HUD_HEIGHT - PADDING - 6;
        int barW = infoW;

        graphics.method_25294(infoX, barY, infoX + barW, barY + 5, grayWithAlpha);

        int filledW = (int) (barW * ratio);
        if (filledW > 0) {
            int hColor = getHealthColor(ratio);
            int hColorWithAlpha = alphaBits | (hColor & 0xFFFFFF);
            graphics.method_25294(infoX, barY, infoX + filledW, barY + 5, hColorWithAlpha);
        }

        if (client.field_1724 != null) {
            float selfHealth = client.field_1724.method_6032();
            String statusText = selfHealth > currentHealth ? "W" : "L";
            int statusColor = selfHealth > currentHealth ? (alphaBits | 0x55FF55) : (alphaBits | 0xFF5555);

            int textWidth = client.field_1772.method_1727(statusText);
            graphics.method_51439(client.field_1772, class_2561.method_43470(statusText), x + HUD_WIDTH - PADDING - textWidth, y + PADDING + 2, statusColor, false);
        }
        graphics.method_51448().popMatrix();
    }

    private void renderNew(class_332 graphics, class_310 client, float alpha, long now, boolean blurMode) {
        int screenW = client.method_22683().method_4486();
        int screenH = client.method_22683().method_4502();
        float hudScale = Math.max(0.5f, Config.targetHudScale);
        int scaledW = Math.round(NEW_HUD_WIDTH * hudScale);
        int scaledH = Math.round(NEW_HUD_HEIGHT * hudScale);

        int x = (int) (screenW * 0.5f + Config.targetHudX);
        int y = (int) (screenH * 0.5f + Config.targetHudY);
        x = Math.max(0, Math.min(x, screenW - scaledW));
        y = Math.max(0, Math.min(y, screenH - scaledH));

        float maxHealth = target.method_6063();
        float currentHealth = target.method_6032();
        int scoreboardHealth = TargetScoreboardUtil.getBelowNameHealth(target);
        if (scoreboardHealth != -1) {
            currentHealth = (float) scoreboardHealth;
            if (currentHealth > maxHealth) maxHealth = currentHealth;
        }
        float absorption = Math.max(0f, target.method_6067());
        updateHealthTransition(currentHealth, now);
        float ratio = maxHealth > 0 ? class_3532.method_15363(currentHealth / maxHealth, 0f, 1f) : 0f;
        float absorptionRatio = maxHealth > 0 ? class_3532.method_15363(absorption / maxHealth, 0f, 1f) : 0f;
        updateHealthTextAnimation(currentHealth, now);
        float dt = lastRenderTime == 0L ? 0.016f : Math.min((now - lastRenderTime) / 1000f, 0.05f);
        lastRenderTime = now;
        animatedHealthRatio += (ratio - animatedHealthRatio) * Math.min(1f, dt * 10f);
        animatedAbsorptionRatio += (absorptionRatio - animatedAbsorptionRatio) * Math.min(1f, dt * 10f);

        String name = truncateName(target.method_5476().getString());
        float cx = x + scaledW * 0.5f;
        float cy = y + scaledH * 0.5f;
        float drawScale = easeOutBack(alpha);
        float drawX = cx + (x - cx) * drawScale;
        float drawY = cy + (y - cy) * drawScale;
        float drawW = scaledW * drawScale;
        float drawH = scaledH * drawScale;
        float drawRadius = 16f * hudScale * drawScale;

        renderNewBaseTexture(client, name, blurMode);
        renderNewOverlayTexture(client, currentHealthText, animatedHealthRatio, animatedAbsorptionRatio, now, blurMode);
        if (blurMode) {
            SkiaBlurRenderer.getInstance().render(client, drawX, drawY, drawW, drawH, drawRadius, Config.skiaBlurTintColor(), Config.skiaBlurStrength);
        }

        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(cx, cy);
        graphics.method_51448().scale(drawScale, drawScale);
        graphics.method_51448().translate(-cx, -cy);
        graphics.method_51448().translate(x, y);
        graphics.method_51448().scale(hudScale, hudScale);
        graphics.method_51448().translate(-x, -y);
        graphics.method_25302(class_10799.field_56883, TEXTURE_ID, x, y, 0f, 0f, NEW_HUD_WIDTH, NEW_HUD_HEIGHT, textureW, textureH, textureW, textureH);
        graphics.method_25302(class_10799.field_56883, OVERLAY_TEXTURE_ID, x + NEW_OVERLAY_X, y + NEW_OVERLAY_Y, 0f, 0f, NEW_OVERLAY_WIDTH, NEW_OVERLAY_HEIGHT, overlayTextureW, overlayTextureH, overlayTextureW, overlayTextureH);

        int avatarX = x + 12;
        int avatarY = y + 10;
        int alphaInt = Math.round(alpha * 255);
        int alphaBits = alphaInt << 24;
        float avatarScale = 1.0f;
        float hurtFlashFactor = getFlashFactor(now, lastDamageTime);
        float healFlashFactor = getFlashFactor(now, lastHealTime);
        renderAvatarFlashTexture(client, alpha, hurtFlashFactor, healFlashFactor);
        boolean playerRoundedAvatarRendered = false;
        if (hurtFlashFactor > 0.0f) {
            float damageFactor = 1.0f - hurtFlashFactor;
            float scaleProgress = (float) Math.sin(damageFactor * Math.PI);
            avatarScale = 1.0f - scaleProgress * 0.2f;
        }

        graphics.method_51448().pushMatrix();
        float avatarCenterX = avatarX + NEW_AVATAR_SIZE * 0.5f;
        float avatarCenterY = avatarY + NEW_AVATAR_SIZE * 0.5f;
        graphics.method_51448().translate(avatarCenterX, avatarCenterY);
        graphics.method_51448().scale(avatarScale, avatarScale);
        graphics.method_51448().translate(-avatarCenterX, -avatarCenterY);
        int avatarDrawInset = 0;
        int avatarDrawSize = NEW_AVATAR_SIZE - avatarDrawInset * 2;
        if (target instanceof class_1657 player) {
            try {
                class_8685 skin = resolvePlayerSkin(client, player);
                playerRoundedAvatarRendered = renderRoundedPlayerAvatarTexture(graphics, client, skin, avatarX + avatarDrawInset, avatarY + avatarDrawInset, avatarDrawSize);
                if (!playerRoundedAvatarRendered) {
                    class_7532.method_52722(graphics, skin, avatarX + avatarDrawInset, avatarY + avatarDrawInset, avatarDrawSize);
                }
            } catch (Exception e) {
                graphics.method_25294(avatarX + avatarDrawInset, avatarY + avatarDrawInset, avatarX + avatarDrawInset + avatarDrawSize, avatarY + avatarDrawInset + avatarDrawSize, alphaBits | 0x111111);
            }
        } else {
            class_1826 eggItem = class_1826.method_8019(target.method_5864());
            if (eggItem != null) {
                graphics.method_51445(new class_1799(eggItem), avatarX + 11, avatarY + 11);
            } else {
                graphics.method_25294(avatarX + avatarDrawInset, avatarY + avatarDrawInset, avatarX + avatarDrawInset + avatarDrawSize, avatarY + avatarDrawInset + avatarDrawSize, alphaBits | 0x111111);
            }
        }
        if (lastAvatarFlashKey != 0) {
            graphics.method_25302(class_10799.field_56883, AVATAR_FLASH_TEXTURE_ID, avatarX, avatarY, 0f, 0f, NEW_AVATAR_SIZE, NEW_AVATAR_SIZE, avatarFlashW, avatarFlashH, avatarFlashW, avatarFlashH);
        }
        if (!blurMode && !playerRoundedAvatarRendered) {
            renderAvatarMaskTexture(client);
            graphics.method_25302(class_10799.field_56883, AVATAR_MASK_TEXTURE_ID, avatarX, avatarY, 0f, 0f, NEW_AVATAR_SIZE, NEW_AVATAR_SIZE, avatarMaskW, avatarMaskH, avatarMaskW, avatarMaskH);
        }
        graphics.method_51448().popMatrix();
        graphics.method_51448().popMatrix();
    }

    private boolean renderRoundedPlayerAvatarTexture(class_332 graphics, class_310 client, class_8685 skin, int x, int y, int size) {
        float targetScale = Math.max(1f, (float) client.method_22683().method_4495() * Math.max(0.5f, Config.targetHudScale));
        int targetW = Math.max(1, Math.round(size * targetScale));
        int targetH = Math.max(1, Math.round(size * targetScale));
        String key = skin.comp_1626().comp_3626() + "|" + targetW + "x" + targetH;

        if (roundedAvatarTexture != null && key.equals(lastRoundedAvatarKey) && targetW == roundedAvatarW && targetH == roundedAvatarH) {
            graphics.method_25302(class_10799.field_56883, ROUNDED_AVATAR_TEXTURE_ID, x, y, 0f, 0f, size, size, roundedAvatarW, roundedAvatarH, roundedAvatarW, roundedAvatarH);
            return true;
        }

        if (pendingRoundedAvatarImage != null && key.equals(pendingRoundedAvatarKey) && pendingRoundedAvatarImage.isDone()) {
            try {
                class_1011 image = pendingRoundedAvatarImage.join();
                releaseRoundedAvatarTexture(client);
                roundedAvatarTexture = new class_1043(() -> "dioxide_lite:target_hud_rounded_avatar", image);
                client.method_1531().method_4616(ROUNDED_AVATAR_TEXTURE_ID, roundedAvatarTexture);
                roundedAvatarW = targetW;
                roundedAvatarH = targetH;
                lastRoundedAvatarKey = key;
                pendingRoundedAvatarImage = null;
                pendingRoundedAvatarKey = "";
                graphics.method_25302(class_10799.field_56883, ROUNDED_AVATAR_TEXTURE_ID, x, y, 0f, 0f, size, size, roundedAvatarW, roundedAvatarH, roundedAvatarW, roundedAvatarH);
                return true;
            } catch (Exception ignored) {
                pendingRoundedAvatarImage = null;
                pendingRoundedAvatarKey = "";
                lastRoundedAvatarKey = key;
                return false;
            }
        }

        if (pendingRoundedAvatarImage == null || !key.equals(pendingRoundedAvatarKey)) {
            pendingRoundedAvatarKey = key;
            pendingRoundedAvatarImage = CompletableFuture.supplyAsync(() -> loadRoundedAvatarImage(client, skin.comp_1626(), targetW, targetH));
        }
        return false;
    }

    private class_1011 loadRoundedAvatarImage(class_310 client, class_12079.class_12081 texture, int targetW, int targetH) {
        try (InputStream resourceStream = client.method_1478().open(texture.comp_3627())) {
            try (class_1011 source = class_1011.method_4309(resourceStream)) {
                return createRoundedAvatarImage(source, targetW, targetH);
            }
        } catch (Exception ignored) {
            if (texture instanceof class_12079.class_12080 downloadedTexture) {
                try (InputStream stream = URI.create(downloadedTexture.comp_4939()).toURL().openStream();
                     class_1011 source = class_1011.method_4309(stream)) {
                    return createRoundedAvatarImage(source, targetW, targetH);
                } catch (Exception ignoredAgain) {
                    throw new IllegalStateException("Failed to load player skin image");
                }
            }
            throw new IllegalStateException("Failed to load player skin image");
        }
    }

    private class_1011 createRoundedAvatarImage(class_1011 source, int targetW, int targetH) {
        class_1011 output = new class_1011(class_1011.class_1012.field_4997, targetW, targetH, false);
        int sourceW = Math.max(1, source.method_4307());
        int sourceH = Math.max(1, source.method_4323());
        int skinScaleX = Math.max(1, sourceW / 64);
        int skinScaleY = Math.max(1, sourceH / 64);
        float radius = Math.min(targetW, targetH) * (NEW_AVATAR_RADIUS / (float) NEW_AVATAR_SIZE);

        for (int py = 0; py < targetH; py++) {
            for (int px = 0; px < targetW; px++) {
                if (!insideRoundedRect(px + 0.5f, py + 0.5f, targetW, targetH, radius)) {
                    output.method_61941(px, py, 0);
                    continue;
                }

                float u = px / (float) targetW;
                float v = py / (float) targetH;
                int srcX = class_3532.method_15340((int) ((8f + u * 8f) * skinScaleX), 0, sourceW - 1);
                int srcY = class_3532.method_15340((int) ((8f + v * 8f) * skinScaleY), 0, sourceH - 1);
                int hatX = class_3532.method_15340((int) ((40f + u * 8f) * skinScaleX), 0, sourceW - 1);
                int hatY = srcY;
                int color = blendArgb(source.method_61940(srcX, srcY), source.method_61940(hatX, hatY));
                output.method_61941(px, py, color);
            }
        }
        return output;
    }

    private boolean insideRoundedRect(float px, float py, int width, int height, float radius) {
        float left = radius;
        float right = width - radius;
        float top = radius;
        float bottom = height - radius;
        float cx = class_3532.method_15363(px, left, right);
        float cy = class_3532.method_15363(py, top, bottom);
        float dx = px - cx;
        float dy = py - cy;
        return dx * dx + dy * dy <= radius * radius;
    }

    private int blendArgb(int base, int overlay) {
        int alpha = (overlay >>> 24) & 0xFF;
        if (alpha <= 0) return base;
        if (alpha >= 255) return overlay;

        int inv = 255 - alpha;
        int r = (((overlay >>> 16) & 0xFF) * alpha + ((base >>> 16) & 0xFF) * inv) / 255;
        int g = (((overlay >>> 8) & 0xFF) * alpha + ((base >>> 8) & 0xFF) * inv) / 255;
        int b = ((overlay & 0xFF) * alpha + (base & 0xFF) * inv) / 255;
        int a = Math.max((base >>> 24) & 0xFF, alpha);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private void renderNewBaseTexture(class_310 client, String name, boolean blurMode) {
        ensureNativeLoaded();
        float targetScale = Math.max(1f, (float) client.method_22683().method_4495() * Math.max(0.5f, Config.targetHudScale));
        int targetW = Math.max(1, Math.round(NEW_HUD_WIDTH * targetScale));
        int targetH = Math.max(1, Math.round(NEW_HUD_HEIGHT * targetScale));
        if (dynamicTexture != null && targetW == textureW && targetH == textureH && name.equals(lastTextureName) && lastTextureTheme == Config.hudTheme && lastTextureBlurMode == blurMode) return;

        if (surface == null || dynamicTexture == null || targetW != textureW || targetH != textureH) {
            destroyBaseTexture(client);
            surface = Surface.makeRaster(new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), targetW, targetH), 0, SURFACE_PROPS);
            dynamicTexture = new class_1043("dioxide_lite:target_hud_new", targetW, targetH, false);
            client.method_1531().method_4616(TEXTURE_ID, dynamicTexture);
            textureW = targetW;
            textureH = targetH;
            lastTextureName = "";
        }

        Canvas c = surface.getCanvas();
        c.restoreToCount(1);
        c.resetMatrix();
        c.clear(0x00000000);
        c.save();
        c.scale(targetScale, targetScale);
        if (!blurMode) {
            newHudBgPaint.setColor(newHudCardColor());
            c.drawRRect(RRect.makeXYWH(0f, 0f, NEW_HUD_WIDTH, NEW_HUD_HEIGHT, 16f), newHudBgPaint);
        }
        if (!blurMode) {
            newHudAvatarPaint.setColor(newHudAvatarBackplateColor());
            c.drawRRect(RRect.makeXYWH(12f, 10f, NEW_AVATAR_SIZE, NEW_AVATAR_SIZE, NEW_AVATAR_RADIUS), newHudAvatarPaint);
        }

        FontRenderer.drawText(c, name, 60f, 24f, 13f, newHudPrimaryTextColor(blurMode));
        c.restore();
        uploadSurface(surface, dynamicTexture, textureW, textureH);
        lastTextureName = name;
        lastTextureTheme = Config.hudTheme;
        lastTextureBlurMode = blurMode;
    }

    private void renderNewOverlayTexture(class_310 client, String healthText, float healthRatio, float absorptionRatio, long now, boolean blurMode) {
        ensureNativeLoaded();
        float targetScale = Math.max(1f, (float) client.method_22683().method_4495() * Math.max(0.5f, Config.targetHudScale));
        int targetW = Math.max(1, Math.round(NEW_OVERLAY_WIDTH * targetScale));
        int targetH = Math.max(1, Math.round(NEW_OVERLAY_HEIGHT * targetScale));
        int healthKey = Math.round(healthRatio * 120f);
        int absorptionKey = Math.round(absorptionRatio * 80f);
        int healthTextAnimKey = getHealthTextAnimKey(now);
        if (overlayTexture != null && targetW == overlayTextureW && targetH == overlayTextureH && healthText.equals(lastTextureHealthText) && healthTextAnimKey == lastTextureHealthTextAnim && healthKey == lastTextureHealth && absorptionKey == lastTextureAbsorption && lastOverlayTextureTheme == Config.hudTheme && lastOverlayTextureBlurMode == blurMode) return;

        if (overlaySurface == null || overlayTexture == null || targetW != overlayTextureW || targetH != overlayTextureH) {
            destroyOverlayTexture(client);
            overlaySurface = Surface.makeRaster(new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), targetW, targetH), 0, SURFACE_PROPS);
            overlayTexture = new class_1043("dioxide_lite:target_hud_new_overlay", targetW, targetH, false);
            client.method_1531().method_4616(OVERLAY_TEXTURE_ID, overlayTexture);
            overlayTextureW = targetW;
            overlayTextureH = targetH;
            lastTextureHealthText = "";
        }

        Canvas c = overlaySurface.getCanvas();
        c.restoreToCount(1);
        c.resetMatrix();
        c.clear(0x00000000);
        c.save();
        c.scale(targetScale, targetScale);
        c.translate(-NEW_OVERLAY_X, -NEW_OVERLAY_Y);
        drawAnimatedHealthText(c, healthText, now, blurMode);

        float barX = 60f;
        float barY = 45f;
        float barW = 112f;
        float barH = 7f;
        newHudTrackPaint.setColor(newHudTrackColor(blurMode));
        c.drawRRect(RRect.makeXYWH(barX, barY, barW, barH, barH * 0.5f), newHudTrackPaint);
        float fillW = Math.max(barH, barW * class_3532.method_15363(healthRatio, 0f, 1f));
        newHudFillPaint.setColor(0xFF000000 | (getHealthColor(class_3532.method_15363(healthRatio, 0f, 1f)) & 0xFFFFFF));
        c.drawRRect(RRect.makeXYWH(barX, barY, fillW, barH, barH * 0.5f), newHudFillPaint);
        if (absorptionRatio > 0.01f) {
            float absorbW = Math.min(barW, barW * class_3532.method_15363(absorptionRatio, 0f, 1f));
            newHudAbsorbPaint.setColor(0xFFF5B83D);
            c.drawRRect(RRect.makeXYWH(barX + barW - absorbW, barY, absorbW, barH, barH * 0.5f), newHudAbsorbPaint);
        }

        c.restore();
        uploadSurface(overlaySurface, overlayTexture, overlayTextureW, overlayTextureH);
        lastTextureHealthText = healthText;
        lastTextureHealth = healthKey;
        lastTextureAbsorption = absorptionKey;
        lastTextureHealthTextAnim = healthTextAnimKey;
        lastOverlayTextureTheme = Config.hudTheme;
        lastOverlayTextureBlurMode = blurMode;
    }

    private void updateHealthTextAnimation(float value, long now) {
        String text = String.format(java.util.Locale.ROOT, "%.1f HP", value);
        if (currentHealthText.isEmpty()) {
            currentHealthText = text;
            previousHealthText = text;
            lastHealthTextValue = value;
            return;
        }
        if (!text.equals(currentHealthText)) {
            previousHealthText = currentHealthText;
            healthTextDirection = value > lastHealthTextValue ? 1 : -1;
            healthTextAnimStart = now;
            currentHealthText = text;
            lastHealthTextValue = value;
        }
    }

    private void drawAnimatedHealthText(Canvas c, String healthText, long now, boolean blurMode) {
        float progress = healthTextAnimStart == 0L ? 1f : class_3532.method_15363((now - healthTextAnimStart) / (float) HEALTH_TEXT_ANIM_DURATION, 0f, 1f);
        float eased = 1f - (1f - progress) * (1f - progress) * (1f - progress);
        float baseY = 40f;
        float height = 14f;
        float x = 60f;
        c.save();
        c.clipRect(Rect.makeXYWH(58f, 28f, 72f, 16f));
        for (int i = 0; i < healthText.length(); i++) {
            String ch = healthText.substring(i, i + 1);
            String oldCh = i < previousHealthText.length() ? previousHealthText.substring(i, i + 1) : ch;
            boolean digit = Character.isDigit(ch.charAt(0));
            boolean changed = digit && progress < 1f && healthTextDirection != 0 && !ch.equals(oldCh);
            float w = getHealthCharWidth(ch);
            if (changed) {
                float oldY = baseY + (healthTextDirection > 0 ? -height * eased : height * eased);
                float newY = baseY + (healthTextDirection > 0 ? height * (1f - eased) : -height * (1f - eased));
                FontRenderer.drawText(c, oldCh, x, oldY, 10f, newHudMutedTextColor(blurMode));
                FontRenderer.drawText(c, ch, x, newY, 10f, newHudMutedTextColor(blurMode));
            } else {
                FontRenderer.drawText(c, ch, x, baseY, 10f, newHudMutedTextColor(blurMode));
            }
            x += w;
        }
        c.restore();
    }

    private int newHudCardColor() {
        return Config.hudTheme == Config.HudTheme.LIGHT ? 0xF7F8FAFC : 0xE6111827;
    }

    private int newHudAvatarBackplateColor() {
        return Config.hudTheme == Config.HudTheme.LIGHT ? 0x66FFFFFF : 0x332A3345;
    }

    private int newHudPrimaryTextColor(boolean blurMode) {
        return blurMode ? Config.hudPrimaryTextColor() : (Config.hudTheme == Config.HudTheme.LIGHT ? 0xFF202027 : 0xFFF8FAFC);
    }

    private int newHudMutedTextColor(boolean blurMode) {
        return blurMode ? Config.hudMutedTextColor() : (Config.hudTheme == Config.HudTheme.LIGHT ? 0xAA5C5870 : 0xB8CBD5E1);
    }

    private int newHudTrackColor(boolean blurMode) {
        if (blurMode) {
            return Config.hudTheme == Config.HudTheme.LIGHT ? 0x33111827 : 0x2D000000;
        }
        return Config.hudTheme == Config.HudTheme.LIGHT ? 0x22111827 : 0x33FFFFFF;
    }

    private int getHealthTextAnimKey(long now) {
        if (healthTextAnimStart == 0L) return 100;
        float progress = class_3532.method_15363((now - healthTextAnimStart) / (float) HEALTH_TEXT_ANIM_DURATION, 0f, 1f);
        if (progress >= 1f) return 100;
        return Math.round(progress * 24f);
    }

    private void resetHealthTextAnimation() {
        currentHealthText = "";
        previousHealthText = "";
        healthTextAnimStart = 0L;
        healthTextDirection = 0;
        lastHealthTextValue = -1f;
    }

    private void resetNewHudRuntimeState() {
        lastRenderTime = 0L;
        animatedHealthRatio = 1f;
        animatedAbsorptionRatio = 0f;
        lastTextureName = "";
        lastTextureHealthText = "";
        lastTextureHealth = -1;
        lastTextureAbsorption = -1;
        lastTextureHealthTextAnim = -1;
    }

    private void updateHealthTransition(float currentHealth, long now) {
        if (lastObservedHealth < 0f) {
            lastObservedHealth = currentHealth;
            return;
        }
        if (currentHealth > lastObservedHealth + 0.001f) {
            lastHealTime = now;
        } else if (currentHealth < lastObservedHealth - 0.001f) {
            lastDamageTime = now;
        }
        lastObservedHealth = currentHealth;
    }

    private float getFlashFactor(long now, long startTime) {
        if (startTime <= 0L) return 0.0f;
        long elapsed = now - startTime;
        if (elapsed < 0L || elapsed >= DAMAGE_FLASH_DURATION) return 0.0f;
        return 1.0f - (float) elapsed / DAMAGE_FLASH_DURATION;
    }

    private String truncateName(String rawName) {
        if (rawName.equals(lastRawName)) return lastTruncatedName;

        lastRawName = rawName;
        if (FontRenderer.measureTextWidth(rawName, 13f) <= 95f) {
            lastTruncatedName = rawName;
            return lastTruncatedName;
        }

        int low = 1;
        int high = rawName.length();
        while (low < high) {
            int mid = (low + high + 1) >>> 1;
            if (FontRenderer.measureTextWidth(rawName.substring(0, mid) + "...", 13f) <= 95f) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        lastTruncatedName = rawName.substring(0, low) + "...";
        return lastTruncatedName;
    }

    private void renderAvatarMaskTexture(class_310 client) {
        ensureNativeLoaded();
        float targetScale = Math.max(1f, (float) client.method_22683().method_4495() * Math.max(0.5f, Config.targetHudScale));
        int targetW = Math.max(1, Math.round(NEW_AVATAR_SIZE * targetScale));
        int targetH = Math.max(1, Math.round(NEW_AVATAR_SIZE * targetScale));
        if (avatarMaskTexture != null && targetW == avatarMaskW && targetH == avatarMaskH && lastAvatarMaskTheme == Config.hudTheme) return;

        if (avatarMaskSurface != null) {
            avatarMaskSurface.close();
            avatarMaskSurface = null;
        }
        if (avatarMaskTexture != null) {
            client.method_1531().method_4615(AVATAR_MASK_TEXTURE_ID);
            avatarMaskTexture = null;
        }

        avatarMaskSurface = Surface.makeRaster(new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), targetW, targetH), 0, SURFACE_PROPS);
        avatarMaskTexture = new class_1043("dioxide_lite:target_hud_avatar_mask", targetW, targetH, false);
        client.method_1531().method_4616(AVATAR_MASK_TEXTURE_ID, avatarMaskTexture);
        avatarMaskW = targetW;
        avatarMaskH = targetH;

        Canvas c = avatarMaskSurface.getCanvas();
        c.restoreToCount(1);
        c.resetMatrix();
        c.clear(0x00000000);
        c.save();
        c.scale(targetScale, targetScale);
        avatarMaskCoverPaint.setColor(newHudAvatarBackplateColor());
        c.drawRect(io.github.humbleui.types.Rect.makeXYWH(0f, 0f, NEW_AVATAR_SIZE, NEW_AVATAR_SIZE), avatarMaskCoverPaint);
        c.drawRRect(RRect.makeXYWH(-0.75f, -0.75f, NEW_AVATAR_SIZE + 1.5f, NEW_AVATAR_SIZE + 1.5f, NEW_AVATAR_RADIUS + 0.75f), avatarMaskHolePaint);
        c.restore();
        uploadSurface(avatarMaskSurface, avatarMaskTexture, avatarMaskW, avatarMaskH);
        lastAvatarMaskTheme = Config.hudTheme;
    }

    private void renderAvatarFlashTexture(class_310 client, float alpha, float hurtFlashFactor, float healFlashFactor) {
        ensureNativeLoaded();
        int damageAlpha = Math.round(alpha * hurtFlashFactor * 0.6f * 255f);
        int healAlpha = Math.round(alpha * healFlashFactor * 0.62f * 255f);
        int flashKey = (damageAlpha << 8) | healAlpha;
        float targetScale = Math.max(1f, (float) client.method_22683().method_4495() * Math.max(0.5f, Config.targetHudScale));
        int targetW = Math.max(1, Math.round(NEW_AVATAR_SIZE * targetScale));
        int targetH = Math.max(1, Math.round(NEW_AVATAR_SIZE * targetScale));
        if (avatarFlashTexture != null && targetW == avatarFlashW && targetH == avatarFlashH && lastAvatarFlashKey == flashKey) return;

        if (avatarFlashSurface != null) {
            avatarFlashSurface.close();
            avatarFlashSurface = null;
        }
        if (avatarFlashTexture != null) {
            client.method_1531().method_4615(AVATAR_FLASH_TEXTURE_ID);
            avatarFlashTexture = null;
        }

        avatarFlashSurface = Surface.makeRaster(new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), targetW, targetH), 0, SURFACE_PROPS);
        avatarFlashTexture = new class_1043("dioxide_lite:target_hud_avatar_flash", targetW, targetH, false);
        client.method_1531().method_4616(AVATAR_FLASH_TEXTURE_ID, avatarFlashTexture);
        avatarFlashW = targetW;
        avatarFlashH = targetH;

        Canvas c = avatarFlashSurface.getCanvas();
        c.restoreToCount(1);
        c.resetMatrix();
        c.clear(0x00000000);
        c.save();
        c.scale(targetScale, targetScale);
        if (damageAlpha > 0) {
            avatarFlashPaint.setColor((damageAlpha << 24) | 0xFF0000);
            c.drawRRect(RRect.makeXYWH(0f, 0f, NEW_AVATAR_SIZE, NEW_AVATAR_SIZE, NEW_AVATAR_RADIUS), avatarFlashPaint);
        }
        if (healAlpha > 0) {
            avatarFlashPaint.setColor((healAlpha << 24) | 0x55FF55);
            c.drawRRect(RRect.makeXYWH(0f, 0f, NEW_AVATAR_SIZE, NEW_AVATAR_SIZE, NEW_AVATAR_RADIUS), avatarFlashPaint);
        }
        c.restore();
        uploadSurface(avatarFlashSurface, avatarFlashTexture, avatarFlashW, avatarFlashH);
        lastAvatarFlashKey = flashKey;
    }

    private float easeOutBack(float value) {
        float t = class_3532.method_15363(value, 0f, 1f) - 1f;
        return 1f + t * t * (1.55f * t + 0.55f);
    }

    private void ensureNativeLoaded() {
        if (nativeLoaded) return;
        Library.load();
        nativeLoaded = true;
    }

    private void uploadSurface(Surface sourceSurface, class_1043 targetTexture, int width, int height) {
        Pixmap pixmap = new Pixmap();
        try {
            if (!sourceSurface.peekPixels(pixmap)) {
                return;
            }
            long addr = pixmap.getAddr();
            int byteSize = height * pixmap.getRowBytes();
            ByteBuffer buf = MemoryUtil.memByteBuffer(addr, byteSize);
            GpuTexture gpuTexture = targetTexture.method_68004();
            RenderSystem.getDevice().createCommandEncoder()
                    .writeToTexture(gpuTexture, buf, class_1011.class_1012.field_4997, 0, 0, 0, 0, width, height);
        } finally {
            pixmap.close();
        }
    }

    private void destroyBaseTexture(class_310 client) {
        if (surface != null) {
            surface.close();
            surface = null;
        }
        if (dynamicTexture != null) {
            client.method_1531().method_4615(TEXTURE_ID);
            dynamicTexture = null;
        }
        textureW = -1;
        textureH = -1;
        lastTextureName = "";
        lastTextureTheme = null;
    }

    private void destroyOverlayTexture(class_310 client) {
        if (overlaySurface != null) {
            overlaySurface.close();
            overlaySurface = null;
        }
        if (overlayTexture != null) {
            client.method_1531().method_4615(OVERLAY_TEXTURE_ID);
            overlayTexture = null;
        }
        overlayTextureW = -1;
        overlayTextureH = -1;
        lastTextureHealthText = "";
        lastTextureHealth = -1;
        lastTextureAbsorption = -1;
        lastTextureHealthTextAnim = -1;
        lastTextureBlurMode = false;
        lastOverlayTextureBlurMode = false;
        lastOverlayTextureTheme = null;
    }

    private void releaseRoundedAvatarTexture(class_310 client) {
        if (roundedAvatarTexture != null) {
            client.method_1531().method_4615(ROUNDED_AVATAR_TEXTURE_ID);
            roundedAvatarTexture = null;
        }
        roundedAvatarW = -1;
        roundedAvatarH = -1;
        lastRoundedAvatarKey = "";
    }

    private void destroyTexture(class_310 client) {
        destroyBaseTexture(client);
        destroyOverlayTexture(client);
        releaseRoundedAvatarTexture(client);
        if (avatarMaskSurface != null) {
            avatarMaskSurface.close();
            avatarMaskSurface = null;
        }
        if (avatarMaskTexture != null) {
            client.method_1531().method_4615(AVATAR_MASK_TEXTURE_ID);
            avatarMaskTexture = null;
        }
        if (avatarFlashSurface != null) {
            avatarFlashSurface.close();
            avatarFlashSurface = null;
        }
        if (avatarFlashTexture != null) {
            client.method_1531().method_4615(AVATAR_FLASH_TEXTURE_ID);
            avatarFlashTexture = null;
        }
        avatarMaskW = -1;
        avatarMaskH = -1;
        lastAvatarMaskTheme = null;
        avatarFlashW = -1;
        avatarFlashH = -1;
        lastAvatarFlashKey = -1;
    }

    private int getHealthColor(float ratio) {
        int r, g;
        if (ratio > 0.5f) {
            float t = (ratio - 0.5f) * 2f;
            r = (int) (255 * (1f - t));
            g = 255;
        } else {
            float t = ratio * 2f;
            r = 255;
            g = (int) (255 * t);
        }
        return 0xFF000000 | (r << 16) | (g << 8);
    }
}
