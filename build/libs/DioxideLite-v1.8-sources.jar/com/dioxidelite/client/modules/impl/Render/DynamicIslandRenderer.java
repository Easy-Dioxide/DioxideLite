package com.dioxidelite.client.modules.impl.Render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.dioxidelite.Config;
import com.dioxidelite.client.render.font.FontRenderer;
import com.dioxidelite.client.render.skia.SkiaBlurRenderer;
import com.dioxidelite.client.render.skia.LiquidGlassVisualSystem;
import com.dioxidelite.client.render.skia.DioxideLiteVisuals;
import io.github.humbleui.skija.*;
import io.github.humbleui.skija.impl.Library;
import io.github.humbleui.types.RRect;
import io.github.humbleui.types.Rect;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_1934;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_640;
import net.minecraft.class_642;

public class DynamicIslandRenderer {
    private static final DynamicIslandRenderer INSTANCE = new DynamicIslandRenderer();
    private static final class_2960 TEXTURE_ID = class_2960.method_60655("dioxide_lite", "dynamic_island_text");
    private static final SurfaceProps SURFACE_PROPS = new SurfaceProps(false, PixelGeometry.RGB_H);
    private static final float BASE_HEIGHT = 30f;
    private static final float MIN_WIDTH = 250f;
    private static final float MAX_WIDTH_MARGIN = 24f;
    private static final float TOP = 10f;
    private static final float PADDING_X = 18f;
    private static final float TEXT_SIZE = 11.5f;
    private static final float ICON_SIZE = 13.5f;
    private static final float ICON_GAP = 4f;
    private static final float ICON_Y_OFFSET = 3.0f;
    private static final float SEPARATOR_GAP = 8f;
    private static final float TAB_MIN_WIDTH = 340f;
    private static final float TAB_MAX_WIDTH_MARGIN = 34f;
    private static final float TAB_TOP_PADDING = 16f;
    private static final float TAB_BOTTOM_PADDING = 16f;
    private static final float TAB_SIDE_PADDING = 22f;
    private static final float TAB_ROW_HEIGHT = 14f;
    private static final float TAB_COLUMN_GAP = 20f;
    private static final float TAB_NAME_SIZE = 11.5f;
    private static final int TAB_MAX_ROWS = 20;
    private static final String ICON_LINK = "\uE157";
    private static final String ICON_COMPUTER = "\uE30C";
    private static final String ICON_PERSON = "\uE7FD";
    private static final int TEXT_COLOR = 0xF2111827;
    private static final int SEPARATOR_COLOR = 0x8A111827;
    private static final int TAB_SELF_NAME_COLOR = 0xFFFF5555;
    private static final int TAB_DEFAULT_NAME_COLOR = 0xFFFFFFFF;
    private static final int TAB_SPECTATOR_NAME_COLOR = 0xFFAAAAAA;
    private static final float SIZE_EASE_SPEED = 13.5f;
    private static final float TAB_FADE_EASE_SPEED = 9.0f;
    private static final long TAB_REQUEST_TTL_MS = 120L;

    private Surface surface;
    private class_1043 texture;
    private boolean nativeLoaded = false;
    private int textureW = -1;
    private int textureH = -1;
    private int textureRegionW = -1;
    private int textureRegionH = -1;
    private String lastContentKey = "";
    private float lastWidth = -1f;
    private float lastScale = -1f;
    private float animatedWidth = -1f;
    private float animatedHeight = -1f;
    private float tabContentFade = 0f;
    private long lastAnimationTime = 0L;
    private long lastTabRequestTime = 0L;

    public static DynamicIslandRenderer getInstance() {
        return INSTANCE;
    }

    public void requestTabListFrame() {
        lastTabRequestTime = System.currentTimeMillis();
    }

    public void render(class_332 graphics) {
        if (!Config.dynamicIsland) {
            destroyTexture(class_310.method_1551());
            resetAnimation();
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.method_22683() == null) {
            return;
        }
        if (client.field_1755 instanceof class_465<?>) {
            return;
        }

        IslandContent content = buildContent(client);
        boolean tabOpen = isTabOpen();
        List<class_640> tabPlayers = tabOpen ? getTabPlayers(client) : List.of();
        IslandLayout targetLayout = tabOpen ? measureTabLayout(client, tabPlayers) : measureLayout(client, content);
        IslandLayout layout = updateAnimatedLayout(targetLayout);
        float x = (client.method_22683().method_4486() - layout.width) * 0.5f;
        float y = TOP;

        int tint = 0x66D9ECFF;
        if (Config.liquidGlassAllVisuals) LiquidGlassVisualSystem.renderHudDock(graphics, x, y, layout.width, layout.height, .86f);
        SkiaBlurRenderer.getInstance().render(client, x, y, layout.width, layout.height, layout.radius,
                tint, Config.dynamicIslandBlur * Config.dynamicIslandOpacity);
        renderTextTexture(client, content, tabPlayers, layout, tabOpen);
        graphics.method_25302(class_10799.field_56883, TEXTURE_ID, Math.round(x), Math.round(y), 0f, 0f,
                Math.round(layout.width), Math.round(layout.height), textureRegionW, textureRegionH, textureW, textureH);
    }

    private boolean isTabOpen() {
        class_310 client = class_310.method_1551();
        boolean keyDown = client.field_1690 != null && client.field_1690.field_1907.method_1434();
        return keyDown || System.currentTimeMillis() - lastTabRequestTime <= TAB_REQUEST_TTL_MS;
    }

    private IslandLayout updateAnimatedLayout(IslandLayout target) {
        long now = System.currentTimeMillis();
        if (animatedWidth < 0f || animatedHeight < 0f || lastAnimationTime == 0L) {
            animatedWidth = target.width;
            animatedHeight = target.height;
            lastAnimationTime = now;
            return target;
        }

        float dt = Math.min((now - lastAnimationTime) / 1000f, 0.05f);
        lastAnimationTime = now;
        animatedWidth = easeTo(animatedWidth, target.width, SIZE_EASE_SPEED, dt);
        animatedHeight = easeTo(animatedHeight, target.height, SIZE_EASE_SPEED, dt);
        boolean reachedTarget = Math.abs(animatedWidth - target.width) < 1.25f && Math.abs(animatedHeight - target.height) < 1.25f;
        if (reachedTarget) {
            animatedWidth = target.width;
            animatedHeight = target.height;
        }
        tabContentFade = easeTo(tabContentFade, target.isTab && reachedTarget ? 1f : 0f, TAB_FADE_EASE_SPEED, dt);
        if (tabContentFade > 0.985f) {
            tabContentFade = 1f;
        } else if (tabContentFade < 0.015f) {
            tabContentFade = 0f;
        }
        return new IslandLayout(animatedWidth, animatedHeight, Math.min(animatedHeight * 0.5f, target.isTab ? 18f : 16f), target.isTab);
    }

    private float easeTo(float current, float target, float speed, float dt) {
        float alpha = 1f - (float) Math.exp(-speed * dt);
        return current + (target - current) * alpha;
    }

    private IslandContent buildContent(class_310 client) {
        String username = client.method_1548() != null ? client.method_1548().method_1676() : "Unknown";
        String location = getLocationText(client);
        String fps = String.valueOf(client.method_47599());
        String brand = Config.clientName == null || Config.clientName.isBlank() ? "DioxideLite" : Config.clientName;
        return new IslandContent(brand, username, location, fps);
    }

    private String getLocationText(class_310 client) {
        class_642 server = client.method_1558();
        if (server != null && server.field_3761 != null && !server.field_3761.isBlank()) {
            return server.field_3761;
        }
        return "Singleplayer";
    }

    private IslandLayout measureLayout(class_310 client, IslandContent content) {
        float textW = measure(content.brand)
                + measureIconSegment(content.username)
                + measureIconSegment(content.location)
                + measureIconSegment("FPS:" + content.fps)
                + measure("|") * 3f
                + SEPARATOR_GAP * 6f;
        float maxW = Math.max(120f, client.method_22683().method_4486() - MAX_WIDTH_MARGIN * 2f);
        float width = clamp(Math.max(MIN_WIDTH, textW + PADDING_X * 2f) * Config.dynamicIslandWidthScale,
                MIN_WIDTH * Config.dynamicIslandWidthScale, maxW);
        float height = BASE_HEIGHT * Config.dynamicIslandHeightScale;
        return new IslandLayout(width, height, Math.min(height * 0.5f, 18f), false);
    }

    private IslandLayout measureTabLayout(class_310 client, List<class_640> players) {
        int count = Math.max(1, players.size());
        int columns = Math.max(1, (count + TAB_MAX_ROWS - 1) / TAB_MAX_ROWS);
        int rows = Math.max(1, (count + columns - 1) / columns);
        float nameW = 120f;
        for (class_640 player : players) {
            nameW = Math.max(nameW, measure(parseTabName(getPlayerName(player), TAB_DEFAULT_NAME_COLOR).text()));
        }
        float columnW = clamp(nameW + 48f, 150f, 230f);
        float rawWidth = TAB_SIDE_PADDING * 2f + columns * columnW + (columns - 1) * TAB_COLUMN_GAP;
        float maxW = Math.max(TAB_MIN_WIDTH, client.method_22683().method_4486() - TAB_MAX_WIDTH_MARGIN * 2f);
        float width = clamp(Math.max(TAB_MIN_WIDTH, rawWidth), TAB_MIN_WIDTH, maxW);
        float height = TAB_TOP_PADDING + TAB_BOTTOM_PADDING + rows * TAB_ROW_HEIGHT;
        float maxH = Math.max(BASE_HEIGHT, client.method_22683().method_4502() - TOP * 2f);
        return new IslandLayout(width, clamp(height * Config.dynamicIslandHeightScale, 74f, maxH), 18f, true);
    }

    private float measure(String text) {
        return FontRenderer.measureTextWidth(text, TEXT_SIZE);
    }

    private void renderTextTexture(class_310 client, IslandContent content, List<class_640> tabPlayers, IslandLayout layout, boolean tabOpen) {
        ensureNativeLoaded();
        float scale = Math.max(1f, (float) client.method_22683().method_4495());
        int targetW = Math.max(1, Math.round(layout.width * scale));
        int targetH = Math.max(1, Math.round(layout.height * scale));
        String key = content.key() + "|" + tabKey(tabPlayers, tabOpen) + "|" + Math.round(layout.width) + "x" + Math.round(layout.height) + "|" + Math.round(tabContentFade * 255f);
        if (texture != null && targetW == textureW && targetH == textureH && key.equals(lastContentKey) && scale == lastScale) {
            return;
        }

        if (surface == null || texture == null || targetW > textureW || targetH > textureH) {
            destroyTexture(client);
            int capacityW = nextTextureCapacity(targetW);
            int capacityH = nextTextureCapacity(targetH);
            surface = Surface.makeRaster(new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), capacityW, capacityH), 0, SURFACE_PROPS);
            texture = new class_1043("dioxide_lite:dynamic_island_text", capacityW, capacityH, false);
            client.method_1531().method_4616(TEXTURE_ID, texture);
            textureW = capacityW;
            textureH = capacityH;
        }
        textureRegionW = targetW;
        textureRegionH = targetH;

        Canvas canvas = surface.getCanvas();
        canvas.restoreToCount(1);
        canvas.resetMatrix();
        canvas.clear(0x00000000);
        canvas.save();
        canvas.scale(scale, scale);

        // The island follows the reference's compact, outline-first HUD language:
        // almost black translucent body, a single cool rim and a tiny moving
        // highlight. Background blur is supplied by SkiaBlurRenderer on the
        // Minecraft framebuffer before this texture is composited.
        Paint islandPaint = new Paint().setAntiAlias(true);
        islandPaint.setColor(DioxideLiteVisuals.withAlpha(0x071018, 0.46f * Config.dynamicIslandOpacity));
        canvas.drawRRect(RRect.makeXYWH(0f, 0f, layout.width, layout.height, layout.radius), islandPaint);
        DioxideLiteVisuals.outline(canvas, 0f, 0f, layout.width, layout.height, layout.radius,
                DioxideLiteVisuals.CYAN, 0.26f * Config.dynamicIslandOpacity, 0.75f);
        float sheen = (float) ((Math.sin(System.nanoTime() / 1_000_000_000.0 * 0.65) + 1.0) * 0.5);
        float sheenW = Math.max(18f, layout.width * 0.12f);
        islandPaint.setColor(DioxideLiteVisuals.withAlpha(0xFFFFFF, 0.018f * Config.glassHighlight));
        canvas.save();
        canvas.clipRRect(RRect.makeXYWH(0f, 0f, layout.width, layout.height, layout.radius), true);
        canvas.drawRect(Rect.makeXYWH(-sheenW + (layout.width + sheenW * 2f) * sheen, 0f, sheenW, layout.height), islandPaint);
        canvas.restore();
        islandPaint.close();

        if (tabOpen || tabContentFade > 0f) {
            drawTabContent(canvas, tabPlayers, layout, tabContentFade);
        } else {
            drawCenteredContent(canvas, content, layout);
        }
        canvas.restore();

        uploadSurface(surface, texture, textureW, textureH);
        lastContentKey = key;
        lastWidth = layout.width;
        lastScale = scale;
    }

    private String tabKey(List<class_640> players, boolean tabOpen) {
        if (!tabOpen) return "compact";
        StringBuilder key = new StringBuilder("tab:");
        for (int i = 0; i < Math.min(players.size(), 80); i++) {
            class_640 player = players.get(i);
            key.append(player.method_2966().id())
                    .append(':').append(getPlayerName(player))
                    .append('@').append(player.method_2959())
                    .append(';');
        }
        return key.toString();
    }

    private void drawCenteredContent(Canvas canvas, IslandContent content, IslandLayout layout) {
        float fullW = measure(content.brand)
                + measureIconSegment(content.username)
                + measureIconSegment(content.location)
                + measureIconSegment("FPS:" + content.fps)
                + measure("|") * 3f
                + SEPARATOR_GAP * 6f;
        float x = (layout.width - fullW) * 0.5f;
        float y = layout.height * 0.5f + 4.0f;
        x = drawSegment(canvas, content.brand, x, y);
        x = drawSeparator(canvas, x, y);
        x = drawIconSegment(canvas, ICON_PERSON, content.username, x, y);
        x = drawSeparator(canvas, x, y);
        x = drawIconSegment(canvas, ICON_LINK, content.location, x, y);
        x = drawSeparator(canvas, x, y);
        drawIconSegment(canvas, ICON_COMPUTER, "FPS:" + content.fps, x, y);
    }

    private float drawSegment(Canvas canvas, String text, float x, float y) {
        FontRenderer.drawText(canvas, text, x, y, TEXT_SIZE, TEXT_COLOR);
        return x + measure(text);
    }

    private float drawIconSegment(Canvas canvas, String icon, String text, float x, float y) {
        FontRenderer.drawText(canvas, icon, x, y + ICON_Y_OFFSET, ICON_SIZE, TEXT_COLOR, FontRenderer.MATERIAL_SYMBOLS);
        x += measureIcon() + ICON_GAP;
        FontRenderer.drawText(canvas, text, x, y, TEXT_SIZE, TEXT_COLOR);
        return x + measure(text);
    }

    private float measureIconSegment(String text) {
        return measureIcon() + ICON_GAP + measure(text);
    }

    private float measureIcon() {
        return FontRenderer.measureTextWidth(ICON_PERSON, ICON_SIZE, FontRenderer.MATERIAL_SYMBOLS);
    }

    private float drawSeparator(Canvas canvas, float x, float y) {
        x += SEPARATOR_GAP;
        FontRenderer.drawText(canvas, "|", x, y, TEXT_SIZE, SEPARATOR_COLOR);
        return x + measure("|") + SEPARATOR_GAP;
    }

    private List<class_640> getTabPlayers(class_310 client) {
        if (client.method_1562() == null) return List.of();
        List<class_640> players = new ArrayList<>(client.method_1562().method_45732());
        players.sort(Comparator
                .comparingInt(class_640::method_62154)
                .thenComparing(info -> getPlayerName(info).toLowerCase()));
        return players;
    }

    private void drawTabContent(Canvas canvas, List<class_640> players, IslandLayout layout, float fade) {
        int alpha = Math.round(clamp(fade, 0f, 1f) * 255f);
        if (alpha <= 0 || players.isEmpty()) return;

        int count = players.size();
        int columns = Math.max(1, (count + TAB_MAX_ROWS - 1) / TAB_MAX_ROWS);
        int rows = Math.max(1, (count + columns - 1) / columns);
        float usableW = layout.width - TAB_SIDE_PADDING * 2f - (columns - 1) * TAB_COLUMN_GAP;
        float columnW = usableW / columns;
        float totalContentH = rows * TAB_ROW_HEIGHT;
        float startY = TAB_TOP_PADDING + (layout.height - TAB_TOP_PADDING - TAB_BOTTOM_PADDING - totalContentH) * 0.5f + 10.5f;

        for (int i = 0; i < count; i++) {
            int column = i / rows;
            int row = i % rows;
            float x = TAB_SIDE_PADDING + column * (columnW + TAB_COLUMN_GAP);
            float y = startY + row * TAB_ROW_HEIGHT;
            class_640 player = players.get(i);
            int baseColor = player.method_2958() == class_1934.field_9219 ? TAB_SPECTATOR_NAME_COLOR : TAB_DEFAULT_NAME_COLOR;
            FormattedTabName formattedName = parseTabName(getPlayerName(player), baseColor);
            String name = trimToWidth(formattedName.text(), columnW - 46f, TAB_NAME_SIZE);
            int color = isLocalPlayer(player) ? TAB_SELF_NAME_COLOR : formattedName.color();
            FontRenderer.drawText(canvas, name, x, y, TAB_NAME_SIZE, withAlpha(color, alpha));

            String latency = formatLatency(player.method_2959());
            float latencyW = FontRenderer.measureTextWidth(latency, 9f);
            FontRenderer.drawText(canvas, latency, x + columnW - latencyW, y, 9f, withAlpha(latencyColor(player.method_2959()), alpha));
        }
    }

    private FormattedTabName parseTabName(String rawName, int fallbackColor) {
        if (rawName == null || rawName.isEmpty()) {
            return new FormattedTabName("", fallbackColor);
        }

        StringBuilder cleanName = new StringBuilder(rawName.length());
        int color = fallbackColor;
        for (int i = 0; i < rawName.length(); i++) {
            char current = rawName.charAt(i);
            if ((current == '\u00A7' || current == '&') && i + 1 < rawName.length()) {
                Integer parsedColor = minecraftColor(rawName.charAt(++i), fallbackColor);
                if (parsedColor != null) {
                    color = parsedColor;
                }
                continue;
            }
            cleanName.append(current);
        }
        return new FormattedTabName(cleanName.toString(), color);
    }

    private Integer minecraftColor(char code, int fallbackColor) {
        return switch (Character.toLowerCase(code)) {
            case '0' -> 0xFF000000;
            case '1' -> 0xFF0000AA;
            case '2' -> 0xFF00AA00;
            case '3' -> 0xFF00AAAA;
            case '4' -> 0xFFAA0000;
            case '5' -> 0xFFAA00AA;
            case '6' -> 0xFFFFAA00;
            case '7' -> 0xFFAAAAAA;
            case '8' -> 0xFF555555;
            case '9' -> 0xFF5555FF;
            case 'a' -> 0xFF55FF55;
            case 'b' -> 0xFF55FFFF;
            case 'c' -> 0xFFFF5555;
            case 'd' -> 0xFFFF55FF;
            case 'e' -> 0xFFFFFF55;
            case 'f' -> 0xFFFFFFFF;
            case 'r' -> fallbackColor;
            default -> null;
        };
    }

    private boolean isLocalPlayer(class_640 player) {
        class_310 client = class_310.method_1551();
        return client.field_1724 != null && player.method_2966().id().equals(client.field_1724.method_5667());
    }

    private String getPlayerName(class_640 player) {
        if (player.method_2971() != null) {
            return player.method_2971().getString();
        }
        return player.method_2966().name();
    }

    private String trimToWidth(String text, float maxWidth, float size) {
        if (FontRenderer.measureTextWidth(text, size) <= maxWidth) return text;
        String suffix = "...";
        float suffixW = FontRenderer.measureTextWidth(suffix, size);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            String next = out + text.substring(i, i + 1);
            if (FontRenderer.measureTextWidth(next, size) + suffixW > maxWidth) break;
            out.append(text.charAt(i));
        }
        return out + suffix;
    }

    private String formatLatency(int latency) {
        return latency < 0 ? "?" : latency + "ms";
    }

    private int latencyColor(int latency) {
        if (latency < 0) return 0xFFAAAAAA;
        if (latency < 150) return 0xFF53D86A;
        if (latency < 300) return 0xFFFFD166;
        return 0xFFFF6B6B;
    }

    private int withAlpha(int argb, int alpha) {
        return (argb & 0x00FFFFFF) | (clamp(alpha, 0, 255) << 24);
    }

    private void ensureNativeLoaded() {
        if (nativeLoaded) return;
        Library.load();
        nativeLoaded = true;
    }

    private void uploadSurface(Surface sourceSurface, class_1043 targetTexture, int width, int height) {
        Pixmap pixmap = new Pixmap();
        try {
            if (!sourceSurface.peekPixels(pixmap)) return;
            long addr = pixmap.getAddr();
            int byteSize = height * pixmap.getRowBytes();
            ByteBuffer buf = MemoryUtil.memByteBuffer(addr, byteSize);
            GpuTexture gpuTexture = targetTexture.method_68004();
            RenderSystem.getDevice().createCommandEncoder()
                    .writeToTexture(gpuTexture, buf, class_1011.class_1012.field_4997, 0, 0, 0, 0, width, height);
        } finally {
            pixmap.close();
        }
    }

    private void destroyTexture(class_310 client) {
        if (surface != null) {
            surface.close();
            surface = null;
        }
        if (texture != null) {
            client.method_1531().method_4615(TEXTURE_ID);
            texture = null;
        }
        textureW = -1;
        textureH = -1;
        textureRegionW = -1;
        textureRegionH = -1;
        lastContentKey = "";
        lastWidth = -1f;
        lastScale = -1f;
    }

    private void resetAnimation() {
        animatedWidth = -1f;
        animatedHeight = -1f;
        tabContentFade = 0f;
        lastAnimationTime = 0L;
        lastTabRequestTime = 0L;
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int nextTextureCapacity(int value) {
        int capacity = 64;
        while (capacity < value) {
            capacity *= 2;
        }
        return capacity;
    }

    private record IslandContent(String brand, String username, String location, String fps) {
        String key() {
            return brand + "|" + username + "|" + location + "|" + fps;
        }
    }

    private record IslandLayout(float width, float height, float radius, boolean isTab) {
    }

    private record FormattedTabName(String text, int color) {
    }
}
