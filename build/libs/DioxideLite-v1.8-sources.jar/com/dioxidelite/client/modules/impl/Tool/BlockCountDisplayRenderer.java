package com.dioxidelite.client.modules.impl.Tool;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.dioxidelite.Config;
import com.dioxidelite.client.modules.impl.Render.HudEditOverlay;
import com.dioxidelite.client.render.font.FontRenderer;
import com.dioxidelite.client.render.skia.SkiaBlurRenderer;
import com.dioxidelite.client.util.RateCounter;
import io.github.humbleui.skija.*;
import io.github.humbleui.skija.impl.Library;
import io.github.humbleui.types.RRect;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.Locale;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;

public class BlockCountDisplayRenderer {
    private static final BlockCountDisplayRenderer INSTANCE = new BlockCountDisplayRenderer();
    private static final long STAY_MS = 900L;
    private static final long ANIM_DURATION = 200L;
    private static final float WIDTH = 190f;
    private static final float HEIGHT = 58f;
    private static final float PURPLE = 0xFF8F5CFF;
    private static final class_2960 TEXTURE_ID = class_2960.method_60655("dioxide_lite", "block_count_display");
    private static final class_2960 OVERLAY_TEXTURE_ID = class_2960.method_60655("dioxide_lite", "block_count_display_overlay");
    private static final SurfaceProps SURFACE_PROPS = new SurfaceProps(false, PixelGeometry.RGB_H);

    private final RateCounter rightClicks = new RateCounter();
    private final RateCounter placements = new RateCounter();
    private final Paint bgPaint = new Paint().setAntiAlias(true);
    private final Paint ringFillPaint = new Paint().setAntiAlias(true);
    private final Paint ringTrackPaint = new Paint().setAntiAlias(true).setMode(PaintMode.STROKE).setStrokeWidth(4f);
    private final Paint ringArcPaint = new Paint().setAntiAlias(true).setMode(PaintMode.STROKE).setStrokeWidth(4f);

    private Surface surface;
    private Surface overlaySurface;
    private class_1043 dynamicTexture;
    private class_1043 overlayTexture;
    private boolean visible = false;
    private boolean closing = false;
    private boolean nativeLoaded = false;
    private float scale = 0f;
    private float ringProgress = 0f;
    private String lastTextureName = "";
    private String lastTextureSpeed = "";
    private int lastTextureProgress = -1;
    private Config.HudTheme lastTextureTheme = null;
    private Config.HudTheme lastOverlayTextureTheme = null;
    private boolean lastTextureBlurMode = false;
    private boolean lastOverlayTextureBlurMode = false;
    private int textureW = -1;
    private int textureH = -1;
    private int overlayTextureW = -1;
    private int overlayTextureH = -1;
    private float textureScale = -1f;
    private long lastInteractionMs = 0L;
    private long appearanceTime = 0L;
    private long closeTime = 0L;
    private int lastSlot = -1;
    private int lastCount = -1;
    private class_1799 displayStack = class_1799.field_8037;

    public static BlockCountDisplayRenderer getInstance() {
        return INSTANCE;
    }

    public boolean needsCanvas() {
        return false;
    }

    public float getEditWidth() {
        return WIDTH * Math.max(0.5f, Config.blockCountDisplayScale);
    }

    public float getEditHeight() {
        return HEIGHT * Math.max(0.5f, Config.blockCountDisplayScale);
    }

    public float getDefaultY(int screenH) {
        return screenH - 112f;
    }

    public float getRenderX(int screenW) {
        float scaledW = getEditWidth();
        return clamp((screenW - scaledW) * 0.5f + Config.blockCountDisplayX, 0f, Math.max(0f, screenW - scaledW));
    }

    public float getRenderY(int screenH) {
        float scaledH = getEditHeight();
        return clamp(getDefaultY(screenH) + Config.blockCountDisplayY, 0f, Math.max(0f, screenH - scaledH));
    }

    public void tick(class_310 client) {
        if (!Config.blockCountDisplay) {
            reset();
            return;
        }
        if (HudEditOverlay.getInstance().isActive()) return;

        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null || client.field_1755 != null) {
            close();
            rightClicks.resetPressed();
            return;
        }

        class_1799 stack = player.method_6047();
        boolean block = stack.method_7909() instanceof class_1747;
        long now = System.currentTimeMillis();
        placements.count(now);

        if (!block) {
            close();
            rightClicks.resetPressed();
            return;
        }

        int slot = player.method_31548().method_67532();
        if (slot != lastSlot || !class_1799.method_31577(stack, displayStack)) {
            if (visible && lastSlot != -1) close();
            ringProgress = 0f;
            lastSlot = slot;
        }
        lastCount = stack.method_7947();
        displayStack = stack.method_7972();

        if (visible && now - lastInteractionMs > STAY_MS) close();
    }

    public void triggerUse(class_310 client) {
        if (!Config.blockCountDisplay || HudEditOverlay.getInstance().isActive()) return;
        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null || client.field_1755 != null) return;
        class_1799 stack = player.method_6047();
        if (!(stack.method_7909() instanceof class_1747)) return;

        long now = System.currentTimeMillis();
        open(now);
        lastInteractionMs = now;
        if (scale <= 0.01f) ringProgress = 0f;
        lastSlot = player.method_31548().method_67532();
        lastCount = stack.method_7947();
        displayStack = stack.method_7972();
        placements.count(now);
    }

    public void recordPlacement(class_310 client) {
        if (!Config.blockCountDisplay || HudEditOverlay.getInstance().isActive()) return;
        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null || client.field_1755 != null) return;
        class_1799 stack = player.method_6047();
        if (!(stack.method_7909() instanceof class_1747)) return;

        long now = System.currentTimeMillis();
        placements.record();
        open(now);
        lastInteractionMs = now;
        if (scale <= 0.01f) ringProgress = 0f;
        lastSlot = player.method_31548().method_67532();
        lastCount = stack.method_7947();
        displayStack = stack.method_7972();
    }

    public void render(class_332 graphics, Canvas canvas) {
        if (!Config.blockCountDisplay) {
            destroyTexture(class_310.method_1551());
            reset();
            return;
        }

        class_310 client = class_310.method_1551();
        class_746 player = client.field_1724;
        boolean editActive = HudEditOverlay.getInstance().isActive();
        if (player == null || client.field_1687 == null || (client.field_1755 != null && !editActive)) {
            close();
            updateScale(System.currentTimeMillis());
            return;
        }

        class_1799 stack = player.method_6047();
        boolean block = stack.method_7909() instanceof class_1747;
        long now = System.currentTimeMillis();

        if (editActive) {
            visible = true;
            closing = false;
            scale = Math.max(scale, 1f);
            lastInteractionMs = now;
            if (!block) {
                stack = new class_1799(class_1802.field_20391, 64);
                block = true;
            }
            displayStack = stack.method_7972();
            lastSlot = player.method_31548().method_67532();
            lastCount = stack.method_7947();
            if (ringProgress <= 0.01f) ringProgress = 1f;
        }

        int rightCps = editActive ? rightClicks.count(now) : rightClicks.updatePressed(client.field_1690.field_1904.method_1434());
        placements.count(now);
        updateScale(now);
        if (scale <= 0.01f || displayStack.method_7960()) return;

        int screenW = client.method_22683().method_4486();
        int screenH = client.method_22683().method_4502();
        float x = getRenderX(screenW);
        float y = getRenderY(screenH);
        float userScale = Math.max(0.5f, Config.blockCountDisplayScale);
        float scaledW = WIDTH * userScale;
        float scaledH = HEIGHT * userScale;
        float cx = x + scaledW * 0.5f;
        float cy = y + scaledH * 0.5f;
        float drawScale = easeOutBack(scale);
        float drawX = cx + (x - cx) * drawScale;
        float drawY = cy + (y - cy) * drawScale;
        float drawW = scaledW * drawScale;
        float drawH = scaledH * drawScale;
        float drawRadius = 16f * userScale * drawScale;

        String name = displayStack.method_7964().getString();
        if (FontRenderer.measureTextWidth(name, 13f) > 128f) {
            while (name.length() > 1 && FontRenderer.measureTextWidth(name + "...", 13f) > 128f) {
                name = name.substring(0, name.length() - 1);
            }
            name += "...";
        }
        String speed = String.format(Locale.ROOT, "%dBPS\\%dCPS", placements.count(now), rightCps);

        float ringCx = x + (WIDTH - 32f) * userScale;
        float ringCy = y + HEIGHT * 0.5f * userScale;
        float ratio = Math.max(0f, Math.min(1f, displayStack.method_7947() / (float) Math.max(1, displayStack.method_7914())));
        ringProgress += (ratio - ringProgress) * 0.18f;

        boolean blurMode = Config.blockCountDisplayMode == Config.BlockCountDisplayMode.BLUR;
        renderBaseTexture(client, name, blurMode);
        renderOverlayTexture(client, speed, ringProgress, blurMode);
        if (blurMode) {
            SkiaBlurRenderer.getInstance().render(client, drawX, drawY, drawW, drawH, drawRadius, Config.skiaBlurTintColor(), Config.skiaBlurStrength);
        }

        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(cx, cy);
        graphics.method_51448().scale(drawScale, drawScale);
        graphics.method_51448().translate(-cx, -cy);
        graphics.method_25302(class_10799.field_56883, TEXTURE_ID, Math.round(x), Math.round(y), 0f, 0f, Math.round(scaledW), Math.round(scaledH), textureW, textureH, textureW, textureH);
        graphics.method_25302(class_10799.field_56883, OVERLAY_TEXTURE_ID, Math.round(x), Math.round(y), 0f, 0f, Math.round(scaledW), Math.round(scaledH), overlayTextureW, overlayTextureH, overlayTextureW, overlayTextureH);

        int itemX = Math.round(ringCx - 8f);
        int itemY = Math.round(ringCy - 8f);
        float iconScale = 0.35f + 0.65f * easeOutCubic(scale);
        graphics.method_51448().translate(ringCx, ringCy);
        graphics.method_51448().scale(iconScale, iconScale);
        graphics.method_51448().translate(-ringCx, -ringCy);
        graphics.method_51445(displayStack, itemX, itemY);
        graphics.method_51431(client.field_1772, displayStack, itemX, itemY);
        graphics.method_73199();
        graphics.method_51448().popMatrix();
    }

    public void renderFrameEnd() {
        // Kept for the shared frame-end hook. BlockCount renders through GuiGraphics to keep item layering correct.
    }

    private void updateScale(long now) {
        if (visible) {
            scale = clamp((now - appearanceTime) / (float) ANIM_DURATION, 0f, 1f);
            return;
        }

        if (closing) {
            scale = 1f - clamp((now - closeTime) / (float) ANIM_DURATION, 0f, 1f);
        } else {
            scale = 0f;
        }

        if (!visible && scale <= 0f) {
            closing = false;
            if (displayStack.method_7960()) return;
            displayStack = class_1799.field_8037;
        }
    }

    private float easeOutBack(float value) {
        float t = Math.max(0f, Math.min(1f, value)) - 1f;
        return 1f + t * t * (1.55f * t + 0.55f);
    }

    private float easeOutCubic(float value) {
        float t = 1f - Math.max(0f, Math.min(1f, value));
        return 1f - t * t * t;
    }

    private void open(long now) {
        if (!visible) {
            appearanceTime = now - Math.round(scale * ANIM_DURATION);
        }
        visible = true;
        closing = false;
    }

    private void close() {
        if (visible) {
            closeTime = System.currentTimeMillis() - Math.round((1f - scale) * ANIM_DURATION);
        }
        visible = false;
        closing = true;
        lastSlot = -1;
        lastCount = -1;
    }

    private void reset() {
        visible = false;
        closing = false;
        scale = 0f;
        lastInteractionMs = 0L;
        appearanceTime = 0L;
        closeTime = 0L;
        ringProgress = 0f;
        lastSlot = -1;
        lastCount = -1;
        displayStack = class_1799.field_8037;
        rightClicks.clear();
        placements.clear();
    }

    private void renderBaseTexture(class_310 client, String name, boolean blurMode) {
        ensureNativeLoaded();
        float userScale = Math.max(0.5f, Config.blockCountDisplayScale);
        float targetScale = Math.max(1f, (float) client.method_22683().method_4495() * userScale);
        int targetW = Math.max(1, Math.round(WIDTH * targetScale));
        int targetH = Math.max(1, Math.round(HEIGHT * targetScale));
        if (dynamicTexture != null && targetW == textureW && targetH == textureH && name.equals(lastTextureName) && lastTextureTheme == Config.hudTheme && lastTextureBlurMode == blurMode) return;

        if (surface == null || dynamicTexture == null || targetW != textureW || targetH != textureH) {
            destroyBaseTexture(client);
            surface = Surface.makeRaster(new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), targetW, targetH), 0, SURFACE_PROPS);
            dynamicTexture = new class_1043("dioxide_lite:block_count_display", targetW, targetH, false);
            client.method_1531().method_4616(TEXTURE_ID, dynamicTexture);
            textureW = targetW;
            textureH = targetH;
            textureScale = targetScale;
            lastTextureName = "";
        }

        Canvas c = surface.getCanvas();
        c.restoreToCount(1);
        c.resetMatrix();
        c.clear(0x00000000);
        c.save();
        c.scale(textureScale, textureScale);
        if (!blurMode) {
            bgPaint.setColor(newCardColor());
            c.drawRRect(RRect.makeXYWH(0f, 0f, WIDTH, HEIGHT, 16f), bgPaint);
        }
        FontRenderer.drawText(c, name, 16f, 22f, 12f, primaryTextColor(blurMode));
        c.restore();
        uploadSurface(surface, dynamicTexture, textureW, textureH);
        lastTextureName = name;
        lastTextureTheme = Config.hudTheme;
        lastTextureBlurMode = blurMode;
    }

    private void renderOverlayTexture(class_310 client, String speed, float progress, boolean blurMode) {
        ensureNativeLoaded();
        float userScale = Math.max(0.5f, Config.blockCountDisplayScale);
        float targetScale = Math.max(1f, (float) client.method_22683().method_4495() * userScale);
        int targetW = Math.max(1, Math.round(WIDTH * targetScale));
        int targetH = Math.max(1, Math.round(HEIGHT * targetScale));
        int progressKey = Math.round(progress * 48f);
        if (overlayTexture != null && targetW == overlayTextureW && targetH == overlayTextureH && speed.equals(lastTextureSpeed) && progressKey == lastTextureProgress && lastOverlayTextureTheme == Config.hudTheme && lastOverlayTextureBlurMode == blurMode) return;

        if (overlaySurface == null || overlayTexture == null || targetW != overlayTextureW || targetH != overlayTextureH) {
            destroyOverlayTexture(client);
            overlaySurface = Surface.makeRaster(new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), targetW, targetH), 0, SURFACE_PROPS);
            overlayTexture = new class_1043("dioxide_lite:block_count_display_overlay", targetW, targetH, false);
            client.method_1531().method_4616(OVERLAY_TEXTURE_ID, overlayTexture);
            overlayTextureW = targetW;
            overlayTextureH = targetH;
        }

        Canvas c = overlaySurface.getCanvas();
        c.restoreToCount(1);
        c.resetMatrix();
        c.clear(0x00000000);
        c.save();
        c.scale(targetScale, targetScale);
        FontRenderer.drawText(c, speed, 16f, 40f, 11f, mutedTextColor(blurMode));
        float ringCx = WIDTH - 32f;
        float ringCy = HEIGHT * 0.5f;
        float radius = 17f;
        ringFillPaint.setColor(ringFillColor(blurMode));
        c.drawCircle(ringCx, ringCy, radius + 5f, ringFillPaint);
        ringTrackPaint.setColor(ringTrackColor(blurMode));
        c.drawCircle(ringCx, ringCy, radius, ringTrackPaint);
        ringArcPaint.setColor((int) PURPLE);
        c.drawArc(ringCx - radius, ringCy - radius, ringCx + radius, ringCy + radius, -90f, -360f * progress, false, ringArcPaint);
        c.restore();
        uploadSurface(overlaySurface, overlayTexture, overlayTextureW, overlayTextureH);
        lastTextureSpeed = speed;
        lastTextureProgress = progressKey;
        lastOverlayTextureTheme = Config.hudTheme;
        lastOverlayTextureBlurMode = blurMode;
    }

    private int newCardColor() {
        return Config.hudTheme == Config.HudTheme.LIGHT ? 0xF7F8FAFC : 0xE6111827;
    }

    private int primaryTextColor(boolean blurMode) {
        return blurMode ? Config.hudPrimaryTextColor() : (Config.hudTheme == Config.HudTheme.LIGHT ? 0xFF202027 : 0xFFF8FAFC);
    }

    private int mutedTextColor(boolean blurMode) {
        return blurMode ? Config.hudMutedTextColor() : (Config.hudTheme == Config.HudTheme.LIGHT ? 0xAA5C5870 : 0xB8CBD5E1);
    }

    private int ringFillColor(boolean blurMode) {
        if (blurMode) {
            return Config.hudTheme == Config.HudTheme.LIGHT ? 0x228F5CFF : 0x1F8F5CFF;
        }
        return Config.hudTheme == Config.HudTheme.LIGHT ? 0x228F5CFF : 0x2A8F5CFF;
    }

    private int ringTrackColor(boolean blurMode) {
        if (blurMode) {
            return Config.hudTheme == Config.HudTheme.LIGHT ? 0x448F5CFF : 0x338F5CFF;
        }
        return Config.hudTheme == Config.HudTheme.LIGHT ? 0x448F5CFF : 0x668F5CFF;
    }

    private void ensureNativeLoaded() {
        if (nativeLoaded) return;
        Library.load();
        nativeLoaded = true;
    }

    private void uploadSurface(Surface sourceSurface, class_1043 targetTexture, int width, int height) {
        Pixmap pixmap = new Pixmap();
        try {
            if (!sourceSurface.peekPixels(pixmap)) return;
            long addr = pixmap.getAddr();
            int byteSize = height * pixmap.getRowBytes();
            ByteBuffer buf = MemoryUtil.memByteBuffer(addr, byteSize);
            GpuTexture gpuTexture = targetTexture.method_68004();
            RenderSystem.getDevice().createCommandEncoder()
                    .writeToTexture(gpuTexture, buf, class_1011.class_1012.field_4997, 0, 0, 0, 0, width, height);
        } finally {
            pixmap.close();
        }
    }

    private void destroyBaseTexture(class_310 client) {
        if (surface != null) {
            surface.close();
            surface = null;
        }
        if (dynamicTexture != null) {
            client.method_1531().method_4615(TEXTURE_ID);
            dynamicTexture = null;
        }
        textureW = -1;
        textureH = -1;
        textureScale = -1f;
        lastTextureName = "";
        lastTextureBlurMode = false;
        lastTextureTheme = null;
    }

    private void destroyOverlayTexture(class_310 client) {
        if (overlaySurface != null) {
            overlaySurface.close();
            overlaySurface = null;
        }
        if (overlayTexture != null) {
            client.method_1531().method_4615(OVERLAY_TEXTURE_ID);
            overlayTexture = null;
        }
        overlayTextureW = -1;
        overlayTextureH = -1;
        lastTextureSpeed = "";
        lastTextureProgress = -1;
        lastOverlayTextureBlurMode = false;
        lastOverlayTextureTheme = null;
    }

    private void destroyTexture(class_310 client) {
        destroyBaseTexture(client);
        destroyOverlayTexture(client);
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(value, max));
    }
}
