/*
 * This file is part of DioxideLiteVia - https://github.com/ViaVersion/DioxideLiteVia
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.dioxidelitevia.screen.impl;

import com.viaversion.dioxidelitevia.DioxideLiteViaImpl;
import com.viaversion.dioxidelitevia.api.settings.AbstractSetting;
import com.viaversion.dioxidelitevia.api.settings.SettingGroup;
import com.viaversion.dioxidelitevia.api.settings.type.BooleanSetting;
import com.viaversion.dioxidelitevia.api.settings.type.ButtonSetting;
import com.viaversion.dioxidelitevia.api.settings.type.ModeSetting;
import com.viaversion.dioxidelitevia.api.settings.type.VersionedBooleanSetting;
import com.viaversion.dioxidelitevia.screen.DioxideLiteViaList;
import com.viaversion.dioxidelitevia.screen.DioxideLiteViaScreen;
import com.viaversion.dioxidelitevia.screen.impl.settings.BooleanListEntry;
import com.viaversion.dioxidelitevia.screen.impl.settings.ButtonListEntry;
import com.viaversion.dioxidelitevia.screen.impl.settings.ModeListEntry;
import com.viaversion.dioxidelitevia.screen.impl.settings.TitleEntry;
import com.viaversion.dioxidelitevia.screen.impl.settings.VersionedBooleanListEntry;
import com.viaversion.dioxidelitevia.settings.SettingsManager;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public final class SettingsScreen extends DioxideLiteViaScreen {

    public static final SettingsScreen INSTANCE = new SettingsScreen();

    public SettingsScreen() {
        super(Component.translatable("screen.dioxidelitevia.settings"), true);
    }

    @Override
    protected void init() {
        this.setupDefaultSubtitle();
        this.addRenderableWidget(new SlotList(this.minecraft, width, height, 3 + 3 /* start offset */ + (font.lineHeight + 2) * 3 /* title is 2 */, -5, (font.lineHeight + 2) * 2));

        super.init();
    }

    public static class SlotList extends DioxideLiteViaList {
        private static double scrollAmount;

        public SlotList(Minecraft minecraftClient, int width, int height, int top, int bottom, int entryHeight) {
            super(minecraftClient, width, height, top, bottom, entryHeight);

            for (SettingGroup group : SettingsManager.INSTANCE.getGroups()) {
                this.addEntry(new TitleEntry(group.getName()));

                for (AbstractSetting<?> setting : group.getSettings()) {
                    switch (setting) {
                        case final BooleanSetting booleanSetting -> this.addEntry(new BooleanListEntry(booleanSetting));
                        case final ButtonSetting buttonSetting -> this.addEntry(new ButtonListEntry(buttonSetting));
                        case final ModeSetting modeSetting -> this.addEntry(new ModeListEntry(modeSetting));
                        case final VersionedBooleanSetting versionedBooleanSetting ->
                            this.addEntry(new VersionedBooleanListEntry(versionedBooleanSetting));
                        default ->
                            DioxideLiteViaImpl.INSTANCE.getLogger().warn("Unknown setting type: {}", setting.getClass().getName());
                    }
                }
            }
            initScrollY(scrollAmount);
        }

        @Override
        public int getRowWidth() {
            return super.getRowWidth() + 140;
        }

        @Override
        protected void updateSlotAmount(double amount) {
            scrollAmount = amount;
        }
    }

}
