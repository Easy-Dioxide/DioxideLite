/*
 * This file is part of DioxideLiteVia - https://github.com/ViaVersion/DioxideLiteVia
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.dioxidelitevia.injection.mixin.features.world.always_tick_entities;

import com.viaversion.dioxidelitevia.injection.access.world.always_tick_entities.IEntity;
import com.viaversion.dioxidelitevia.settings.impl.DebugSettings;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(Entity.class)
public abstract class MixinEntity implements IEntity {

    @Unique
    private boolean DioxideLiteVia$isInLoadedChunkAndShouldTick;

    @Override
    public boolean DioxideLiteVia$isInLoadedChunkAndShouldTick() {
        return this.DioxideLiteVia$isInLoadedChunkAndShouldTick || DebugSettings.INSTANCE.alwaysTickClientPlayer.isEnabled();
    }

    @Override
    public void DioxideLiteVia$setInLoadedChunkAndShouldTick(final boolean inLoadedChunkAndShouldTick) {
        this.DioxideLiteVia$isInLoadedChunkAndShouldTick = inLoadedChunkAndShouldTick;
    }

}
