package mixins;

import com.dioxideliteng.ui.mainmenu.background.MenuBackground;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(Screen.class)
public abstract class MixinMenuBackground {
   @WrapOperation(method = "extractRenderStateWithTooltipAndSubtitles", at = @At(value = "INVOKE",
      target = "Lnet/minecraft/client/gui/screens/Screen;extractBackground(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIF)V"))
   private void dioxideliteng$background(Screen screen, GuiGraphicsExtractor graphics, int x, int y, float delta, Operation<Void> original) {
      if (screen instanceof com.dioxideliteng.ui.terminal.TerminalPage page)
         com.dioxideliteng.ui.terminal.TerminalTheme.background(graphics, screen, page);
      else if (MenuBackground.applies(screen)) MenuBackground.render(graphics, screen.width, screen.height);
      else original.call(screen, graphics, x, y, delta);
   }
}
